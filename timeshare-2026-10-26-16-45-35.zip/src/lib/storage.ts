import { CalendarEvent, SharedCalendar, PinnedPlace, Member, CustomShiftRule, ShiftRosterProfile } from '../types';

export const CURRENT_USER: Member = {
  id: 'user-takuma',
  name: 'たくま (自分)',
  avatarUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=150&q=80',
  color: '#10B981', // Emerald green
  role: 'owner',
  email: 'abdef1590@gmail.com',
};

export const PARTNER_USER: Member = {
  id: 'user-aoi',
  name: 'あおい (パートナー)',
  avatarUrl: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=150&q=80',
  color: '#EC4899', // Pink
  role: 'member',
  email: 'aoi.share@example.com',
};

export const WORK_USER: Member = {
  id: 'user-work',
  name: '職場・シフト管理',
  avatarUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=150&q=80',
  color: '#3B82F6', // Blue
  role: 'member',
};

const DEFAULT_CALENDARS: SharedCalendar[] = [
  {
    id: 'cal-couple',
    name: 'ふたりの共有カレンダー',
    description: 'パートナーとのデートや記念日、お互いの予定を共有するカレンダー',
    color: '#10B981',
    emoji: '🌿',
    inviteCode: 'TREE-7749',
    isDefault: true,
    members: [CURRENT_USER, PARTNER_USER],
  },
  {
    id: 'cal-shift',
    name: '勤務表・シフト',
    description: '日勤・夜勤・早番・遅番などシフト勤務をまとめて管理',
    color: '#3B82F6',
    emoji: '🏥',
    inviteCode: 'WORK-2041',
    members: [CURRENT_USER, WORK_USER],
  },
  {
    id: 'cal-travel',
    name: '行きたい場所・旅計画',
    description: '週末のおでかけや行きたいカフェ、旅行のアイデアメモ',
    color: '#F59E0B',
    emoji: '✈️',
    inviteCode: 'TRIP-9310',
    members: [CURRENT_USER, PARTNER_USER],
  },
];

// Helper to get formatted date string for relative offsets
const getOffsetDate = (dayOffset: number): string => {
  const d = new Date();
  d.setDate(d.getDate() + dayOffset);
  return d.toISOString().substring(0, 10);
};

const DEFAULT_EVENTS: CalendarEvent[] = [
  {
    id: 'evt-1',
    calendarId: 'cal-couple',
    title: 'カフェ巡り＆ランチ ☕',
    date: getOffsetDate(1),
    startTime: '12:00',
    endTime: '15:00',
    isAllDay: false,
    memberIds: ['user-takuma', 'user-aoi'],
    color: '#F59E0B',
    category: 'デート',
    location: 'ブルーボトルコーヒー 清澄白河フラッグシップカフェ',
    locationCoords: { lat: 35.6795, lng: 139.7998 },
    notes: 'テラス席で新作ペイストリーとドリップコーヒーを楽しむ予定。',
    checklist: [
      { id: 'chk-1', text: 'カメラの充電', done: true },
      { id: 'chk-2', text: '本を持っていく', done: false },
    ],
    comments: [
      {
        id: 'c-1',
        memberId: 'user-aoi',
        memberName: 'あおい',
        memberAvatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=150&q=80',
        text: '12:00に門前仲町駅の改札前で待ち合わせしよう！',
        createdAt: '昨日 20:30',
      },
      {
        id: 'c-2',
        memberId: 'user-takuma',
        memberName: 'たくま',
        memberAvatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=150&q=80',
        text: '了解！天気が良さそうだからテラス席座れるといいね✨',
        createdAt: '昨日 20:45',
      },
    ],
  },
  {
    id: 'evt-2',
    calendarId: 'cal-shift',
    title: '早番 (病棟A)',
    date: getOffsetDate(0),
    startTime: '07:30',
    endTime: '16:15',
    isAllDay: false,
    memberIds: ['user-takuma'],
    color: '#059669',
    category: 'シフト',
    shiftType: '早番',
    notes: '引き継ぎ業務あり。16:15退勤予定。',
  },
  {
    id: 'evt-3',
    calendarId: 'cal-shift',
    title: '夜勤入り 🏥',
    date: getOffsetDate(3),
    startTime: '16:30',
    endTime: '23:59',
    isAllDay: false,
    memberIds: ['user-takuma'],
    color: '#7C3AED',
    category: 'シフト',
    shiftType: '夜勤',
    notes: '夜勤スタート。翌日09:30明け。',
  },
  {
    id: 'evt-4',
    calendarId: 'cal-couple',
    title: '映画鑑賞 🎬',
    date: getOffsetDate(5),
    startTime: '19:30',
    endTime: '22:00',
    isAllDay: false,
    memberIds: ['user-takuma', 'user-aoi'],
    color: '#EC4899',
    category: 'デート',
    location: 'TOHOシネマズ 新宿',
    locationCoords: { lat: 35.6953, lng: 139.7022 },
    notes: '席はスクリーン中央J列で予約済み。',
    checklist: [
      { id: 'chk-3', text: 'ポップコーンの味決める', done: true },
      { id: 'chk-4', text: '発券QRコード保存', done: true },
    ],
  },
  {
    id: 'evt-5',
    calendarId: 'cal-couple',
    title: 'ふたりの記念日ディナー 🥂',
    date: getOffsetDate(8),
    startTime: '18:30',
    endTime: '21:00',
    isAllDay: false,
    memberIds: ['user-takuma', 'user-aoi'],
    color: '#DC2626',
    category: '記念日',
    location: '恵比寿 ガーデンプレイス周辺レストラン',
    locationCoords: { lat: 35.6425, lng: 139.7135 },
    notes: 'コース予約完了。サプライズデザートプレート手配済み！',
  },
  {
    id: 'evt-6',
    calendarId: 'cal-travel',
    title: '週末温泉旅行 ♨️ 草津温泉',
    date: getOffsetDate(14),
    endDate: getOffsetDate(15),
    isAllDay: true,
    memberIds: ['user-takuma', 'user-aoi'],
    color: '#0284C7',
    category: '旅行',
    location: '草津温泉 湯畑',
    locationCoords: { lat: 36.6226, lng: 138.5962 },
    notes: '特急草津・四万号のチケット手配完了。湯畑散策と露天風呂を満喫！',
  },
];

const DEFAULT_PINNED_PLACES: PinnedPlace[] = [
  {
    id: 'pin-1',
    calendarId: 'cal-travel',
    name: 'チームラボプラネッツ TOKYO',
    category: 'sightseeing',
    lat: 35.6517,
    lng: 139.7892,
    address: '東京都江東区豊洲6-1-16',
    notes: '水に入る没入型ミュージアム。膝までまくれる服装で行く！',
    targetDate: getOffsetDate(20),
    isVisited: false,
    createdBy: 'たくま',
    rating: 5,
    budget: '約¥3,800/人',
    url: 'https://planets.teamlab.art/tokyo/ja/',
    imageUrl: 'https://upload.wikimedia.org/wikipedia/commons/thumb/6/69/TeamLab_Planets_Tokyo_2018.jpg/800px-TeamLab_Planets_Tokyo_2018.jpg',
  },
  {
    id: 'pin-2',
    calendarId: 'cal-couple',
    name: 'ブルーボトルコーヒー 清澄白河フラッグシップ',
    category: 'cafe',
    lat: 35.6795,
    lng: 139.7998,
    address: '東京都江東区平野1-4-8',
    notes: 'ロースタリー併設の開放的なカフェ。シングルオリジンとワッフルが絶品。',
    isVisited: true,
    createdBy: 'あおい',
    rating: 5,
    budget: '約¥1,200',
    imageUrl: 'https://images.unsplash.com/photo-1554118811-1e0d58224f24?auto=format&fit=crop&w=800&q=80',
  },
  {
    id: 'pin-3',
    calendarId: 'cal-travel',
    name: 'SHIBUYA SKY (渋谷スカイ)',
    category: 'sightseeing',
    lat: 35.6591,
    lng: 139.7006,
    address: '東京都渋谷区渋谷2-24-12 渋谷スクランブルスクエア',
    notes: '地上229mの展望空間。日没の30分前入場がマジックアワーで一番おすすめ！',
    isVisited: false,
    createdBy: 'たくま',
    rating: 5,
    budget: '約¥2,200',
    imageUrl: 'https://upload.wikimedia.org/wikipedia/commons/thumb/d/db/Shibuya_Scramble_Crossing_2018.jpg/800px-Shibuya_Scramble_Crossing_2018.jpg',
  },
  {
    id: 'pin-4',
    calendarId: 'cal-couple',
    name: 'bills お台場',
    category: 'gourmet',
    lat: 35.6285,
    lng: 139.7758,
    address: '東京都港区台場1-6-1 デックス東京ビーチ シーサイドモール3F',
    notes: 'レインボーブリッジが見えるテラス席でリコッタパンケーキ。',
    isVisited: false,
    createdBy: 'あおい',
    rating: 4,
    budget: '約¥2,500',
    imageUrl: 'https://images.unsplash.com/photo-1567620905732-2d1ec7ab7445?auto=format&fit=crop&w=800&q=80',
  },
  {
    id: 'pin-5',
    calendarId: 'cal-travel',
    name: '草津温泉 湯畑',
    category: 'stay',
    lat: 36.6226,
    lng: 138.5962,
    address: '群馬県吾妻郡草津町草津',
    notes: '湯けむりが立ち込めるシンボル。夜のライトアップが幻想的。',
    isVisited: false,
    createdBy: 'たくま',
    rating: 5,
    budget: '約¥30,000',
    imageUrl: 'https://upload.wikimedia.org/wikipedia/commons/thumb/8/87/Kusatsu_Onsen_Yubatake_2018.jpg/800px-Kusatsu_Onsen_Yubatake_2018.jpg',
  },
  {
    id: 'pin-6',
    calendarId: 'cal-couple',
    name: '東京タワー (Tokyo Tower)',
    category: 'sightseeing',
    lat: 35.6586,
    lng: 139.7454,
    address: '東京都港区芝公園4-2-8',
    notes: '高さ333mの東京のシンボルタワー。大展望台からの夜景が見事。',
    isVisited: false,
    createdBy: 'たくま',
    rating: 5,
    budget: '約¥1,200',
    imageUrl: 'https://upload.wikimedia.org/wikipedia/commons/thumb/3/37/Tokyo_Tower_and_around_Skyscrapers.jpg/800px-Tokyo_Tower_and_around_Skyscrapers.jpg',
  },
];

const STORAGE_KEYS = {
  CALENDARS: 'timeshare_calendars_v1',
  EVENTS: 'timeshare_events_v1',
  PLACES: 'timeshare_places_v1',
  ACTIVE_CAL_ID: 'timeshare_active_cal_id',
  ACTIVE_MEMBER_ID: 'timeshare_active_member_id',
  SHIFT_RULES: 'timeshare_shift_rules_v1',
  ROSTER_PROFILES: 'timeshare_roster_profiles_v1',
  ACTIVE_ROSTER_PROFILE_ID: 'timeshare_active_roster_profile_id_v1',
};

export const DEFAULT_SHIFT_RULES: CustomShiftRule[] = [
  { id: 'rule-day', symbol: '日', name: '日勤', startTime: '08:30', endTime: '17:15', isDayOff: false, color: '#10B981', note: '通常日勤' },
  { id: 'rule-early', symbol: '早', name: '早番', startTime: '07:00', endTime: '15:45', isDayOff: false, color: '#F59E0B', note: '朝礼・開錠担当' },
  { id: 'rule-late', symbol: '遅', name: '遅番', startTime: '13:00', endTime: '21:45', isDayOff: false, color: '#EA580C', note: '施錠・締め作業' },
  { id: 'rule-semi-night', symbol: '準', name: '準夜勤', startTime: '16:00', endTime: '00:30', isDayOff: false, color: '#8B5CF6', note: '3交代準夜' },
  { id: 'rule-deep-night', symbol: '深', name: '深夜勤', startTime: '00:00', endTime: '08:30', isDayOff: false, color: '#4C1D95', note: '3交代深夜' },
  { id: 'rule-night', symbol: '夜', name: '夜勤', startTime: '16:30', endTime: '09:30', isDayOff: false, color: '#6D28D9', note: '2交代夜勤 (翌朝明け)' },
  { id: 'rule-on-duty', symbol: '当', name: '当直', startTime: '17:00', endTime: '09:00', isDayOff: false, color: '#2563EB', note: '当直業務' },
  { id: 'rule-off-1', symbol: '休', name: '公休', isDayOff: true, color: '#F43F5E', note: '休日' },
  { id: 'rule-off-2', symbol: '○', name: '公休', isDayOff: true, color: '#F43F5E', note: '丸印は休み' },
  { id: 'rule-paid-leave', symbol: '有', name: '有給休暇', isDayOff: true, color: '#EC4899', note: '有給取得' },
];

export const PARTNER_DEFAULT_SHIFT_RULES: CustomShiftRule[] = [
  { id: 'p-rule-early', symbol: '早', name: '早番', startTime: '09:00', endTime: '17:00', isDayOff: false, color: '#F59E0B', note: 'オープン・早番' },
  { id: 'p-rule-mid', symbol: '中', name: '中番', startTime: '11:00', endTime: '19:30', isDayOff: false, color: '#10B981', note: 'ピークタイム担当' },
  { id: 'p-rule-late', symbol: '遅', name: '遅番', startTime: '13:30', endTime: '22:00', isDayOff: false, color: '#EA580C', note: 'クローズ・締め' },
  { id: 'p-rule-a', symbol: 'A', name: 'A勤 (朝)', startTime: '08:30', endTime: '16:30', isDayOff: false, color: '#0284C7', note: 'Aシフト' },
  { id: 'p-rule-b', symbol: 'B', name: 'B勤 (夕)', startTime: '12:00', endTime: '20:30', isDayOff: false, color: '#7C3AED', note: 'Bシフト' },
  { id: 'p-rule-off1', symbol: '休', name: '公休', isDayOff: true, color: '#F43F5E', note: 'シフト休み' },
  { id: 'p-rule-off2', symbol: '公', name: '公休', isDayOff: true, color: '#F43F5E', note: '公休日' },
  { id: 'p-rule-paid', symbol: '有', name: '有給休暇', isDayOff: true, color: '#EC4899', note: '有給' },
];

export const DEFAULT_ROSTER_PROFILES: ShiftRosterProfile[] = [
  {
    id: 'roster-user-takuma',
    name: 'たくまのシフト表',
    memberId: 'user-takuma',
    targetPersonName: '',
    description: 'ユーザー1 (たくま) 用のシフト表ルール設定',
    rules: DEFAULT_SHIFT_RULES,
  },
  {
    id: 'roster-user-aoi',
    name: 'あおいのシフト表',
    memberId: 'user-aoi',
    targetPersonName: '',
    description: 'ユーザー2 (あおい) 用のシフト表ルール設定',
    rules: PARTNER_DEFAULT_SHIFT_RULES,
  },
];

export function loadRosterProfiles(): ShiftRosterProfile[] {
  try {
    const data = localStorage.getItem(STORAGE_KEYS.ROSTER_PROFILES);
    if (data) {
      const parsed = JSON.parse(data);
      if (Array.isArray(parsed) && parsed.length > 0) {
        return parsed;
      }
    }
    // Migrate existing legacy single custom rules into the first profile if present
    const legacyRules = localStorage.getItem(STORAGE_KEYS.SHIFT_RULES);
    if (legacyRules) {
      const parsedLegacy = JSON.parse(legacyRules);
      if (Array.isArray(parsedLegacy) && parsedLegacy.length > 0) {
        return [
          {
            ...DEFAULT_ROSTER_PROFILES[0],
            rules: parsedLegacy,
          },
          DEFAULT_ROSTER_PROFILES[1],
        ];
      }
    }
    return DEFAULT_ROSTER_PROFILES;
  } catch {
    return DEFAULT_ROSTER_PROFILES;
  }
}

export function saveRosterProfiles(profiles: ShiftRosterProfile[]) {
  try {
    localStorage.setItem(STORAGE_KEYS.ROSTER_PROFILES, JSON.stringify(profiles));
  } catch (err) {
    console.error('Failed to save roster profiles:', err);
  }
}

export function loadActiveRosterProfileId(): string {
  return localStorage.getItem(STORAGE_KEYS.ACTIVE_ROSTER_PROFILE_ID) || DEFAULT_ROSTER_PROFILES[0].id;
}

export function saveActiveRosterProfileId(id: string) {
  try {
    localStorage.setItem(STORAGE_KEYS.ACTIVE_ROSTER_PROFILE_ID, id);
  } catch (err) {
    console.error('Failed to save active roster profile id:', err);
  }
}

export function loadCustomShiftRules(): CustomShiftRule[] {
  try {
    const data = localStorage.getItem(STORAGE_KEYS.SHIFT_RULES);
    return data ? JSON.parse(data) : DEFAULT_SHIFT_RULES;
  } catch {
    return DEFAULT_SHIFT_RULES;
  }
}

export function saveCustomShiftRules(rules: CustomShiftRule[]) {
  try {
    localStorage.setItem(STORAGE_KEYS.SHIFT_RULES, JSON.stringify(rules));
  } catch (err) {
    console.error('Failed to save shift rules:', err);
  }
}

export function loadCalendars(): SharedCalendar[] {
  try {
    const data = localStorage.getItem(STORAGE_KEYS.CALENDARS);
    return data ? JSON.parse(data) : DEFAULT_CALENDARS;
  } catch {
    return DEFAULT_CALENDARS;
  }
}

export function saveCalendars(calendars: SharedCalendar[]) {
  try {
    localStorage.setItem(STORAGE_KEYS.CALENDARS, JSON.stringify(calendars));
  } catch (err) {
    console.error('Failed to save calendars:', err);
  }
}

export function loadEvents(): CalendarEvent[] {
  try {
    const data = localStorage.getItem(STORAGE_KEYS.EVENTS);
    return data ? JSON.parse(data) : DEFAULT_EVENTS;
  } catch {
    return DEFAULT_EVENTS;
  }
}

export function saveEvents(events: CalendarEvent[]) {
  try {
    localStorage.setItem(STORAGE_KEYS.EVENTS, JSON.stringify(events));
  } catch (err) {
    console.error('Failed to save events:', err);
  }
}

export function loadPinnedPlaces(): PinnedPlace[] {
  try {
    const data = localStorage.getItem(STORAGE_KEYS.PLACES);
    return data ? JSON.parse(data) : DEFAULT_PINNED_PLACES;
  } catch {
    return DEFAULT_PINNED_PLACES;
  }
}

export function savePinnedPlaces(places: PinnedPlace[]) {
  try {
    localStorage.setItem(STORAGE_KEYS.PLACES, JSON.stringify(places));
  } catch (err) {
    console.error('Failed to save places:', err);
  }
}

export function loadActiveCalendarId(): string {
  return localStorage.getItem(STORAGE_KEYS.ACTIVE_CAL_ID) || 'cal-couple';
}

export function saveActiveCalendarId(id: string) {
  localStorage.setItem(STORAGE_KEYS.ACTIVE_CAL_ID, id);
}

export function loadActiveMemberId(): string {
  return localStorage.getItem(STORAGE_KEYS.ACTIVE_MEMBER_ID) || CURRENT_USER.id;
}

export function saveActiveMemberId(id: string) {
  localStorage.setItem(STORAGE_KEYS.ACTIVE_MEMBER_ID, id);
}
