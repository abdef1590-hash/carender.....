// Generates realistic Japanese roster/shift table images as base64 JPEG/PNG for instant AI testing

export interface SampleRosterPreset {
  id: string;
  name: string;
  role: string;
  targetPerson: string;
  description: string;
  base64Data: string;
}

// Generate an SVG-based simulated shift roster rendered as Data URL
function generateRosterDataUrl(
  title: string,
  targetPerson: string,
  monthStr: string,
  rows: { name: string; shifts: string[] }[]
): string {
  const daysInMonth = 15; // 15 days visible table for clear OCR
  const daysHeader = Array.from({ length: daysInMonth }, (_, i) => i + 1);
  const weekdays = ['木', '金', '土', '日', '月', '火', '水', '木', '金', '土', '日', '月', '火', '水', '木'];

  const svg = `
  <svg xmlns="http://www.w3.org/2000/svg" width="900" height="520" viewBox="0 0 900 520" style="background:#ffffff; font-family:'Hiragino Kaku Gothic ProN', Meiryo, sans-serif;">
    <rect width="900" height="520" fill="#f8fafc"/>
    <!-- Header -->
    <rect x="20" y="20" width="860" height="60" rx="8" fill="#1e293b"/>
    <text x="40" y="58" fill="#ffffff" font-size="22" font-weight="bold">${title} (${monthStr})</text>
    <text x="680" y="58" fill="#94a3b8" font-size="14">作成日: 2026/09/25</text>

    <!-- Legend -->
    <rect x="20" y="90" width="860" height="36" fill="#f1f5f9" rx="4"/>
    <text x="35" y="113" fill="#334155" font-size="12" font-weight="bold">【勤務区分】日: 日勤 (8:30-17:15) / 早: 早番 (7:00-15:45) / 遅: 遅番 (13:00-21:45) / 夜: 夜勤 (16:30-翌9:30) / 休: 公休</text>

    <!-- Table Header -->
    <rect x="20" y="135" width="860" height="50" fill="#e2e8f0"/>
    <text x="35" y="165" fill="#1e293b" font-size="13" font-weight="bold">氏名</text>
    ${daysHeader
      .map((d, i) => {
        const x = 120 + i * 49;
        const isSun = weekdays[i] === '日';
        const isSat = weekdays[i] === '土';
        const color = isSun ? '#dc2626' : isSat ? '#2563eb' : '#1e293b';
        return `
        <text x="${x + 12}" y="156" fill="${color}" font-size="13" font-weight="bold" text-anchor="middle">${d}</text>
        <text x="${x + 12}" y="174" fill="${color}" font-size="11" text-anchor="middle">(${weekdays[i]})</text>
      `;
      })
      .join('')}

    <!-- Table Rows -->
    ${rows
      .map((row, rIdx) => {
        const y = 190 + rIdx * 55;
        const isTarget = row.name === targetPerson;
        const bg = isTarget ? '#eff6ff' : rIdx % 2 === 0 ? '#ffffff' : '#f8fafc';
        const borderStroke = isTarget ? '#3b82f6' : '#cbd5e1';
        const strokeWidth = isTarget ? '2' : '1';

        return `
        <rect x="20" y="${y}" width="860" height="50" fill="${bg}" stroke="${borderStroke}" stroke-width="${strokeWidth}"/>
        <text x="35" y="${y + 30}" fill="${isTarget ? '#1d4ed8' : '#1e293b'}" font-size="14" font-weight="${isTarget ? 'bold' : 'normal'}">
          ${row.name}${isTarget ? ' ★' : ''}
        </text>
        ${row.shifts
          .map((shift, cIdx) => {
            const x = 120 + cIdx * 49;
            let shiftBg = '#f1f5f9';
            let shiftColor = '#334155';
            if (shift === '日') { shiftBg = '#dcfce7'; shiftColor = '#15803d'; }
            else if (shift === '早') { shiftBg = '#fef9c3'; shiftColor = '#a16207'; }
            else if (shift === '遅') { shiftBg = '#ffedd5'; shiftColor = '#c2410c'; }
            else if (shift === '夜') { shiftBg = '#ede9fe'; shiftColor = '#6d28d9'; }
            else if (shift === '休') { shiftBg = '#fee2e2'; shiftColor = '#b91c1c'; }

            return `
            <rect x="${x}" y="${y + 8}" width="42" height="34" rx="4" fill="${shiftBg}"/>
            <text x="${x + 21}" y="${y + 30}" fill="${shiftColor}" font-size="15" font-weight="bold" text-anchor="middle">${shift}</text>
          `;
          })
          .join('')}
      `;
      })
      .join('')}
  </svg>
  `;

  // Encode SVG as Base64 data URL
  const base64 = btoa(unescape(encodeURIComponent(svg)));
  return `data:image/svg+xml;base64,${base64}`;
}

export const SAMPLE_ROSTERS: SampleRosterPreset[] = [
  {
    id: 'nurse-ward-august',
    name: '総合病院 8月度病棟勤務表',
    role: '医療・看護師 (2交代・8月)',
    targetPerson: '佐藤',
    description: '2026年8月度。日勤・早番・遅番・夜勤・公休の看護シフト表（8月検証用）',
    base64Data: generateRosterDataUrl('東病棟 8月度 勤務割振表', '佐藤', '2026年8月', [
      { name: '佐藤', shifts: ['日', '早', '遅', '休', '日', '夜', '休', '日', '早', '休', '遅', '夜', '休', '日', '日'] },
      { name: '田中ナース', shifts: ['夜', '休', '日', '早', '休', '遅', '日', '夜', '休', '日', '日', '早', '遅', '休', '日'] },
      { name: '高橋ナース', shifts: ['休', '遅', '夜', '休', '日', '日', '早', '休', '夜', '休', '日', '日', '休', '早', '遅'] },
      { name: '鈴木師長', shifts: ['日', '日', '日', '休', '日', '日', '休', '日', '日', '日', '休', '日', '日', '休', '休'] },
    ]),
  },
  {
    id: 'nurse-ward',
    name: '総合病院 病棟勤務表 (10月)',
    role: '医療・看護師 (2交代制)',
    targetPerson: '佐藤主任',
    description: '日勤・早番・遅番・夜勤・公休が入り混じるリアルな看護シフト表',
    base64Data: generateRosterDataUrl('東病棟 10月度 勤務割振表', '佐藤主任', '2026年10月', [
      { name: '佐藤主任', shifts: ['日', '日', '日', '休', '日', '日', '休', '日', '日', '日', '休', '日', '日', '休', '休'] },
      { name: '田中ナース', shifts: ['夜', '休', '日', '早', '休', '遅', '日', '夜', '休', '日', '日', '早', '遅', '休', '日'] },
      { name: 'たくま', shifts: ['日', '早', '遅', '休', '日', '夜', '休', '日', '早', '休', '遅', '夜', '休', '日', '日'] },
      { name: '小林ナース', shifts: ['休', '遅', '夜', '休', '日', '日', '早', '休', '夜', '休', '日', '日', '休', '早', '遅'] },
    ]),
  },
  {
    id: 'restaurant-parttime',
    name: 'カフェ＆飲食店 シフト表',
    role: '飲食・アルバイト',
    targetPerson: '店長',
    description: 'ランチ帯(早番)やディナー帯(遅番)、土日出勤のバイトシフト表',
    base64Data: generateRosterDataUrl('カフェダイニング 8月度シフト表', '店長', '2026年8月', [
      { name: '店長', shifts: ['日', '日', '日', '日', '休', '日', '日', '休', '日', '日', '日', '日', '休', '日', '日'] },
      { name: 'たくま', shifts: ['早', '休', '遅', '遅', '休', '早', '早', '休', '遅', '休', '早', '遅', '遅', '休', '早'] },
      { name: '鈴木バイト', shifts: ['休', '遅', '休', '早', '遅', '休', '遅', '遅', '休', '早', '休', '休', '遅', '早', '休'] },
      { name: '高橋バイト', shifts: ['遅', '休', '早', '休', '早', '遅', '休', '休', '早', '遅', '遅', '休', '早', '休', '遅'] },
    ]),
  },
  {
    id: 'factory-shift',
    name: '製造・物流 3交代シフト表',
    role: '工場・交代制勤務',
    targetPerson: '伊藤リーダー',
    description: '1直(朝)・2直(夕)・3直(深夜)の規則正しい交代勤務スケジュール',
    base64Data: generateRosterDataUrl('製造ライン第2 交代表', '伊藤リーダー', '2026年8月', [
      { name: '伊藤リーダー', shifts: ['遅', '遅', '遅', '遅', '休', '夜', '夜', '夜', '夜', '休', '早', '早', '早', '早', '休'] },
      { name: '渡辺オペレーター', shifts: ['夜', '夜', '夜', '夜', '休', '早', '早', '早', '早', '休', '遅', '遅', '遅', '遅', '休'] },
      { name: 'たくま', shifts: ['早', '早', '早', '早', '休', '遅', '遅', '遅', '遅', '休', '夜', '夜', '夜', '夜', '休'] },
    ]),
  },
];
