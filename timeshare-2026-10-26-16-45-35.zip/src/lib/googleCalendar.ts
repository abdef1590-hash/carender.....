import { CalendarEvent } from '../types';

export interface GoogleCalendarEventItem {
  id: string;
  summary: string;
  description?: string;
  location?: string;
  start: {
    dateTime?: string;
    date?: string;
    timeZone?: string;
  };
  end: {
    dateTime?: string;
    date?: string;
    timeZone?: string;
  };
}

// Fetch list of upcoming events from user's primary Google Calendar
export async function fetchGoogleCalendarEvents(
  accessToken: string,
  timeMin?: string
): Promise<GoogleCalendarEventItem[]> {
  const minTime = timeMin || new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString();
  const maxTime = new Date(Date.now() + 180 * 24 * 60 * 60 * 1000).toISOString();

  const url = new URL('https://www.googleapis.com/calendar/v3/calendars/primary/events');
  url.searchParams.set('timeMin', minTime);
  url.searchParams.set('timeMax', maxTime);
  url.searchParams.set('singleEvents', 'true');
  url.searchParams.set('orderBy', 'startTime');
  url.searchParams.set('maxResults', '150');

  const res = await fetch(url.toString(), {
    headers: {
      Authorization: `Bearer ${accessToken}`,
      Accept: 'application/json',
    },
  });

  if (!res.ok) {
    const errorData = await res.json().catch(() => ({}));
    throw new Error(
      errorData.error?.message || `Googleカレンダー取得エラー (${res.status})`
    );
  }

  const data = await res.json();
  return (data.items || []) as GoogleCalendarEventItem[];
}

// Convert Google Event to internal CalendarEvent format
export function convertGoogleEventToLocal(
  gEvent: GoogleCalendarEventItem,
  calendarId: string,
  memberId: string
): CalendarEvent {
  const isAllDay = !gEvent.start.dateTime && !!gEvent.start.date;
  const dateStr = (gEvent.start.dateTime?.substring(0, 10) || gEvent.start.date) || new Date().toISOString().substring(0, 10);
  
  let startTime = '';
  let endTime = '';

  if (gEvent.start.dateTime) {
    const d = new Date(gEvent.start.dateTime);
    startTime = `${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`;
  }
  if (gEvent.end.dateTime) {
    const d = new Date(gEvent.end.dateTime);
    endTime = `${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`;
  }

  return {
    id: `google-${gEvent.id}`,
    calendarId,
    title: gEvent.summary || '(タイトルなし)',
    date: dateStr,
    startTime: isAllDay ? undefined : startTime,
    endTime: isAllDay ? undefined : endTime,
    isAllDay,
    memberIds: [memberId],
    color: '#4285F4', // Google Blue
    category: 'その他',
    location: gEvent.location || '',
    notes: gEvent.description || '',
    isGoogleSynced: true,
    googleEventId: gEvent.id,
  };
}

// Push local event to Google Calendar
export async function pushEventToGoogleCalendar(
  accessToken: string,
  event: CalendarEvent
): Promise<{ id: string }> {
  const url = 'https://www.googleapis.com/calendar/v3/calendars/primary/events';

  const body: any = {
    summary: event.title,
    description: [
      event.notes || '',
      event.checklist && event.checklist.length > 0
        ? '\n【チェックリスト】\n' + event.checklist.map((c) => `- [${c.done ? 'x' : ' '}] ${c.text}`).join('\n')
        : '',
      '\n(TimeShare共有カレンダーより同期)',
    ].filter(Boolean).join('\n'),
    location: event.location || undefined,
  };

  if (event.isAllDay) {
    body.start = { date: event.date };
    // Google Calendar API requires end date to be the day AFTER for all-day events
    const endDate = new Date(event.date);
    endDate.setDate(endDate.getDate() + 1);
    body.end = { date: endDate.toISOString().substring(0, 10) };
  } else {
    const startStr = `${event.date}T${event.startTime || '09:00'}:00`;
    const endStr = `${event.date}T${event.endTime || '10:00'}:00`;
    const timeZone = Intl.DateTimeFormat().resolvedOptions().timeZone || 'Asia/Tokyo';

    body.start = { dateTime: new Date(startStr).toISOString(), timeZone };
    body.end = { dateTime: new Date(endStr).toISOString(), timeZone };
  }

  const res = await fetch(url, {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${accessToken}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(body),
  });

  if (!res.ok) {
    const errorData = await res.json().catch(() => ({}));
    throw new Error(
      errorData.error?.message || `Googleカレンダー登録失敗 (${res.status})`
    );
  }

  const data = await res.json();
  return { id: data.id };
}
