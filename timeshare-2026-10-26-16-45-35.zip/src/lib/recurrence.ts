import { CalendarEvent, RecurrenceRule } from '../types';

function addDaysToDateStr(dateStr: string, daysToAdd: number): string {
  const [y, m, d] = dateStr.split('-').map(Number);
  if (!y || !m || !d) return dateStr;
  const dt = new Date(y, m - 1, d);
  dt.setDate(dt.getDate() + daysToAdd);
  const ny = dt.getFullYear();
  const nm = String(dt.getMonth() + 1).padStart(2, '0');
  const nd = String(dt.getDate()).padStart(2, '0');
  return `${ny}-${nm}-${nd}`;
}

function getDaySpan(startDateStr: string, endDateStr?: string): number {
  if (!endDateStr || endDateStr <= startDateStr) return 0;
  const [sy, sm, sd] = startDateStr.split('-').map(Number);
  const [ey, em, ed] = endDateStr.split('-').map(Number);
  if (!sy || !sm || !sd || !ey || !em || !ed) return 0;
  const s = new Date(sy, sm - 1, sd);
  const e = new Date(ey, em - 1, ed);
  const diff = Math.round((e.getTime() - s.getTime()) / (1000 * 60 * 60 * 24));
  return diff > 0 ? diff : 0;
}

/**
 * Generates an array of CalendarEvent instances based on a base event and its RecurrenceRule.
 * Preserves multi-day span (endDate) if the base event spans across days.
 */
export function generateRecurringEvents(
  baseEvent: CalendarEvent,
  rule: RecurrenceRule
): CalendarEvent[] {
  if (!rule || rule.frequency === 'none') {
    return [baseEvent];
  }

  const events: CalendarEvent[] = [];
  const groupId =
    baseEvent.recurringGroupId ||
    `rec-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`;

  const [startY, startM, startD] = baseEvent.date.split('-').map(Number);
  if (!startY || !startM || !startD) return [baseEvent];

  const daySpan = getDaySpan(baseEvent.date, baseEvent.endDate);
  const startDate = new Date(startY, startM - 1, startD);
  const interval = rule.interval && rule.interval > 0 ? rule.interval : 1;

  const maxInstances = rule.endType === 'count' ? rule.endCount || 10 : 52;
  const limitDate =
    rule.endType === 'until_date' && rule.endDate
      ? new Date(rule.endDate + 'T23:59:59')
      : new Date(startDate.getFullYear() + 1, startDate.getMonth(), startDate.getDate());

  let count = 0;
  let currDate = new Date(startDate);

  while (count < maxInstances && currDate <= limitDate) {
    const year = currDate.getFullYear();
    const month = String(currDate.getMonth() + 1).padStart(2, '0');
    const day = String(currDate.getDate()).padStart(2, '0');
    const formattedDate = `${year}-${month}-${day}`;
    const computedEndDate =
      daySpan > 0 ? addDaysToDateStr(formattedDate, daySpan) : undefined;

    events.push({
      ...baseEvent,
      id:
        count === 0
          ? baseEvent.id
          : `evt-rec-${Date.now()}-${count}-${Math.random().toString(36).substring(2, 5)}`,
      date: formattedDate,
      endDate: computedEndDate,
      recurringGroupId: groupId,
      recurrenceRule: rule,
    });

    count++;

    switch (rule.frequency) {
      case 'daily':
        currDate.setDate(currDate.getDate() + interval);
        break;
      case 'weekly':
        currDate.setDate(currDate.getDate() + 7 * interval);
        break;
      case 'biweekly':
        currDate.setDate(currDate.getDate() + 14 * interval);
        break;
      case 'monthly':
        currDate.setMonth(currDate.getMonth() + interval);
        break;
      case 'yearly':
        currDate.setFullYear(currDate.getFullYear() + interval);
        break;
      case 'custom':
        currDate.setDate(currDate.getDate() + interval);
        break;
      default:
        currDate.setDate(currDate.getDate() + 7 * interval);
        break;
    }
  }

  return events;
}

/**
 * Generates an array of CalendarEvent instances for multiple selected dates.
 * Preserves multi-day span (endDate) if the base event spans across days.
 */
export function generateMultiDateEvents(
  baseEvent: CalendarEvent,
  dates: string[]
): CalendarEvent[] {
  if (!dates || dates.length === 0) return [baseEvent];

  const groupId = `bulk-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`;
  const daySpan = getDaySpan(baseEvent.date, baseEvent.endDate);

  return dates.map((d, index) => ({
    ...baseEvent,
    id:
      index === 0
        ? baseEvent.id
        : `evt-bulk-${Date.now()}-${index}-${Math.random().toString(36).substring(2, 5)}`,
    date: d,
    endDate: daySpan > 0 ? addDaysToDateStr(d, daySpan) : undefined,
    recurringGroupId: groupId,
  }));
}
