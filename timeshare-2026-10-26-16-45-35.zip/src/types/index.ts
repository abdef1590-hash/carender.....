export type EventCategory =
  | '仕事'
  | 'プライベート'
  | 'デート'
  | '旅行'
  | 'シフト'
  | '記念日'
  | '病院'
  | 'その他';

export interface Member {
  id: string;
  name: string;
  avatarUrl: string;
  color: string;
  role: 'owner' | 'member';
  email?: string;
  password?: string;
  isPasswordProtected?: boolean;
  jobTitle?: string;
}

export interface ChecklistItem {
  id: string;
  text: string;
  done: boolean;
}

export interface EventComment {
  id: string;
  memberId: string;
  memberName: string;
  memberAvatar?: string;
  text: string;
  createdAt: string;
}

export type RecurrenceFrequency =
  | 'none'
  | 'daily'
  | 'weekly'
  | 'biweekly'
  | 'monthly'
  | 'yearly'
  | 'custom';

export interface RecurrenceRule {
  frequency: RecurrenceFrequency;
  interval?: number;
  daysOfWeek?: number[];
  endType: 'count' | 'until_date' | 'never';
  endDate?: string;
  endCount?: number;
}

export interface CalendarEvent {
  id: string;
  calendarId: string;
  title: string;
  date: string; // YYYY-MM-DD
  endDate?: string;
  startTime?: string; // HH:mm
  endTime?: string; // HH:mm
  isAllDay: boolean;
  memberIds: string[];
  color: string;
  category: EventCategory;
  location?: string;
  locationCoords?: { lat: number; lng: number };
  notes?: string;
  checklist?: ChecklistItem[];
  comments?: EventComment[];
  isGoogleSynced?: boolean;
  googleEventId?: string;
  shiftType?: string;
  recurrenceRule?: RecurrenceRule;
  recurringGroupId?: string;
}

export interface SharedCalendar {
  id: string;
  name: string;
  description: string;
  color: string;
  emoji: string;
  inviteCode: string;
  isDefault?: boolean;
  members: Member[];
}

export type PlaceCategory =
  | 'gourmet'
  | 'cafe'
  | 'sightseeing'
  | 'shopping'
  | 'stay'
  | 'nature'
  | 'other';

export interface PinnedPlace {
  id: string;
  calendarId: string;
  name: string;
  category: PlaceCategory;
  lat: number;
  lng: number;
  address: string;
  notes?: string;
  targetDate?: string;
  isVisited: boolean;
  createdBy: string;
  rating?: number;
  budget?: string;
  url?: string;
  imageUrl?: string;
}

export interface CustomShiftRule {
  id: string;
  symbol: string; // 記号・文字 (例: "準", "深", "日", "○", "A")
  name: string; // シフト名 (例: "準夜勤", "深夜勤", "日勤", "公休")
  startTime?: string; // "16:00"
  endTime?: string; // "00:30"
  isDayOff: boolean;
  color: string;
  note?: string;
}

export interface ShiftRosterProfile {
  id: string;
  name: string; // シフト表の名前 (例: "たくまのシフト表", "あおいのシフト表")
  memberId: string; // 紐づくメンバーID (例: "user-takuma", "user-aoi")
  targetPersonName?: string; // 表内の検索氏名 (例: "佐藤", "田中")
  description?: string; // 職場・シフト表の説明
  rules: CustomShiftRule[];
}

export interface ShiftEntry {
  date: string;
  shiftType: string;
  rawSymbol?: string;
  startTime?: string;
  endTime?: string;
  isDayOff: boolean;
  note?: string;
}

export interface StaffRosterMap {
  [personName: string]: ShiftEntry[];
}

export interface ShiftParseResult {
  personName?: string;
  yearMonth?: string;
  shifts: ShiftEntry[];
  summary?: string;
  detectedStaffNames?: string[];
  allStaffShifts?: StaffRosterMap;
  extractedRules?: CustomShiftRule[];
}

export interface WeatherCurrent {
  temp: number;
  apparentTemp: number;
  humidity: number;
  windSpeed: number;
  precipitation: number;
  weatherLabel: string;
  emoji: string;
  condition: string;
}

export interface WeatherForecastDay {
  date: string;
  maxTemp: number;
  minTemp: number;
  rainProb: number;
  rainSum: number;
  maxWind: number;
  weatherLabel: string;
  emoji: string;
}

export interface DisasterAlert {
  level: 'safe' | 'caution' | 'warning' | 'emergency';
  title: string;
  desc: string;
}

export interface PlaceWeatherDisaster {
  placeName: string;
  current: WeatherCurrent;
  forecast: WeatherForecastDay[];
  disaster: {
    overallStatus: 'safe' | 'caution' | 'warning' | 'emergency';
    isSafe: boolean;
    alerts: DisasterAlert[];
    summaryMessage: string;
  };
}
