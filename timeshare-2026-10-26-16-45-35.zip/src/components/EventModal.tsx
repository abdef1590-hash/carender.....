import React, { useState, useEffect } from 'react';
import {
  Calendar as CalendarIcon,
  Clock,
  MapPin,
  CheckSquare,
  MessageCircle,
  Users,
  Trash2,
  Send,
  Plus,
  Repeat,
  Layers,
  ArrowRight,
  AlertCircle,
  MoreVertical,
  Edit3,
  Copy,
  FileText,
  ChevronLeft,
  ChevronRight,
  Check,
} from 'lucide-react';
import {
  CalendarEvent,
  EventCategory,
  Member,
  SharedCalendar,
  ChecklistItem,
  EventComment,
  RecurrenceFrequency,
  RecurrenceRule,
} from '../types';
import { generateRecurringEvents, generateMultiDateEvents } from '../lib/recurrence';

interface EventModalProps {
  isOpen: boolean;
  onClose: () => void;
  event: Partial<CalendarEvent> | null;
  calendars: SharedCalendar[];
  activeCalendarId: string;
  members: Member[];
  currentMember: Member;
  onSaveEvent: (event: CalendarEvent | CalendarEvent[], syncToGoogle?: boolean) => Promise<void>;
  onDeleteEvent?: (id: string, recurringGroupId?: string) => void;
  isGoogleConnected?: boolean;
}

const CATEGORIES: { label: EventCategory; color: string }[] = [
  { label: 'デート', color: '#EC4899' },
  { label: '旅行', color: '#0284C7' },
  { label: '記念日', color: '#DC2626' },
  { label: 'プライベート', color: '#10B981' },
  { label: '仕事', color: '#3B82F6' },
  { label: 'シフト', color: '#7C3AED' },
  { label: '病院', color: '#F59E0B' },
  { label: 'その他', color: '#6B7280' },
];

function addDaysStr(dateStr: string, days: number): string {
  const [y, m, d] = dateStr.split('-').map(Number);
  if (!y || !m || !d) return dateStr;
  const dt = new Date(y, m - 1, d);
  dt.setDate(dt.getDate() + days);
  return `${dt.getFullYear()}-${String(dt.getMonth() + 1).padStart(2, '0')}-${String(
    dt.getDate()
  ).padStart(2, '0')}`;
}

function diffDaysStr(startStr: string, endStr?: string): number {
  if (!endStr || endStr <= startStr) return 0;
  const [sy, sm, sd] = startStr.split('-').map(Number);
  const [ey, em, ed] = endStr.split('-').map(Number);
  if (!sy || !sm || !sd || !ey || !em || !ed) return 0;
  const s = new Date(sy, sm - 1, sd).getTime();
  const e = new Date(ey, em - 1, ed).getTime();
  return Math.max(0, Math.round((e - s) / (1000 * 60 * 60 * 24)));
}

function formatJapaneseDateFull(dateStr: string): string {
  if (!dateStr) return '';
  const dt = new Date(dateStr + 'T00:00:00');
  if (isNaN(dt.getTime())) return dateStr;
  return dt.toLocaleDateString('ja-JP', {
    year: 'numeric',
    month: 'long',
    day: 'numeric',
    weekday: 'short',
  });
}

function formatShortDateWithWeekday(dateStr: string): string {
  if (!dateStr) return '';
  const dt = new Date(dateStr + 'T00:00:00');
  if (isNaN(dt.getTime())) return dateStr;
  return dt.toLocaleDateString('ja-JP', {
    month: 'numeric',
    day: 'numeric',
    weekday: 'short',
  });
}

type ModalMode = 'view' | 'edit' | 'copy_multi';

export const EventModal: React.FC<EventModalProps> = ({
  isOpen,
  onClose,
  event,
  calendars,
  activeCalendarId,
  members,
  currentMember,
  onSaveEvent,
  onDeleteEvent,
  isGoogleConnected = false,
}) => {
  const defaultDate = new Date().toISOString().substring(0, 10);

  // Modal view mode: 'view' (Detail screen for existing events), 'edit' (Create/Edit form), 'copy_multi' (Copy to multiple dates)
  const [modalMode, setModalMode] = useState<ModalMode>('view');
  const [isMenuOpen, setIsMenuOpen] = useState<boolean>(false);
  const [isDuplicateCreate, setIsDuplicateCreate] = useState<boolean>(false);

  // Form states
  const [title, setTitle] = useState('');
  const [calendarId, setCalendarId] = useState(activeCalendarId);
  const [date, setDate] = useState(defaultDate);
  const [endDate, setEndDate] = useState(defaultDate);
  const [isAllDay, setIsAllDay] = useState(false);
  const [startTime, setStartTime] = useState('12:00');
  const [endTime, setEndTime] = useState('14:00');

  // Recurrence & Multi-Date Selection Mode (inside Edit form)
  const [dateSelectionMode, setDateSelectionMode] = useState<'standard' | 'multi_dates'>('standard');

  // Recurrence States
  const [frequency, setFrequency] = useState<RecurrenceFrequency>('none');
  const [repeatInterval, setRepeatInterval] = useState<number>(1);
  const [endType, setEndType] = useState<'count' | 'until_date' | 'never'>('count');
  const [repeatCount, setRepeatCount] = useState<number>(10);
  const [untilDate, setUntilDate] = useState<string>('');

  // Multi-Dates State (inside Edit form)
  const [multiDates, setMultiDates] = useState<string[]>([defaultDate]);
  const [newMultiDate, setNewMultiDate] = useState<string>('');

  // Copy to Multiple Dates State ('copy_multi' mode from ︙ menu)
  const [copyTargetDates, setCopyTargetDates] = useState<string[]>([]);
  const [copyCalMonth, setCopyCalMonth] = useState<Date>(new Date());

  const [selectedMemberIds, setSelectedMemberIds] = useState<string[]>([currentMember.id]);
  const [category, setCategory] = useState<EventCategory>('プライベート');
  const [color, setColor] = useState('#10B981');
  const [location, setLocation] = useState('');
  const [notes, setNotes] = useState('');

  // Checklists & Comments
  const [checklist, setChecklist] = useState<ChecklistItem[]>([]);
  const [newChecklistText, setNewChecklistText] = useState('');
  const [comments, setComments] = useState<EventComment[]>([]);
  const [newCommentText, setNewCommentText] = useState('');

  // Google Calendar Sync & Confirmation
  const [syncToGoogle, setSyncToGoogle] = useState(false);
  const [showGoogleConfirm, setShowGoogleConfirm] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);

  // In-modal delete confirmation & validation error
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  const [formError, setFormError] = useState<string | null>(null);

  // Active tab inside Edit mode
  const [activeTab, setActiveTab] = useState<'details' | 'checklist' | 'chat'>('details');

  // Sync props into state whenever modal opens or target event changes
  useEffect(() => {
    if (!isOpen) return;
    const initDate = event?.date || new Date().toISOString().substring(0, 10);
    const initEndDate = event?.endDate && event.endDate >= initDate ? event.endDate : initDate;
    const initCategory = event?.category || 'プライベート';
    const initColor =
      event?.color ||
      CATEGORIES.find((c) => c.label === initCategory)?.color ||
      '#10B981';

    // Existing events open in read-only Detail View ('view'); new events open in 'edit'
    const hasExistingId = Boolean(event?.id);
    setModalMode(hasExistingId ? 'view' : 'edit');
    setIsMenuOpen(false);
    setIsDuplicateCreate(false);

    setTitle(event?.title || '');
    setCalendarId(event?.calendarId || activeCalendarId);
    setDate(initDate);
    setEndDate(initEndDate);
    setIsAllDay(event?.isAllDay ?? false);
    setStartTime(event?.startTime || '12:00');
    setEndTime(event?.endTime || '14:00');
    setDateSelectionMode('standard');
    setFrequency(event?.recurrenceRule?.frequency || 'none');
    setRepeatInterval(event?.recurrenceRule?.interval || 1);
    setEndType(event?.recurrenceRule?.endType || 'count');
    setRepeatCount(event?.recurrenceRule?.endCount || 10);
    setUntilDate(event?.recurrenceRule?.endDate || addDaysStr(initDate, 60));
    setMultiDates([initDate]);
    setNewMultiDate('');
    setCopyTargetDates([]);
    setCopyCalMonth(new Date(initDate + 'T00:00:00'));
    setSelectedMemberIds(
      event?.memberIds && event.memberIds.length > 0 ? event.memberIds : [currentMember.id]
    );
    setCategory(initCategory);
    setColor(initColor);
    setLocation(event?.location || '');
    setNotes(event?.notes || '');
    setChecklist(event?.checklist || []);
    setNewChecklistText('');
    setComments(event?.comments || []);
    setNewCommentText('');
    setSyncToGoogle(false);
    setShowGoogleConfirm(false);
    setShowDeleteConfirm(false);
    setFormError(null);
    setActiveTab('details');
  }, [isOpen, event, activeCalendarId, currentMember.id]);

  if (!isOpen) return null;

  const isEditing = Boolean(event?.id) && !isDuplicateCreate;
  const isCrossDay = endDate > date;

  // Handle start date change: keep endDate >= newStartDate
  const handleStartDateChange = (newStart: string) => {
    setDate(newStart);
    if (!endDate || endDate < newStart) {
      setEndDate(newStart);
    }
  };

  // Handle end time change: if on same day and endTime < startTime, auto-advance endDate by +1 day
  const handleEndTimeChange = (newEndTime: string) => {
    setEndTime(newEndTime);
    if (endDate === date && newEndTime < startTime) {
      setEndDate(addDaysStr(date, 1));
    }
  };

  const handleToggleMember = (memberId: string) => {
    if (selectedMemberIds.includes(memberId)) {
      if (selectedMemberIds.length > 1) {
        setSelectedMemberIds(selectedMemberIds.filter((id) => id !== memberId));
      }
    } else {
      setSelectedMemberIds([...selectedMemberIds, memberId]);
    }
  };

  const handleAddChecklistItem = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newChecklistText.trim()) return;
    const nextList = [
      ...checklist,
      { id: `chk-${Date.now()}`, text: newChecklistText.trim(), done: false },
    ];
    setChecklist(nextList);
    setNewChecklistText('');
    if (modalMode === 'view' && event?.id) {
      await persistQuickUpdate({ checklist: nextList });
    }
  };

  const handleToggleChecklist = async (id: string) => {
    const nextList = checklist.map((item) =>
      item.id === id ? { ...item, done: !item.done } : item
    );
    setChecklist(nextList);
    if (modalMode === 'view' && event?.id) {
      await persistQuickUpdate({ checklist: nextList });
    }
  };

  const handleDeleteChecklistItem = async (id: string) => {
    const nextList = checklist.filter((item) => item.id !== id);
    setChecklist(nextList);
    if (modalMode === 'view' && event?.id) {
      await persistQuickUpdate({ checklist: nextList });
    }
  };

  const handleSendComment = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCommentText.trim()) return;

    const newComment: EventComment = {
      id: `c-${Date.now()}`,
      memberId: currentMember.id,
      memberName: currentMember.name,
      memberAvatar: currentMember.avatarUrl,
      text: newCommentText.trim(),
      createdAt: 'たった今',
    };

    const nextComments = [...comments, newComment];
    setComments(nextComments);
    setNewCommentText('');
    if (modalMode === 'view' && event?.id) {
      await persistQuickUpdate({ comments: nextComments });
    }
  };

  // Persist checklist/comment updates directly when toggled from Detail View
  const persistQuickUpdate = async (patch: Partial<CalendarEvent>) => {
    if (!event?.id) return;
    const updated: CalendarEvent = {
      id: event.id,
      calendarId,
      title,
      date,
      endDate: endDate > date ? endDate : undefined,
      startTime: isAllDay ? undefined : startTime,
      endTime: isAllDay ? undefined : endTime,
      isAllDay,
      memberIds: selectedMemberIds,
      color,
      category,
      location: location || undefined,
      locationCoords: event.locationCoords,
      notes: notes || undefined,
      checklist,
      comments,
      isGoogleSynced: event.isGoogleSynced,
      googleEventId: event.googleEventId,
      shiftType: event.shiftType,
      recurringGroupId: event.recurringGroupId,
      recurrenceRule: event.recurrenceRule,
      ...patch,
    };
    await onSaveEvent(updated, false);
  };

  const handleAddMultiDate = (dStr: string) => {
    if (!dStr || multiDates.includes(dStr)) return;
    const sorted = [...multiDates, dStr].sort();
    setMultiDates(sorted);
    setNewMultiDate('');
    setFormError(null);
  };

  const handleRemoveMultiDate = (dStr: string) => {
    if (multiDates.length <= 1) {
      setFormError('少なくとも1つの日付が必要です。');
      return;
    }
    setMultiDates(multiDates.filter((d) => d !== dStr));
  };

  const handleAddNextWeekPreset = () => {
    const base = multiDates[multiDates.length - 1] || date;
    const formatted = addDaysStr(base, 7);
    if (!multiDates.includes(formatted)) {
      setMultiDates([...multiDates, formatted].sort());
    }
  };

  const handleAddWeekdaysPreset = () => {
    const today = new Date();
    const newDates = [...multiDates];
    for (let i = 0; i < 7; i++) {
      const d = new Date(today);
      d.setDate(today.getDate() + i);
      const dayOfWeek = d.getDay();
      if (dayOfWeek >= 1 && dayOfWeek <= 5) {
        const formatted = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(
          d.getDate()
        ).padStart(2, '0')}`;
        if (!newDates.includes(formatted)) {
          newDates.push(formatted);
        }
      }
    }
    setMultiDates(newDates.sort());
  };

  // Toggle date in 'copy_multi' interactive mini-calendar
  const handleToggleCopyDate = (dStr: string) => {
    setFormError(null);
    if (copyTargetDates.includes(dStr)) {
      setCopyTargetDates(copyTargetDates.filter((d) => d !== dStr));
    } else {
      setCopyTargetDates([...copyTargetDates, dStr].sort());
    }
  };

  // Execute "Copy to Multiple Dates" from 'copy_multi' screen
  const handleExecuteMultiCopy = async () => {
    if (copyTargetDates.length === 0) {
      setFormError('コピー先の日付をカレンダーから1つ以上選択してください。');
      return;
    }
    setIsSubmitting(true);
    setFormError(null);
    try {
      const spanDays = diffDaysStr(date, endDate);
      const groupId = `copygrp-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`;

      const copiedEvents: CalendarEvent[] = copyTargetDates.map((targetDateStr, idx) => ({
        id: `evt-copy-${Date.now()}-${idx}-${Math.random().toString(36).substring(2, 6)}`,
        calendarId,
        title: title.trim(),
        date: targetDateStr,
        endDate: spanDays > 0 ? addDaysStr(targetDateStr, spanDays) : undefined,
        startTime: isAllDay ? undefined : startTime,
        endTime: isAllDay ? undefined : endTime,
        isAllDay,
        memberIds: selectedMemberIds,
        color,
        category,
        location: location.trim() || undefined,
        locationCoords: event?.locationCoords,
        notes: notes.trim() || undefined,
        checklist: checklist.map((c) => ({ ...c, done: false })),
        comments: [],
        shiftType: event?.shiftType,
        recurringGroupId: groupId,
      }));

      await onSaveEvent(copiedEvents, false);
      onClose();
    } catch (err: any) {
      setFormError(`コピー中にエラーが発生しました: ${err.message}`);
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormError(null);

    if (!title.trim()) {
      setFormError('予定のタイトルを入力してください。');
      return;
    }

    if (dateSelectionMode === 'standard' && endDate < date) {
      setFormError('終了日は開始日以降の日付を指定してください。');
      return;
    }

    if (syncToGoogle && isGoogleConnected) {
      setShowGoogleConfirm(true);
      return;
    }

    await saveEventInternal(false);
  };

  const saveEventInternal = async (pushToGoogle: boolean) => {
    setIsSubmitting(true);
    setFormError(null);
    try {
      const effectiveEndDate = endDate && endDate > date ? endDate : undefined;

      const baseEvent: CalendarEvent = {
        id:
          isEditing && event?.id
            ? event.id
            : `evt-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
        calendarId,
        title: title.trim(),
        date: dateSelectionMode === 'multi_dates' ? multiDates[0] || date : date,
        endDate: effectiveEndDate,
        startTime: isAllDay ? undefined : startTime,
        endTime: isAllDay ? undefined : endTime,
        isAllDay,
        memberIds: selectedMemberIds,
        color,
        category,
        location: location.trim() || undefined,
        locationCoords: event?.locationCoords,
        notes: notes.trim() || undefined,
        checklist,
        comments,
        isGoogleSynced: pushToGoogle || (isEditing ? event?.isGoogleSynced : false),
        googleEventId: isEditing ? event?.googleEventId : undefined,
        shiftType: event?.shiftType,
      };

      let finalPayload: CalendarEvent | CalendarEvent[];

      if (dateSelectionMode === 'multi_dates') {
        if (multiDates.length === 0) {
          setFormError('1つ以上の選択日付を指定してください。');
          setIsSubmitting(false);
          return;
        }
        finalPayload = generateMultiDateEvents(baseEvent, multiDates);
      } else if (frequency !== 'none') {
        const rule: RecurrenceRule = {
          frequency,
          interval: repeatInterval,
          endType,
          endDate: endType === 'until_date' ? untilDate : undefined,
          endCount: endType === 'count' ? repeatCount : undefined,
        };
        baseEvent.recurrenceRule = rule;
        finalPayload = generateRecurringEvents(baseEvent, rule);
      } else {
        finalPayload = baseEvent;
      }

      await onSaveEvent(finalPayload, pushToGoogle);
      setShowGoogleConfirm(false);
      onClose();
    } catch (err: any) {
      setFormError(`保存中にエラーが発生しました: ${err.message}`);
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleConfirmDelete = (deleteAllInGroup = false) => {
    if (!onDeleteEvent || !event?.id) return;
    if (deleteAllInGroup && event.recurringGroupId) {
      onDeleteEvent(event.id, event.recurringGroupId);
    } else {
      onDeleteEvent(event.id);
    }
    setShowDeleteConfirm(false);
    onClose();
  };

  // Build mini-calendar grid for 'copy_multi' view
  const copyYear = copyCalMonth.getFullYear();
  const copyMonth = copyCalMonth.getMonth();
  const copyFirstDay = new Date(copyYear, copyMonth, 1).getDay();
  const copyDaysInMonth = new Date(copyYear, copyMonth + 1, 0).getDate();
  const copyCalendarCells: (string | null)[] = [];
  for (let i = 0; i < copyFirstDay; i++) {
    copyCalendarCells.push(null);
  }
  for (let d = 1; d <= copyDaysInMonth; d++) {
    copyCalendarCells.push(
      `${copyYear}-${String(copyMonth + 1).padStart(2, '0')}-${String(d).padStart(2, '0')}`
    );
  }

  const matchedCalendar = calendars.find((c) => c.id === calendarId);

  return (
    <>
      <div className="fixed inset-0 z-[2000] bg-black/60 backdrop-blur-xs flex items-end sm:items-center justify-center p-0 sm:p-4 overflow-y-auto pb-safe">
        <div className="bg-white rounded-t-3xl sm:rounded-2xl max-w-xl w-full max-h-[92vh] flex flex-col shadow-2xl animate-in fade-in zoom-in-95 duration-150 overflow-hidden relative">
          {/* =========================================================
              MODE 1: READ-ONLY DETAIL VIEW (予定の詳細画面 + 右上 ︙ メニュー)
             ========================================================= */}
          {modalMode === 'view' && (
            <>
              {/* Detail Header with Top-Right ︙ (MoreVertical) Menu */}
              <div className="px-5 py-3.5 border-b border-slate-100 flex items-center justify-between bg-slate-50 shrink-0 relative">
                <div className="flex items-center gap-2.5">
                  <span
                    className="w-3.5 h-3.5 rounded-full ring-2 ring-white shadow-xs shrink-0"
                    style={{ backgroundColor: color }}
                  />
                  <h3 className="font-bold text-slate-900 text-base">予定の詳細</h3>
                </div>

                {/* Right side: ︙ (Three-dots menu button) & Close */}
                <div className="flex items-center gap-1.5 relative">
                  <button
                    type="button"
                    onClick={() => setIsMenuOpen((prev) => !prev)}
                    className={`w-9 h-9 rounded-xl flex items-center justify-center transition cursor-pointer border ${
                      isMenuOpen
                        ? 'bg-emerald-50 border-emerald-300 text-emerald-700'
                        : 'bg-white hover:bg-slate-100 border-slate-200 text-slate-700 shadow-2xs'
                    }`}
                    title="メニュー（編集・複数日コピー・削除）"
                    aria-label="予定メニューを開く"
                  >
                    <MoreVertical className="w-5 h-5" />
                  </button>

                  <button
                    type="button"
                    onClick={onClose}
                    className="w-8 h-8 rounded-full bg-slate-200/70 hover:bg-slate-200 text-slate-600 flex items-center justify-center text-xs transition cursor-pointer"
                    title="閉じる"
                  >
                    ✕
                  </button>

                  {/* ︙ Dropdown Menu */}
                  {isMenuOpen && (
                    <>
                      <div
                        className="fixed inset-0 z-20"
                        onClick={() => setIsMenuOpen(false)}
                      />
                      <div className="absolute right-0 top-11 w-60 bg-white rounded-2xl shadow-2xl border border-slate-200 py-1.5 z-30 animate-in fade-in zoom-in-95 duration-100">
                        <div className="px-3 py-1.5 text-[10px] font-bold text-slate-400 border-b border-slate-100">
                          予定の操作メニュー
                        </div>

                        <button
                          type="button"
                          onClick={() => {
                            setIsMenuOpen(false);
                            setModalMode('edit');
                          }}
                          className="w-full px-3.5 py-2.5 text-left text-xs font-bold text-slate-800 hover:bg-emerald-50 hover:text-emerald-700 flex items-center gap-2.5 transition cursor-pointer"
                        >
                          <Edit3 className="w-4 h-4 text-emerald-600 shrink-0" />
                          <div>
                            <div>予定を編集する</div>
                            <div className="text-[10px] font-normal text-slate-400">
                              日時・タイトル・備考などを変更
                            </div>
                          </div>
                        </button>

                        <button
                          type="button"
                          onClick={() => {
                            setIsMenuOpen(false);
                            setCopyTargetDates([]);
                            setCopyCalMonth(new Date(date + 'T00:00:00'));
                            setModalMode('copy_multi');
                          }}
                          className="w-full px-3.5 py-2.5 text-left text-xs font-bold text-slate-800 hover:bg-emerald-50 hover:text-emerald-700 flex items-center gap-2.5 transition cursor-pointer"
                        >
                          <Copy className="w-4 h-4 text-blue-600 shrink-0" />
                          <div>
                            <div>複数の日付にコピー</div>
                            <div className="text-[10px] font-normal text-slate-400">
                              カレンダーから複数の日を選んで一括複製
                            </div>
                          </div>
                        </button>

                        <button
                          type="button"
                          onClick={() => {
                            setIsMenuOpen(false);
                            setIsDuplicateCreate(true);
                            setModalMode('edit');
                          }}
                          className="w-full px-3.5 py-2.5 text-left text-xs font-bold text-slate-800 hover:bg-emerald-50 hover:text-emerald-700 flex items-center gap-2.5 transition cursor-pointer"
                        >
                          <Layers className="w-4 h-4 text-purple-600 shrink-0" />
                          <div>
                            <div>同じ内容で新規作成（複製）</div>
                            <div className="text-[10px] font-normal text-slate-400">
                              内容を引き継いで別の日時で作成
                            </div>
                          </div>
                        </button>

                        {onDeleteEvent && event?.id && (
                          <>
                            <div className="my-1 border-t border-slate-100" />
                            <button
                              type="button"
                              onClick={() => {
                                setIsMenuOpen(false);
                                setShowDeleteConfirm(true);
                              }}
                              className="w-full px-3.5 py-2.5 text-left text-xs font-bold text-rose-600 hover:bg-rose-50 flex items-center gap-2.5 transition cursor-pointer"
                            >
                              <Trash2 className="w-4 h-4 text-rose-600 shrink-0" />
                              <div>
                                <div>この予定を削除</div>
                                <div className="text-[10px] font-normal text-rose-400">
                                  カレンダーから予定を取り消します
                                </div>
                              </div>
                            </button>
                          </>
                        )}
                      </div>
                    </>
                  )}
                </div>
              </div>

              {/* Detail View Body */}
              <div className="flex-1 overflow-y-auto p-5 space-y-4">
                {/* Delete Confirmation Banner if triggered from ︙ menu */}
                {showDeleteConfirm && event?.id && (
                  <div className="p-3.5 rounded-2xl bg-rose-50 border border-rose-200 space-y-2.5 animate-in fade-in">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-bold text-rose-900 flex items-center gap-1.5">
                        <Trash2 className="w-4 h-4 text-rose-600 shrink-0" />
                        「{title}」を削除しますか？
                      </span>
                      <button
                        type="button"
                        onClick={() => setShowDeleteConfirm(false)}
                        className="text-slate-400 hover:text-slate-600 text-xs px-1 cursor-pointer"
                      >
                        ✕
                      </button>
                    </div>
                    <div className="flex flex-wrap items-center gap-2">
                      <button
                        type="button"
                        onClick={() => handleConfirmDelete(false)}
                        className="px-3.5 py-1.5 bg-rose-600 hover:bg-rose-700 text-white rounded-xl text-xs font-bold transition shadow-2xs cursor-pointer"
                      >
                        この予定を削除する
                      </button>
                      {event.recurringGroupId && (
                        <button
                          type="button"
                          onClick={() => handleConfirmDelete(true)}
                          className="px-3.5 py-1.5 bg-rose-800 hover:bg-rose-900 text-white rounded-xl text-xs font-bold transition shadow-2xs cursor-pointer"
                        >
                          一括・繰り返し予定をすべて削除
                        </button>
                      )}
                      <button
                        type="button"
                        onClick={() => setShowDeleteConfirm(false)}
                        className="px-3 py-1.5 bg-white border border-slate-200 text-slate-600 rounded-xl text-xs font-semibold hover:bg-slate-100 transition cursor-pointer"
                      >
                        キャンセル
                      </button>
                    </div>
                  </div>
                )}

                {/* 1. Title & Category Hero Card */}
                <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200/90 space-y-2">
                  <div className="flex flex-wrap items-center gap-2">
                    <span
                      className="text-xs font-bold px-2.5 py-0.5 rounded-lg text-white"
                      style={{ backgroundColor: color }}
                    >
                      {category}
                    </span>
                    {matchedCalendar && (
                      <span className="text-xs font-semibold text-slate-600 bg-white px-2.5 py-0.5 rounded-lg border border-slate-200">
                        {matchedCalendar.emoji} {matchedCalendar.name}
                      </span>
                    )}
                    {event?.recurringGroupId && (
                      <span className="inline-flex items-center gap-1 text-[11px] font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-lg border border-emerald-200">
                        <Repeat className="w-3 h-3" /> 繰り返し/一括登録
                      </span>
                    )}
                  </div>

                  <h2 className="text-lg sm:text-xl font-extrabold text-slate-900 break-words leading-snug pt-1">
                    {title}
                  </h2>
                </div>

                {/* 2. Date & Time Detail Card */}
                <div className="p-4 rounded-2xl bg-white border border-slate-200 space-y-2 shadow-2xs">
                  <div className="text-xs font-bold text-slate-400 flex items-center gap-1.5">
                    <Clock className="w-3.5 h-3.5 text-emerald-600" />
                    <span>日時</span>
                  </div>

                  {isCrossDay ? (
                    <div className="space-y-1.5 pt-0.5">
                      <div className="flex items-center gap-2 text-sm font-extrabold text-slate-900">
                        <span className="text-xs font-bold px-2 py-0.5 bg-emerald-50 text-emerald-800 rounded border border-emerald-200">
                          開始
                        </span>
                        <span>{formatJapaneseDateFull(date)}</span>
                        {!isAllDay && <span className="text-emerald-700 font-mono">{startTime}</span>}
                      </div>
                      <div className="flex items-center gap-2 text-sm font-extrabold text-slate-900">
                        <span className="text-xs font-bold px-2 py-0.5 bg-blue-50 text-blue-800 rounded border border-blue-200">
                          終了
                        </span>
                        <span>{formatJapaneseDateFull(endDate)}</span>
                        {!isAllDay && <span className="text-blue-700 font-mono">{endTime}</span>}
                      </div>
                    </div>
                  ) : (
                    <div className="flex flex-wrap items-baseline justify-between gap-2 pt-0.5">
                      <div className="text-sm sm:text-base font-extrabold text-slate-900">
                        {formatJapaneseDateFull(date)}
                      </div>
                      <div className="text-sm sm:text-base font-extrabold text-emerald-700 font-mono bg-emerald-50 px-3 py-1 rounded-xl border border-emerald-200">
                        {isAllDay ? '終日' : `${startTime} 〜 ${endTime}`}
                      </div>
                    </div>
                  )}
                </div>

                {/* 3. Notes / Memo Detail Card */}
                <div className="p-4 rounded-2xl bg-white border border-slate-200 space-y-2 shadow-2xs">
                  <div className="text-xs font-bold text-slate-400 flex items-center gap-1.5">
                    <FileText className="w-3.5 h-3.5 text-emerald-600" />
                    <span>備考・メモ</span>
                  </div>
                  {notes && notes.trim() ? (
                    <div className="text-xs sm:text-sm text-slate-800 whitespace-pre-wrap leading-relaxed bg-slate-50 p-3 rounded-xl border border-slate-100">
                      {notes}
                    </div>
                  ) : (
                    <div className="text-xs text-slate-400 py-1">備考はありません</div>
                  )}
                </div>

                {/* 4. Location Detail Card (if location exists) */}
                {location && location.trim() && (
                  <div className="p-4 rounded-2xl bg-white border border-slate-200 space-y-1.5 shadow-2xs">
                    <div className="text-xs font-bold text-slate-400 flex items-center gap-1.5">
                      <MapPin className="w-3.5 h-3.5 text-emerald-600" />
                      <span>場所</span>
                    </div>
                    <div className="text-xs sm:text-sm font-semibold text-slate-800 break-words">
                      {location}
                    </div>
                  </div>
                )}

                {/* 5. Participating Members */}
                <div className="p-4 rounded-2xl bg-white border border-slate-200 space-y-2 shadow-2xs">
                  <div className="text-xs font-bold text-slate-400 flex items-center gap-1.5">
                    <Users className="w-3.5 h-3.5 text-emerald-600" />
                    <span>参加メンバー</span>
                  </div>
                  <div className="flex flex-wrap gap-2">
                    {members
                      .filter((m) => selectedMemberIds.includes(m.id))
                      .map((member) => (
                        <div
                          key={member.id}
                          className="flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-slate-50 border border-slate-200 text-slate-800"
                        >
                          <img
                            src={member.avatarUrl}
                            alt={member.name}
                            referrerPolicy="no-referrer"
                            className="w-4 h-4 rounded-full object-cover"
                          />
                          <span>{member.name}</span>
                          <span
                            className="w-2 h-2 rounded-full"
                            style={{ backgroundColor: member.color }}
                          />
                        </div>
                      ))}
                  </div>
                </div>

                {/* 6. Checklist & Comments Quick Section */}
                {(checklist.length > 0 || comments.length > 0) && (
                  <div className="p-4 rounded-2xl bg-white border border-slate-200 space-y-3 shadow-2xs">
                    {checklist.length > 0 && (
                      <div className="space-y-2">
                        <div className="text-xs font-bold text-slate-500 flex items-center gap-1.5">
                          <CheckSquare className="w-3.5 h-3.5 text-emerald-600" />
                          <span>
                            ToDo・持ち物 ({checklist.filter((c) => c.done).length}/{checklist.length})
                          </span>
                        </div>
                        <div className="space-y-1.5">
                          {checklist.map((item) => (
                            <label
                              key={item.id}
                              className="flex items-center gap-2.5 p-2 rounded-xl bg-slate-50 border border-slate-100 text-xs cursor-pointer"
                            >
                              <input
                                type="checkbox"
                                checked={item.done}
                                onChange={() => handleToggleChecklist(item.id)}
                                className="rounded-sm text-emerald-600 focus:ring-emerald-500 w-4 h-4"
                              />
                              <span
                                className={
                                  item.done ? 'line-through text-slate-400' : 'text-slate-800'
                                }
                              >
                                {item.text}
                              </span>
                            </label>
                          ))}
                        </div>
                      </div>
                    )}

                    {comments.length > 0 && (
                      <div className="space-y-2 pt-2 border-t border-slate-100">
                        <div className="text-xs font-bold text-slate-500 flex items-center gap-1.5">
                          <MessageCircle className="w-3.5 h-3.5 text-blue-500" />
                          <span>チャットメモ ({comments.length}件)</span>
                        </div>
                        <div className="space-y-1.5">
                          {comments.map((comm) => (
                            <div
                              key={comm.id}
                              className="p-2.5 rounded-xl bg-slate-50 text-xs text-slate-800"
                            >
                              <span className="font-bold text-slate-600 mr-2">
                                {comm.memberName}:
                              </span>
                              <span>{comm.text}</span>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                )}
              </div>

              {/* Detail View Footer - Single clear bottom return button */}
              <div className="px-4 sm:px-5 py-3 border-t border-slate-100 bg-slate-50 flex flex-wrap items-center justify-between gap-2 shrink-0">
                <button
                  type="button"
                  onClick={onClose}
                  className="flex-1 py-3 px-4 bg-slate-800 hover:bg-slate-900 text-white rounded-xl text-xs sm:text-sm font-bold transition shadow-xs cursor-pointer text-center min-h-[44px] flex items-center justify-center"
                >
                  ← 前の画面に戻る
                </button>
                <div className="text-[11px] text-slate-400 font-medium">
                  編集・コピー・削除は右上の「︙」メニュー
                </div>
              </div>
            </>
          )}

          {/* =========================================================
              MODE 2: COPY TO MULTIPLE DATES (複数の日付にコピー画面)
             ========================================================= */}
          {modalMode === 'copy_multi' && (
            <>
              <div className="px-5 py-3.5 border-b border-slate-100 flex items-center justify-between bg-slate-50 shrink-0">
                <div className="flex items-center gap-2.5">
                  <button
                    type="button"
                    onClick={() => {
                      setFormError(null);
                      setModalMode('view');
                    }}
                    className="px-2.5 py-1.5 rounded-lg bg-white hover:bg-slate-100 border border-slate-200 text-slate-700 flex items-center gap-1 text-xs font-bold transition cursor-pointer shadow-2xs"
                  >
                    <span>← 詳細に戻る</span>
                  </button>
                  <Copy className="w-4 h-4 text-blue-600" />
                  <h3 className="font-bold text-slate-900 text-base">複数の日付にコピー</h3>
                </div>
                <button
                  type="button"
                  onClick={onClose}
                  className="w-7 h-7 rounded-full bg-slate-200/70 hover:bg-slate-200 text-slate-600 flex items-center justify-center text-xs transition cursor-pointer"
                >
                  ✕
                </button>
              </div>

              <div className="flex-1 overflow-y-auto p-5 space-y-4">
                {formError && (
                  <div className="p-3 rounded-xl bg-rose-50 border border-rose-200 text-rose-700 text-xs flex items-center gap-2">
                    <AlertCircle className="w-4 h-4 shrink-0" />
                    <span>{formError}</span>
                  </div>
                )}

                {/* Source Event Banner */}
                <div className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200 flex items-center justify-between gap-3">
                  <div className="flex items-center gap-2.5 min-w-0">
                    <span
                      className="w-3.5 h-3.5 rounded-full shrink-0"
                      style={{ backgroundColor: color }}
                    />
                    <div className="min-w-0">
                      <div className="text-xs font-extrabold text-slate-900 truncate">
                        {title}
                      </div>
                      <div className="text-[11px] text-slate-500">
                        元の日時: {formatShortDateWithWeekday(date)}{' '}
                        {isAllDay ? '終日' : `${startTime} 〜 ${endTime}`}
                      </div>
                    </div>
                  </div>
                  <span className="text-[11px] font-bold text-blue-700 bg-blue-50 px-2.5 py-1 rounded-lg border border-blue-200 shrink-0">
                    {copyTargetDates.length}日選択中
                  </span>
                </div>

                {/* Interactive Mini Calendar to Tap Multiple Dates */}
                <div className="p-4 rounded-2xl bg-white border border-slate-200 shadow-2xs space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-slate-700">
                      コピー先の日付をタップして選択（複数選択可）
                    </span>
                    <div className="flex items-center gap-1">
                      <button
                        type="button"
                        onClick={() =>
                          setCopyCalMonth(new Date(copyYear, copyMonth - 1, 1))
                        }
                        className="p-1.5 rounded-lg border border-slate-200 hover:bg-slate-100 text-slate-600 cursor-pointer"
                      >
                        <ChevronLeft className="w-4 h-4" />
                      </button>
                      <span className="text-xs font-extrabold text-slate-900 px-2">
                        {copyYear}年 {copyMonth + 1}月
                      </span>
                      <button
                        type="button"
                        onClick={() =>
                          setCopyCalMonth(new Date(copyYear, copyMonth + 1, 1))
                        }
                        className="p-1.5 rounded-lg border border-slate-200 hover:bg-slate-100 text-slate-600 cursor-pointer"
                      >
                        <ChevronRight className="w-4 h-4" />
                      </button>
                    </div>
                  </div>

                  {/* Weekday Headers */}
                  <div className="grid grid-cols-7 text-center text-[11px] font-bold text-slate-500 pb-1 border-b border-slate-100">
                    <span className="text-red-500">日</span>
                    <span>月</span>
                    <span>火</span>
                    <span>水</span>
                    <span>木</span>
                    <span>金</span>
                    <span className="text-blue-500">土</span>
                  </div>

                  {/* Days Grid */}
                  <div className="grid grid-cols-7 gap-1.5">
                    {copyCalendarCells.map((cellDateStr, idx) => {
                      if (!cellDateStr) {
                        return <div key={`empty-${idx}`} className="h-10" />;
                      }
                      const dayNum = Number(cellDateStr.split('-')[2]);
                      const isSourceDate = cellDateStr === date;
                      const isSelected = copyTargetDates.includes(cellDateStr);
                      const dow = new Date(cellDateStr + 'T00:00:00').getDay();

                      return (
                        <button
                          key={cellDateStr}
                          type="button"
                          onClick={() => handleToggleCopyDate(cellDateStr)}
                          className={`h-10 rounded-xl text-xs font-bold flex flex-col items-center justify-center transition cursor-pointer relative border ${
                            isSelected
                              ? 'bg-emerald-600 text-white border-emerald-600 shadow-xs'
                              : isSourceDate
                              ? 'bg-amber-50 text-amber-900 border-amber-300'
                              : 'bg-slate-50/70 hover:bg-emerald-50 text-slate-700 border-slate-200/80'
                          }`}
                        >
                          <span
                            className={
                              !isSelected
                                ? dow === 0
                                  ? 'text-red-500'
                                  : dow === 6
                                  ? 'text-blue-500'
                                  : ''
                                : ''
                            }
                          >
                            {dayNum}
                          </span>
                          {isSourceDate && !isSelected && (
                            <span className="text-[8px] text-amber-700 leading-none">
                              元の日
                            </span>
                          )}
                          {isSelected && (
                            <Check className="w-3 h-3 text-white leading-none" />
                          )}
                        </button>
                      );
                    })}
                  </div>

                  {/* Quick helper buttons */}
                  <div className="flex flex-wrap items-center justify-between gap-2 pt-2 border-t border-slate-100">
                    <div className="flex flex-wrap items-center gap-1.5">
                      <button
                        type="button"
                        onClick={() => {
                          const nextWeek = addDaysStr(
                            copyTargetDates[copyTargetDates.length - 1] || date,
                            7
                          );
                          if (!copyTargetDates.includes(nextWeek)) {
                            setCopyTargetDates([...copyTargetDates, nextWeek].sort());
                          }
                        }}
                        className="px-2.5 py-1 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-[11px] font-semibold transition cursor-pointer"
                      >
                        +翌週の同曜日を追加
                      </button>
                    </div>
                    {copyTargetDates.length > 0 && (
                      <button
                        type="button"
                        onClick={() => setCopyTargetDates([])}
                        className="text-[11px] text-rose-600 hover:underline font-semibold cursor-pointer"
                      >
                        選択をすべてクリア
                      </button>
                    )}
                  </div>
                </div>

                {/* Selected target dates chips */}
                {copyTargetDates.length > 0 && (
                  <div className="space-y-1.5">
                    <div className="text-xs font-bold text-slate-600">
                      コピー先の日付一覧 ({copyTargetDates.length}日分):
                    </div>
                    <div className="flex flex-wrap gap-1.5 p-3 bg-emerald-50/60 border border-emerald-200 rounded-2xl">
                      {copyTargetDates.map((dStr) => (
                        <span
                          key={dStr}
                          className="px-2.5 py-1 bg-white border border-emerald-300 text-emerald-900 rounded-lg text-xs font-bold flex items-center gap-1 shadow-2xs"
                        >
                          <span>{formatShortDateWithWeekday(dStr)}</span>
                          <button
                            type="button"
                            onClick={() => handleToggleCopyDate(dStr)}
                            className="text-slate-400 hover:text-rose-600 pl-0.5 cursor-pointer"
                          >
                            ✕
                          </button>
                        </span>
                      ))}
                    </div>
                  </div>
                )}
              </div>

              <div className="px-5 py-3.5 border-t border-slate-100 bg-slate-50 flex items-center justify-between shrink-0">
                <button
                  type="button"
                  onClick={() => setModalMode('view')}
                  className="px-4 py-2 border border-slate-200 bg-white text-slate-600 rounded-xl text-xs font-bold hover:bg-slate-100 transition cursor-pointer"
                >
                  キャンセル
                </button>
                <button
                  type="button"
                  disabled={isSubmitting || copyTargetDates.length === 0}
                  onClick={handleExecuteMultiCopy}
                  className="px-5 py-2 bg-emerald-600 hover:bg-emerald-700 disabled:bg-slate-300 text-white rounded-xl text-xs font-bold shadow-xs transition flex items-center gap-1.5 cursor-pointer"
                >
                  <Copy className="w-3.5 h-3.5" />
                  <span>
                    {isSubmitting
                      ? 'コピー中...'
                      : `選択した ${copyTargetDates.length}日分にコピーを作成`}
                  </span>
                </button>
              </div>
            </>
          )}

          {/* =========================================================
              MODE 3: EDIT / CREATE FORM (予定の編集・新規作成画面)
             ========================================================= */}
          {modalMode === 'edit' && (
            <>
              {/* Edit Header */}
              <div className="px-5 py-3.5 border-b border-slate-100 flex items-center justify-between bg-slate-50 shrink-0">
                <div className="flex items-center gap-2.5">
                  <button
                    type="button"
                    onClick={() => {
                      if (event?.id) {
                        setIsDuplicateCreate(false);
                        setModalMode('view');
                      } else {
                        onClose();
                      }
                    }}
                    className="px-2.5 py-1 rounded-lg bg-white hover:bg-slate-100 border border-slate-200 text-slate-700 flex items-center gap-1 text-xs font-bold transition cursor-pointer shadow-2xs"
                    title="前の画面に戻る"
                  >
                    <span>{event?.id ? '← 詳細に戻る' : '← 戻る'}</span>
                  </button>
                  <span
                    className="w-3.5 h-3.5 rounded-full ring-2 ring-white shadow-xs shrink-0"
                    style={{ backgroundColor: color }}
                  />
                  <h3 className="font-bold text-slate-900 text-base">
                    {isDuplicateCreate
                      ? '予定を複製して新規作成'
                      : isEditing
                      ? '予定を編集'
                      : '新しい予定を作成'}
                  </h3>
                </div>
                <button
                  type="button"
                  onClick={onClose}
                  className="w-7 h-7 rounded-full bg-slate-200/70 hover:bg-slate-200 text-slate-600 flex items-center justify-center text-xs transition cursor-pointer"
                >
                  ✕
                </button>
              </div>

              {/* Tab Navigation (Details / Checklist / Comments) */}
              <div className="flex border-b border-slate-200 bg-white px-5 text-xs font-semibold shrink-0">
                <button
                  type="button"
                  onClick={() => setActiveTab('details')}
                  className={`py-2.5 px-3 border-b-2 transition cursor-pointer ${
                    activeTab === 'details'
                      ? 'border-emerald-600 text-emerald-700'
                      : 'border-transparent text-slate-500 hover:text-slate-800'
                  }`}
                >
                  基本情報
                </button>
                <button
                  type="button"
                  onClick={() => setActiveTab('checklist')}
                  className={`py-2.5 px-3 border-b-2 transition flex items-center gap-1.5 cursor-pointer ${
                    activeTab === 'checklist'
                      ? 'border-emerald-600 text-emerald-700'
                      : 'border-transparent text-slate-500 hover:text-slate-800'
                  }`}
                >
                  <CheckSquare className="w-3.5 h-3.5" />
                  ToDo・持ち物
                  {checklist.length > 0 && (
                    <span className="bg-slate-100 px-1.5 py-0.2 rounded-full text-[10px]">
                      {checklist.filter((c) => c.done).length}/{checklist.length}
                    </span>
                  )}
                </button>
                <button
                  type="button"
                  onClick={() => setActiveTab('chat')}
                  className={`py-2.5 px-3 border-b-2 transition flex items-center gap-1.5 cursor-pointer ${
                    activeTab === 'chat'
                      ? 'border-emerald-600 text-emerald-700'
                      : 'border-transparent text-slate-500 hover:text-slate-800'
                  }`}
                >
                  <MessageCircle className="w-3.5 h-3.5" />
                  チャット
                  {comments.length > 0 && (
                    <span className="bg-emerald-100 text-emerald-700 px-1.5 py-0.2 rounded-full text-[10px]">
                      {comments.length}
                    </span>
                  )}
                </button>
              </div>

              {/* Modal Body */}
              <div className="flex-1 overflow-y-auto p-5">
                {formError && (
                  <div className="mb-4 p-3 rounded-xl bg-rose-50 border border-rose-200 text-rose-700 text-xs flex items-center gap-2">
                    <AlertCircle className="w-4 h-4 shrink-0" />
                    <span>{formError}</span>
                  </div>
                )}

                {activeTab === 'details' && (
                  <form id="event-form" onSubmit={handleSubmit} className="space-y-4">
                    {/* Title */}
                    <div>
                      <input
                        type="text"
                        required
                        value={title}
                        onChange={(e) => setTitle(e.target.value)}
                        placeholder="予定のタイトル (例: 温泉旅行、夜勤、ランチ、定例MTG)"
                        className="w-full text-base font-bold text-slate-900 border-b-2 border-slate-200 focus:border-emerald-600 focus:outline-hidden pb-1.5 transition placeholder:text-slate-400 placeholder:font-normal"
                      />
                    </div>

                    {/* Calendar & Category */}
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
                      <div>
                        <label className="block text-xs font-semibold text-slate-600 mb-1">
                          共有カレンダー
                        </label>
                        <select
                          value={calendarId}
                          onChange={(e) => setCalendarId(e.target.value)}
                          className="w-full p-2 border border-slate-200 rounded-xl text-xs bg-slate-50 text-slate-800"
                        >
                          {calendars.map((c) => (
                            <option key={c.id} value={c.id}>
                              {c.emoji} {c.name}
                            </option>
                          ))}
                        </select>
                      </div>

                      <div>
                        <label className="block text-xs font-semibold text-slate-600 mb-1">
                          カテゴリー / タグ
                        </label>
                        <div className="flex flex-wrap gap-1.5">
                          {CATEGORIES.map((cat) => (
                            <button
                              key={cat.label}
                              type="button"
                              onClick={() => {
                                setCategory(cat.label);
                                setColor(cat.color);
                              }}
                              className={`text-xs px-2.5 py-1 rounded-lg border font-medium transition cursor-pointer ${
                                category === cat.label
                                  ? 'text-white border-transparent'
                                  : 'bg-slate-50 text-slate-600 border-slate-200 hover:bg-slate-100'
                              }`}
                              style={{
                                backgroundColor: category === cat.label ? cat.color : undefined,
                              }}
                            >
                              {cat.label}
                            </button>
                          ))}
                        </div>
                      </div>
                    </div>

                    {/* Date & Time Settings */}
                    <div className="bg-slate-50 p-3.5 rounded-2xl border border-slate-200 space-y-3.5">
                      <div className="flex flex-wrap items-center justify-between gap-2 pb-2 border-b border-slate-200/80">
                        <div className="flex items-center gap-1 bg-slate-200/70 p-0.5 rounded-xl text-xs font-medium">
                          <button
                            type="button"
                            onClick={() => setDateSelectionMode('standard')}
                            className={`px-3 py-1 rounded-lg transition flex items-center gap-1 cursor-pointer ${
                              dateSelectionMode === 'standard'
                                ? 'bg-white text-emerald-800 font-bold shadow-2xs'
                                : 'text-slate-600 hover:text-slate-900'
                            }`}
                          >
                            <CalendarIcon className="w-3.5 h-3.5 text-emerald-600" />
                            <span>日時・日またぎ・繰り返し</span>
                          </button>

                          <button
                            type="button"
                            onClick={() => setDateSelectionMode('multi_dates')}
                            className={`px-3 py-1 rounded-lg transition flex items-center gap-1 cursor-pointer ${
                              dateSelectionMode === 'multi_dates'
                                ? 'bg-white text-emerald-800 font-bold shadow-2xs'
                                : 'text-slate-600 hover:text-slate-900'
                            }`}
                          >
                            <Layers className="w-3.5 h-3.5 text-emerald-600" />
                            <span>複数日一括入力</span>
                          </button>
                        </div>

                        <label className="inline-flex items-center gap-1.5 text-xs font-semibold text-slate-700 cursor-pointer">
                          <input
                            type="checkbox"
                            checked={isAllDay}
                            onChange={(e) => setIsAllDay(e.target.checked)}
                            className="rounded-sm text-emerald-600 focus:ring-emerald-500 w-3.5 h-3.5"
                          />
                          終日予定
                        </label>
                      </div>

                      {dateSelectionMode === 'standard' ? (
                        <>
                          <div className="space-y-2.5">
                            {/* START ROW */}
                            <div className="p-2.5 bg-white rounded-xl border border-slate-200">
                              <div className="flex items-center justify-between mb-1.5">
                                <span className="text-[11px] font-bold text-emerald-700 flex items-center gap-1">
                                  <Clock className="w-3 h-3" />
                                  開始日時
                                </span>
                                <div className="flex items-center gap-1">
                                  <button
                                    type="button"
                                    onClick={() => handleStartDateChange(addDaysStr(date, -1))}
                                    className="px-2 py-0.5 bg-slate-100 hover:bg-emerald-100 border border-slate-200 text-slate-700 rounded text-[10px] font-bold transition cursor-pointer"
                                  >
                                    ◀ 前日
                                  </button>
                                  <button
                                    type="button"
                                    onClick={() => handleStartDateChange(addDaysStr(date, 1))}
                                    className="px-2 py-0.5 bg-slate-100 hover:bg-emerald-100 border border-slate-200 text-slate-700 rounded text-[10px] font-bold transition cursor-pointer"
                                  >
                                    翌日 ▶
                                  </button>
                                </div>
                              </div>
                              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                                <div>
                                  <label className="block text-[10px] text-slate-400 mb-0.5">
                                    開始日
                                  </label>
                                  <input
                                    type="date"
                                    value={date}
                                    onChange={(e) => handleStartDateChange(e.target.value)}
                                    className="w-full p-2 bg-slate-50 border border-slate-200 rounded-lg text-xs font-bold text-slate-900"
                                  />
                                </div>
                                {!isAllDay && (
                                  <div>
                                    <label className="block text-[10px] text-slate-400 mb-0.5">
                                      開始時刻
                                    </label>
                                    <input
                                      type="time"
                                      value={startTime}
                                      onChange={(e) => setStartTime(e.target.value)}
                                      className="w-full p-2 bg-slate-50 border border-slate-200 rounded-lg text-xs font-bold text-slate-900"
                                    />
                                  </div>
                                )}
                              </div>
                            </div>

                            {/* END ROW */}
                            <div className="p-2.5 bg-white rounded-xl border border-slate-200">
                              <div className="flex flex-wrap items-center justify-between gap-1 mb-1.5">
                                <span className="text-[11px] font-bold text-blue-700 flex items-center gap-1">
                                  <ArrowRight className="w-3 h-3" />
                                  終了日時（日またぎ・宿泊も指定可）
                                </span>
                                <div className="flex items-center gap-1">
                                  <button
                                    type="button"
                                    onClick={() => setEndDate(date)}
                                    className={`px-2 py-0.5 rounded text-[10px] font-bold transition cursor-pointer ${
                                      endDate === date
                                        ? 'bg-emerald-600 text-white'
                                        : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                                    }`}
                                  >
                                    当日
                                  </button>
                                  <button
                                    type="button"
                                    onClick={() => setEndDate(addDaysStr(date, 1))}
                                    className={`px-2 py-0.5 rounded text-[10px] font-bold transition cursor-pointer ${
                                      endDate === addDaysStr(date, 1)
                                        ? 'bg-blue-600 text-white'
                                        : 'bg-blue-50 text-blue-700 hover:bg-blue-100 border border-blue-200'
                                    }`}
                                  >
                                    +1日 (翌日)
                                  </button>
                                  <button
                                    type="button"
                                    onClick={() => setEndDate(addDaysStr(date, 2))}
                                    className={`px-2 py-0.5 rounded text-[10px] font-bold transition cursor-pointer ${
                                      endDate === addDaysStr(date, 2)
                                        ? 'bg-blue-600 text-white'
                                        : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                                    }`}
                                  >
                                    +2日
                                  </button>
                                </div>
                              </div>

                              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                                <div>
                                  <label className="block text-[10px] text-slate-400 mb-0.5">
                                    終了日
                                  </label>
                                  <input
                                    type="date"
                                    min={date}
                                    value={endDate}
                                    onChange={(e) => setEndDate(e.target.value)}
                                    className="w-full p-2 bg-slate-50 border border-slate-200 rounded-lg text-xs font-bold text-slate-900"
                                  />
                                </div>
                                {!isAllDay && (
                                  <div>
                                    <label className="block text-[10px] text-slate-400 mb-0.5">
                                      終了時刻
                                    </label>
                                    <input
                                      type="time"
                                      value={endTime}
                                      onChange={(e) => handleEndTimeChange(e.target.value)}
                                      className="w-full p-2 bg-slate-50 border border-slate-200 rounded-lg text-xs font-bold text-slate-900"
                                    />
                                  </div>
                                )}
                              </div>

                              <div className="mt-2 pt-1.5 border-t border-slate-100 flex items-center justify-between text-[11px]">
                                <span className="text-slate-600 font-medium">
                                  設定期間:{' '}
                                  <strong className="text-slate-900">
                                    {date} {!isAllDay && startTime}
                                  </strong>{' '}
                                  〜{' '}
                                  <strong
                                    className={isCrossDay ? 'text-blue-700' : 'text-slate-900'}
                                  >
                                    {endDate} {!isAllDay && endTime}
                                  </strong>
                                </span>
                                {isCrossDay && (
                                  <span className="text-[10px] font-bold text-blue-700 bg-blue-50 px-2 py-0.5 rounded-md border border-blue-200">
                                    日またぎ予定
                                  </span>
                                )}
                              </div>
                            </div>
                          </div>

                          {/* Recurrence Rule Picker */}
                          <div className="pt-2 border-t border-slate-200/60 space-y-2.5">
                            <div className="flex items-center justify-between">
                              <label className="text-xs font-bold text-slate-700 flex items-center gap-1.5">
                                <Repeat className="w-3.5 h-3.5 text-emerald-600" />
                                繰り返し設定 (隔週・毎週など)
                              </label>
                            </div>

                            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                              <div>
                                <label className="block text-[11px] text-slate-500 mb-0.5">
                                  繰り返しの周期
                                </label>
                                <select
                                  value={frequency}
                                  onChange={(e) =>
                                    setFrequency(e.target.value as RecurrenceFrequency)
                                  }
                                  className="w-full p-2 bg-white border border-slate-200 rounded-xl text-xs font-medium text-slate-800"
                                >
                                  <option value="none">繰り返しなし (1回のみ)</option>
                                  <option value="daily">毎日</option>
                                  <option value="weekly">毎週 (1週間おき)</option>
                                  <option value="biweekly">隔週 (2週間おき / 14日ごと)</option>
                                  <option value="monthly">毎月 (同じ日付)</option>
                                  <option value="yearly">毎年 (同じ月日)</option>
                                  <option value="custom">カスタム間隔 (任意指定)</option>
                                </select>
                              </div>

                              {frequency !== 'none' && (
                                <div>
                                  <label className="block text-[11px] text-slate-500 mb-0.5">
                                    繰り返し間隔
                                  </label>
                                  <div className="flex items-center gap-1.5">
                                    <input
                                      type="number"
                                      min={1}
                                      max={30}
                                      value={repeatInterval}
                                      onChange={(e) =>
                                        setRepeatInterval(Math.max(1, Number(e.target.value)))
                                      }
                                      className="w-20 p-2 bg-white border border-slate-200 rounded-xl text-xs font-bold text-center"
                                    />
                                    <span className="text-xs font-medium text-slate-600">
                                      {frequency === 'daily' || frequency === 'custom'
                                        ? '日ごと'
                                        : frequency === 'weekly' || frequency === 'biweekly'
                                        ? '周期ごと'
                                        : frequency === 'monthly'
                                        ? 'か月ごと'
                                        : '年ごと'}
                                    </span>
                                  </div>
                                </div>
                              )}
                            </div>

                            {frequency !== 'none' && (
                              <div className="p-3 bg-emerald-50/70 border border-emerald-200 rounded-xl space-y-2 text-xs">
                                <div className="flex items-center justify-between text-slate-700">
                                  <span className="font-bold text-emerald-900">
                                    繰り返しの終了条件:
                                  </span>
                                  <div className="flex items-center gap-3">
                                    <label className="inline-flex items-center gap-1 cursor-pointer">
                                      <input
                                        type="radio"
                                        name="endType"
                                        checked={endType === 'count'}
                                        onChange={() => setEndType('count')}
                                        className="text-emerald-600 focus:ring-emerald-500"
                                      />
                                      <span>回数で指定</span>
                                    </label>
                                    <label className="inline-flex items-center gap-1 cursor-pointer">
                                      <input
                                        type="radio"
                                        name="endType"
                                        checked={endType === 'until_date'}
                                        onChange={() => setEndType('until_date')}
                                        className="text-emerald-600 focus:ring-emerald-500"
                                      />
                                      <span>終了日で指定</span>
                                    </label>
                                  </div>
                                </div>

                                {endType === 'count' ? (
                                  <div className="flex items-center gap-2 pt-1">
                                    <span className="text-slate-600">合計作成回数:</span>
                                    <input
                                      type="number"
                                      min={2}
                                      max={50}
                                      value={repeatCount}
                                      onChange={(e) =>
                                        setRepeatCount(Math.max(2, Number(e.target.value)))
                                      }
                                      className="w-16 p-1 bg-white border border-slate-200 rounded-lg text-xs font-bold text-center"
                                    />
                                    <span className="text-slate-600">回分まで自動作成</span>
                                  </div>
                                ) : (
                                  <div className="flex items-center gap-2 pt-1">
                                    <span className="text-slate-600">繰り返しの終了日:</span>
                                    <input
                                      type="date"
                                      value={untilDate}
                                      onChange={(e) => setUntilDate(e.target.value)}
                                      className="p-1 bg-white border border-slate-200 rounded-lg text-xs font-medium"
                                    />
                                  </div>
                                )}
                              </div>
                            )}
                          </div>
                        </>
                      ) : (
                        /* Multi-Dates Bulk Mode */
                        <div className="space-y-3">
                          <div className="text-xs text-slate-600 leading-relaxed">
                            日付を複数選んで、同じ条件の予定を一括作成します。
                          </div>

                          <div className="flex flex-wrap gap-1.5 p-2 bg-white border border-slate-200 rounded-xl min-h-[48px] items-center">
                            {multiDates.map((dStr) => (
                              <span
                                key={dStr}
                                className="px-2.5 py-1 bg-emerald-100 border border-emerald-300 text-emerald-900 rounded-lg text-xs font-semibold flex items-center gap-1"
                              >
                                <span>{dStr}</span>
                                <button
                                  type="button"
                                  onClick={() => handleRemoveMultiDate(dStr)}
                                  className="hover:text-red-600 text-slate-500 font-bold p-0.5 cursor-pointer"
                                >
                                  ✕
                                </button>
                              </span>
                            ))}
                          </div>

                          <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2">
                            <div className="flex items-center gap-2 flex-1">
                              <input
                                type="date"
                                value={newMultiDate}
                                onChange={(e) => setNewMultiDate(e.target.value)}
                                className="flex-1 p-2 bg-white border border-slate-200 rounded-xl text-xs font-medium"
                              />
                              <button
                                type="button"
                                onClick={() => handleAddMultiDate(newMultiDate)}
                                className="px-3 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold transition flex items-center gap-1 shrink-0 cursor-pointer"
                              >
                                <Plus className="w-3.5 h-3.5" /> 追加
                              </button>
                            </div>

                            <div className="flex items-center gap-1">
                              <button
                                type="button"
                                onClick={handleAddNextWeekPreset}
                                className="px-2.5 py-1.5 bg-slate-200 hover:bg-slate-300 text-slate-700 rounded-lg text-[11px] font-semibold transition shrink-0 cursor-pointer"
                              >
                                +翌週の同曜日
                              </button>
                              <button
                                type="button"
                                onClick={handleAddWeekdaysPreset}
                                className="px-2.5 py-1.5 bg-slate-200 hover:bg-slate-300 text-slate-700 rounded-lg text-[11px] font-semibold transition shrink-0 cursor-pointer"
                              >
                                +今週の平日
                              </button>
                            </div>
                          </div>

                          {!isAllDay && (
                            <div className="grid grid-cols-2 gap-2 pt-2 border-t border-slate-200/60">
                              <div>
                                <label className="block text-[10px] text-slate-500 mb-0.5">
                                  開始時刻
                                </label>
                                <input
                                  type="time"
                                  value={startTime}
                                  onChange={(e) => setStartTime(e.target.value)}
                                  className="w-full p-2 bg-white border border-slate-200 rounded-lg text-xs font-bold"
                                />
                              </div>
                              <div>
                                <label className="block text-[10px] text-slate-500 mb-0.5">
                                  終了時刻
                                </label>
                                <input
                                  type="time"
                                  value={endTime}
                                  onChange={(e) => setEndTime(e.target.value)}
                                  className="w-full p-2 bg-white border border-slate-200 rounded-lg text-xs font-bold"
                                />
                              </div>
                            </div>
                          )}
                        </div>
                      )}
                    </div>

                    {/* Members assignment */}
                    <div>
                      <label className="block text-xs font-semibold text-slate-600 mb-1.5 flex items-center gap-1.5">
                        <Users className="w-3.5 h-3.5 text-emerald-600" />
                        参加メンバー (予定を共有する相手)
                      </label>
                      <div className="flex flex-wrap gap-2">
                        {members.map((member) => {
                          const isSelected = selectedMemberIds.includes(member.id);
                          return (
                            <button
                              key={member.id}
                              type="button"
                              onClick={() => handleToggleMember(member.id)}
                              className={`flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium border transition cursor-pointer ${
                                isSelected
                                  ? 'bg-emerald-50 border-emerald-500 text-emerald-800 ring-2 ring-emerald-500/20'
                                  : 'bg-white border-slate-200 text-slate-500 hover:bg-slate-50'
                              }`}
                            >
                              <img
                                src={member.avatarUrl}
                                alt={member.name}
                                referrerPolicy="no-referrer"
                                className="w-4 h-4 rounded-full object-cover"
                              />
                              <span>{member.name}</span>
                              <span
                                className="w-2 h-2 rounded-full shrink-0"
                                style={{ backgroundColor: member.color }}
                              />
                            </button>
                          );
                        })}
                      </div>
                    </div>

                    {/* Location */}
                    <div>
                      <label className="block text-xs font-semibold text-slate-600 mb-1 flex items-center gap-1.5">
                        <MapPin className="w-3.5 h-3.5 text-emerald-600" />
                        場所・住所
                      </label>
                      <input
                        type="text"
                        value={location}
                        onChange={(e) => setLocation(e.target.value)}
                        placeholder="例: ブルーボトルコーヒー 清澄白河、草津温泉 湯畑"
                        className="w-full p-2 border border-slate-200 rounded-xl text-xs bg-slate-50"
                      />
                    </div>

                    {/* Notes */}
                    <div>
                      <label className="block text-xs font-semibold text-slate-600 mb-1">
                        備考・メモ
                      </label>
                      <textarea
                        rows={3}
                        value={notes}
                        onChange={(e) => setNotes(e.target.value)}
                        placeholder="持ち物、予約番号、電車の時間など自由に入力できます"
                        className="w-full p-2 border border-slate-200 rounded-xl text-xs bg-slate-50 resize-none"
                      />
                    </div>

                    {/* Google Calendar sync option */}
                    {isGoogleConnected && (
                      <div className="p-3 rounded-xl bg-blue-50/70 border border-blue-200 flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <div className="w-6 h-6 rounded-md bg-white flex items-center justify-center shadow-xs">
                            <svg className="w-3.5 h-3.5" viewBox="0 0 24 24">
                              <path
                                fill="#4285F4"
                                d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                              />
                              <path
                                fill="#34A853"
                                d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                              />
                              <path
                                fill="#FBBC05"
                                d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"
                              />
                              <path
                                fill="#EA4335"
                                d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"
                              />
                            </svg>
                          </div>
                          <div>
                            <div className="text-xs font-semibold text-slate-800">
                              Googleカレンダーにも反映する
                            </div>
                            <div className="text-[10px] text-slate-500">
                              お使いのGoogleカレンダーにこの予定を自動追加します
                            </div>
                          </div>
                        </div>
                        <label className="relative inline-flex items-center cursor-pointer">
                          <input
                            type="checkbox"
                            checked={syncToGoogle}
                            onChange={(e) => setSyncToGoogle(e.target.checked)}
                            className="sr-only peer"
                          />
                          <div className="w-9 h-5 bg-slate-200 peer-focus:outline-hidden rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-blue-600"></div>
                        </label>
                      </div>
                    )}
                  </form>
                )}

                {/* Checklist Tab */}
                {activeTab === 'checklist' && (
                  <div className="space-y-4">
                    <p className="text-xs text-slate-500">
                      予定に必要な持ち物やToDoリストを共有メンバーと一緒に管理できます。
                    </p>

                    <form onSubmit={handleAddChecklistItem} className="flex gap-2">
                      <input
                        type="text"
                        value={newChecklistText}
                        onChange={(e) => setNewChecklistText(e.target.value)}
                        placeholder="新しい持ち物・ToDoを追加 (例: カメラ充電、チケット発券)"
                        className="flex-1 p-2 border border-slate-200 rounded-xl text-xs bg-slate-50 focus:bg-white"
                      />
                      <button
                        type="submit"
                        className="px-3.5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-semibold flex items-center gap-1 transition cursor-pointer"
                      >
                        <Plus className="w-3.5 h-3.5" /> 追加
                      </button>
                    </form>

                    <div className="space-y-2 max-h-60 overflow-y-auto">
                      {checklist.length === 0 ? (
                        <div className="py-8 text-center text-slate-400 text-xs">
                          まだToDoや持ち物リストがありません
                        </div>
                      ) : (
                        checklist.map((item) => (
                          <div
                            key={item.id}
                            className="flex items-center justify-between p-2.5 bg-slate-50 hover:bg-slate-100 rounded-xl border border-slate-200 transition"
                          >
                            <label className="flex items-center gap-2.5 cursor-pointer text-xs flex-1">
                              <input
                                type="checkbox"
                                checked={item.done}
                                onChange={() => handleToggleChecklist(item.id)}
                                className="rounded-sm text-emerald-600 focus:ring-emerald-500 w-4 h-4"
                              />
                              <span
                                className={
                                  item.done ? 'line-through text-slate-400' : 'text-slate-800'
                                }
                              >
                                {item.text}
                              </span>
                            </label>
                            <button
                              type="button"
                              onClick={() => handleDeleteChecklistItem(item.id)}
                              className="text-slate-400 hover:text-red-500 p-1 cursor-pointer"
                            >
                              ✕
                            </button>
                          </div>
                        ))
                      )}
                    </div>
                  </div>
                )}

                {/* Chat Comments Tab */}
                {activeTab === 'chat' && (
                  <div className="flex flex-col h-80">
                    <div className="flex-1 overflow-y-auto space-y-3 pr-1">
                      {comments.length === 0 ? (
                        <div className="py-12 text-center text-slate-400 text-xs">
                          <MessageCircle className="w-8 h-8 mx-auto mb-1 text-slate-300 stroke-1" />
                          予定に関する相談や連絡をチャットできます
                        </div>
                      ) : (
                        comments.map((comm) => {
                          const isMe = comm.memberId === currentMember.id;
                          return (
                            <div
                              key={comm.id}
                              className={`flex items-start gap-2.5 ${
                                isMe ? 'flex-row-reverse' : ''
                              }`}
                            >
                              {comm.memberAvatar && (
                                <img
                                  src={comm.memberAvatar}
                                  alt={comm.memberName}
                                  referrerPolicy="no-referrer"
                                  className="w-7 h-7 rounded-full object-cover shrink-0"
                                />
                              )}
                              <div className={`max-w-[75%] ${isMe ? 'text-right' : ''}`}>
                                <div className="text-[10px] text-slate-400 mb-0.5">
                                  {comm.memberName} · {comm.createdAt}
                                </div>
                                <div
                                  className={`p-2.5 rounded-2xl text-xs inline-block text-left ${
                                    isMe
                                      ? 'bg-emerald-600 text-white rounded-tr-xs'
                                      : 'bg-slate-100 text-slate-800 rounded-tl-xs'
                                  }`}
                                >
                                  {comm.text}
                                </div>
                              </div>
                            </div>
                          );
                        })
                      )}
                    </div>

                    <form
                      onSubmit={handleSendComment}
                      className="pt-3 border-t border-slate-100 flex gap-2"
                    >
                      <input
                        type="text"
                        value={newCommentText}
                        onChange={(e) => setNewCommentText(e.target.value)}
                        placeholder="この予定についてメッセージを入力..."
                        className="flex-1 p-2 border border-slate-200 rounded-xl text-xs bg-slate-50 focus:bg-white"
                      />
                      <button
                        type="submit"
                        className="px-3.5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-semibold flex items-center gap-1 transition cursor-pointer"
                      >
                        <Send className="w-3.5 h-3.5" /> 送信
                      </button>
                    </form>
                  </div>
                )}
              </div>

              {/* Edit Footer */}
              <div className="px-5 py-3.5 border-t border-slate-100 bg-slate-50 flex items-center justify-between shrink-0">
                <button
                  type="button"
                  onClick={() => {
                    if (event?.id) {
                      setIsDuplicateCreate(false);
                      setModalMode('view');
                    } else {
                      onClose();
                    }
                  }}
                  className="px-4 py-2 border border-slate-200 bg-white text-slate-600 rounded-xl text-xs font-medium hover:bg-slate-100 transition cursor-pointer"
                >
                  キャンセル
                </button>
                <button
                  type="submit"
                  form="event-form"
                  disabled={isSubmitting}
                  className="px-5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold shadow-xs transition cursor-pointer"
                >
                  {isSubmitting
                    ? '保存中...'
                    : isDuplicateCreate
                    ? '複製して新規保存'
                    : '予定を保存'}
                </button>
              </div>
            </>
          )}
        </div>
      </div>

      {/* Mandatory User Confirmation Dialog for Google Calendar Workspace Modification */}
      {showGoogleConfirm && (
        <div className="fixed inset-0 z-[2500] bg-black/70 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-sm w-full p-5 shadow-2xl animate-in fade-in zoom-in-95">
            <div className="w-10 h-10 rounded-full bg-blue-100 text-blue-600 flex items-center justify-center mx-auto mb-3">
              <CalendarIcon className="w-5 h-5" />
            </div>
            <h4 className="text-center font-bold text-slate-900 text-sm">
              Googleカレンダーへの予定追加確認
            </h4>
            <p className="text-xs text-slate-600 text-center mt-2 leading-relaxed">
              Googleカレンダーに「<strong>{title}</strong>（{date}
              {isCrossDay ? `〜${endDate}` : ''}）」を追加します。続行しますか？
            </p>
            <div className="flex items-center gap-2 mt-5">
              <button
                type="button"
                onClick={() => setShowGoogleConfirm(false)}
                className="flex-1 py-2 border border-slate-200 text-slate-600 rounded-xl text-xs font-semibold hover:bg-slate-50 transition cursor-pointer"
              >
                キャンセル
              </button>
              <button
                type="button"
                onClick={() => saveEventInternal(true)}
                className="flex-1 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-bold transition shadow-xs cursor-pointer"
              >
                確認して追加
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
};
