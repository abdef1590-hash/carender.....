import React, { useState, useEffect } from 'react';
import {
  Camera,
  Upload,
  Sparkles,
  CheckCircle,
  AlertCircle,
  Calendar as CalendarIcon,
  Clock,
  User,
  Settings,
  Plus,
  Trash2,
  BookOpen,
  Check,
  RotateCcw,
  FileText,
  MessageSquarePlus,
  Users,
  FolderPlus,
} from 'lucide-react';
import {
  CalendarEvent,
  Member,
  SharedCalendar,
  ShiftEntry,
  ShiftParseResult,
  CustomShiftRule,
  ShiftRosterProfile,
} from '../types';
import { SAMPLE_ROSTERS, SampleRosterPreset } from '../lib/sampleRosters';
import {
  loadRosterProfiles,
  saveRosterProfiles,
  loadActiveRosterProfileId,
  saveActiveRosterProfileId,
  saveCustomShiftRules,
  DEFAULT_SHIFT_RULES,
  PARTNER_DEFAULT_SHIFT_RULES,
} from '../lib/storage';

interface RosterScannerModalProps {
  isOpen: boolean;
  onClose: () => void;
  calendars: SharedCalendar[];
  activeCalendarId: string;
  members: Member[];
  currentMemberId: string;
  onImportShifts: (events: CalendarEvent[], targetCalendarId?: string) => void;
  externalProfiles?: ShiftRosterProfile[];
  onProfilesChange?: (profiles: ShiftRosterProfile[]) => void;
}

// Preset rule templates for quick teaching
const RULE_PRESETS: { name: string; desc: string; rules: Omit<CustomShiftRule, 'id'>[] }[] = [
  {
    name: '看護師・医療 3交代制',
    desc: '日勤・準夜勤・深夜勤・公休の3交代勤務パターン',
    rules: [
      { symbol: '日', name: '日勤', startTime: '08:30', endTime: '17:15', isDayOff: false, color: '#10B981', note: '病棟日勤' },
      { symbol: '準', name: '準夜勤', startTime: '16:00', endTime: '00:30', isDayOff: false, color: '#8B5CF6', note: '準夜勤務' },
      { symbol: '深', name: '深夜勤', startTime: '00:00', endTime: '08:30', isDayOff: false, color: '#4C1D95', note: '深夜勤務' },
      { symbol: '休', name: '公休', isDayOff: true, color: '#F43F5E', note: '公休日' },
      { symbol: '○', name: '公休', isDayOff: true, color: '#F43F5E', note: '丸印は休み' },
      { symbol: '有', name: '有給休暇', isDayOff: true, color: '#EC4899', note: '有休' },
    ],
  },
  {
    name: '医療・介護 2交代制',
    desc: '日勤・夜勤（夕方〜翌朝）・明け・公休の2交代パターン',
    rules: [
      { symbol: '日', name: '日勤', startTime: '08:30', endTime: '17:30', isDayOff: false, color: '#10B981', note: '通常日勤' },
      { symbol: '夜', name: '夜勤', startTime: '16:30', endTime: '09:30', isDayOff: false, color: '#7C3AED', note: '夜勤入り' },
      { symbol: '明', name: '夜勤明け', startTime: '00:00', endTime: '09:30', isDayOff: false, color: '#6366F1', note: '午前退勤・明け休み' },
      { symbol: '休', name: '公休', isDayOff: true, color: '#F43F5E', note: '休日' },
      { symbol: '当', name: '当直', startTime: '17:00', endTime: '09:00', isDayOff: false, color: '#2563EB', note: '当直' },
    ],
  },
  {
    name: 'カフェ・飲食店 アルバイト',
    desc: '早番（ランチ）・遅番（ディナー）・通し・公休',
    rules: [
      { symbol: '早', name: '早番 (ランチ)', startTime: '09:00', endTime: '15:00', isDayOff: false, color: '#F59E0B', note: '仕込み・ランチ' },
      { symbol: '遅', name: '遅番 (ディナー)', startTime: '17:00', endTime: '23:00', isDayOff: false, color: '#EA580C', note: 'ディナー・締め' },
      { symbol: '通', name: '通し勤務', startTime: '10:00', endTime: '22:00', isDayOff: false, color: '#0284C7', note: '休憩2時間あり' },
      { symbol: '休', name: '公休', isDayOff: true, color: '#F43F5E', note: 'シフト休み' },
    ],
  },
  {
    name: '工場・製造 3交代制',
    desc: '1直（朝）・2直（夕）・3直（深夜）の規則交代制',
    rules: [
      { symbol: '1', name: '1直 (朝勤)', startTime: '07:00', endTime: '15:15', isDayOff: false, color: '#10B981', note: '第1直' },
      { symbol: '2', name: '2直 (夕勤)', startTime: '15:00', endTime: '23:15', isDayOff: false, color: '#F59E0B', note: '第2直' },
      { symbol: '3', name: '3直 (夜勤)', startTime: '23:00', endTime: '07:15', isDayOff: false, color: '#6D28D9', note: '第3直' },
      { symbol: '休', name: '公休', isDayOff: true, color: '#F43F5E', note: '交替公休' },
    ],
  },
];

// Natural language rule explanation examples
const EXPLANATION_EXAMPLES = [
  {
    label: 'A/B/C記号のシフト例',
    text: 'Aは早番で08:00〜16:30、Bは遅番で12:00〜20:30、Cは夜勤で20:00〜05:00、公と斜線(／)は休みとして読み取って',
  },
  {
    label: 'カフェ・飲食の記号例',
    text: '早は09:00〜15:00の早番、遅は17:00〜23:00の遅番、通は10:00〜22:00の通し勤務、×と空欄は公休です',
  },
  {
    label: '病院・クリニック記号例',
    text: '日は08:30〜17:15の日勤、準は16:00〜00:30の準夜勤、深は00:00〜08:30の深夜勤、○と休は公休、有は有給休暇です',
  },
];

// Generate a valid minimal PDF data URL containing an August 2026 Shift Table for instant PDF testing
function createSampleShiftPdfDataUrl(): string {
  const lines = [
    '2026-08 SHIFT ROSTER (2026年8月度 勤務シフト表 PDF)',
    'Days: 1(Sat) to 31(Mon)',
    'Staff 1: Sato (佐藤)',
    '1:A, 2:A, 3:休, 4:B, 5:B, 6:C, 7:休, 8:A, 9:A, 10:B, 11:休, 12:A, 13:B, 14:C, 15:休, 16:休, 17:A, 18:A, 19:B, 20:B, 21:休, 22:A, 23:C, 24:休, 25:A, 26:B, 27:A, 28:休, 29:B, 30:A, 31:休',
    'Staff 2: Tanaka (田中)',
    '1:休, 2:B, 3:A, 4:A, 5:休, 6:B, 7:B, 8:休, 9:C, 10:休, 11:A, 12:B, 13:休, 14:A, 15:B, 16:A, 17:休, 18:B, 19:A, 20:休, 21:B, 22:B, 23:休, 24:A, 25:休, 26:A, 27:B, 28:A, 29:休, 30:B, 31:A',
  ];

  const streamContent = [
    'BT',
    '/F1 12 Tf',
    '40 760 Td',
    ...lines.map((line, idx) => `${idx === 0 ? '' : '0 -22 Td '}(${line.replace(/[()]/g, '')}) Tj`),
    'ET',
  ].join('\n');

  const pdfText = `%PDF-1.4
1 0 obj
<< /Type /Catalog /Pages 2 0 R >>
endobj
2 0 obj
<< /Type /Pages /Kids [3 0 R] /Count 1 >>
endobj
3 0 obj
<< /Type /Page /Parent 2 0 R /Resources << /Font << /F1 4 0 R >> >> /MediaBox [0 0 612 792] /Contents 5 0 R >>
endobj
4 0 obj
<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>
endobj
5 0 obj
<< /Length ${streamContent.length} >>
stream
${streamContent}
endstream
endobj
xref
0 6
0000000000 65535 f 
0000000009 00000 n 
0000000058 00000 n 
0000000115 00000 n 
0000000229 00000 n 
0000000297 00000 n 
trailer
<< /Size 6 /Root 1 0 R >>
startxref
${350 + streamContent.length}
%%EOF`;

  const base64 = btoa(unescape(encodeURIComponent(pdfText)));
  return `data:application/pdf;base64,${base64}`;
}

export const RosterScannerModal: React.FC<RosterScannerModalProps> = ({
  isOpen,
  onClose,
  calendars,
  activeCalendarId,
  members,
  currentMemberId,
  onImportShifts,
  externalProfiles,
  onProfilesChange,
}) => {
  // Active Modal Tab: 'scan' | 'manual' | 'rules'
  const [activeTab, setActiveTab] = useState<'scan' | 'manual' | 'rules'>('scan');

  // Multi-user / Per-Roster Shift Rule Profiles
  const [rosterProfiles, setRosterProfiles] = useState<ShiftRosterProfile[]>(
    () => externalProfiles || loadRosterProfiles()
  );
  const [activeProfileId, setActiveProfileId] = useState<string>(loadActiveRosterProfileId);
  const [isCreatingProfile, setIsCreatingProfile] = useState(false);
  const [newProfileName, setNewProfileName] = useState('');
  const [newProfileMemberId, setNewProfileMemberId] = useState(currentMemberId);

  useEffect(() => {
    if (Array.isArray(externalProfiles) && externalProfiles.length > 0) {
      setRosterProfiles(externalProfiles);
    }
  }, [externalProfiles]);

  const updateAllRosterProfiles = (nextProfiles: ShiftRosterProfile[]) => {
    setRosterProfiles(nextProfiles);
    saveRosterProfiles(nextProfiles);
    onProfilesChange?.(nextProfiles);
  };

  const activeProfile =
    rosterProfiles.find((p) => p.id === activeProfileId) ||
    rosterProfiles[0] || {
      id: 'roster-default',
      name: 'たくまのシフト表',
      memberId: currentMemberId,
      rules: DEFAULT_SHIFT_RULES,
    };

  const customRules = activeProfile.rules;

  // Update rules for the currently selected shift table profile
  const setCustomRulesForActiveProfile = (
    updater: CustomShiftRule[] | ((prev: CustomShiftRule[]) => CustomShiftRule[])
  ) => {
    setRosterProfiles((prevProfiles) => {
      const updatedProfiles = prevProfiles.map((prof) => {
        if (prof.id !== activeProfile.id) return prof;
        const nextRules = typeof updater === 'function' ? updater(prof.rules) : updater;
        saveCustomShiftRules(nextRules);
        return { ...prof, rules: nextRules };
      });
      saveRosterProfiles(updatedProfiles);
      onProfilesChange?.(updatedProfiles);
      return updatedProfiles;
    });
  };

  // New Rule form (manual 1-by-1)
  const [newSymbol, setNewSymbol] = useState('');
  const [newName, setNewName] = useState('');
  const [newStartTime, setNewStartTime] = useState('08:30');
  const [newEndTime, setNewEndTime] = useState('17:15');
  const [newIsDayOff, setNewIsDayOff] = useState(false);
  const [newColor, setNewColor] = useState('#10B981');
  const [newNote, setNewNote] = useState('');
  const [ruleSaveMessage, setRuleSaveMessage] = useState<string | null>(null);

  // Natural Language Rule Explanation State (used both during scan and in rules tab)
  const [ruleExplanationText, setRuleExplanationText] = useState<string>('');
  const [isExtractingRules, setIsExtractingRules] = useState(false);
  const [autoAddedRulesNotice, setAutoAddedRulesNotice] = useState<CustomShiftRule[]>([]);

  // Scan state (Image or PDF)
  const currentYear = new Date().getFullYear();
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [selectedFileName, setSelectedFileName] = useState<string>('');
  const [mimeType, setMimeType] = useState<string>('image/jpeg');
  const [targetPerson, setTargetPerson] = useState<string>('');
  const [scanYear, setScanYear] = useState<number>(currentYear);
  const [scanMonth, setScanMonth] = useState<number>(0); // 0 = 自動検出 (AI推奨), 1..12 = 指定月
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  // Parsed shifts result
  const [parsedResult, setParsedResult] = useState<ShiftParseResult | null>(null);
  const [selectedShifts, setSelectedShifts] = useState<{ [index: number]: boolean }>({});

  // Destination options - default to current activeCalendarId so shifts appear on active screen
  const [destCalendarId, setDestCalendarId] = useState<string>(activeCalendarId);
  const [destMemberId, setDestMemberId] = useState<string>(activeProfile.memberId || currentMemberId);
  const [importDayOffs, setImportDayOffs] = useState<boolean>(true);

  // Manual stamp & pattern state
  const [manualYear, setManualYear] = useState<number>(2026);
  const [manualMonth, setManualMonth] = useState<number>(7); // 0-indexed: 7 = 8月
  const [manualShifts, setManualShifts] = useState<{
    [day: number]: {
      name: string;
      symbol: string;
      isDayOff: boolean;
      startTime?: string;
      endTime?: string;
      color: string;
    };
  }>({});
  const [selectedStampName, setSelectedStampName] = useState<string>('日勤');

  // Synchronize destination calendar and member whenever modal is opened
  useEffect(() => {
    if (isOpen) {
      setDestCalendarId(activeCalendarId);
      const matchedProfile = rosterProfiles.find((p) => p.memberId === currentMemberId);
      if (matchedProfile) {
        setActiveProfileId(matchedProfile.id);
        setDestMemberId(matchedProfile.memberId);
      } else {
        setDestMemberId(currentMemberId);
      }
    }
  }, [isOpen, activeCalendarId, currentMemberId]);

  useEffect(() => {
    saveRosterProfiles(rosterProfiles);
  }, [rosterProfiles]);

  useEffect(() => {
    saveActiveRosterProfileId(activeProfileId);
  }, [activeProfileId]);

  if (!isOpen) return null;

  // Switch active shift table profile (User 1 vs User 2 vs Custom)
  const handleSelectProfile = (profile: ShiftRosterProfile) => {
    setActiveProfileId(profile.id);
    if (profile.memberId && members.some((m) => m.id === profile.memberId)) {
      setDestMemberId(profile.memberId);
    }
    if (profile.targetPersonName) {
      setTargetPerson(profile.targetPersonName);
    }
    setAutoAddedRulesNotice([]);
  };

  // Create a new shift table profile
  const handleCreateProfile = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newProfileName.trim()) return;
    const assignedMember = members.find((m) => m.id === newProfileMemberId) || members[0];
    const isSecondUser = assignedMember?.id === 'user-aoi';
    const newProf: ShiftRosterProfile = {
      id: `roster-${Date.now()}`,
      name: newProfileName.trim(),
      memberId: assignedMember?.id || currentMemberId,
      description: `${assignedMember?.name || 'メンバー'}用のシフト表ルール`,
      rules: isSecondUser ? [...PARTNER_DEFAULT_SHIFT_RULES] : [...DEFAULT_SHIFT_RULES],
    };
    const updated = [...rosterProfiles, newProf];
    updateAllRosterProfiles(updated);
    setActiveProfileId(newProf.id);
    setDestMemberId(newProf.memberId);
    setNewProfileName('');
    setIsCreatingProfile(false);
    setRuleSaveMessage(`シフト表「${newProf.name}」を作成しました！`);
    setTimeout(() => setRuleSaveMessage(null), 3000);
  };

  // Delete a custom profile (keep at least 1 profile)
  const handleDeleteProfile = (profileId: string) => {
    if (rosterProfiles.length <= 1) return;
    const next = rosterProfiles.filter((p) => p.id !== profileId);
    updateAllRosterProfiles(next);
    if (activeProfileId === profileId) {
      setActiveProfileId(next[0].id);
      setDestMemberId(next[0].memberId);
    }
  };

  // Merge newly extracted rules into the active profile and notify user
  const mergeExtractedRulesIntoActiveProfile = (extracted: CustomShiftRule[]) => {
    if (!Array.isArray(extracted) || extracted.length === 0) return;

    setCustomRulesForActiveProfile((prevRules) => {
      const nextRules = [...prevRules];
      for (const newRule of extracted) {
        const sym = String(newRule.symbol || '').trim();
        if (!sym) continue;
        const existingIdx = nextRules.findIndex((r) => r.symbol === sym);
        const formattedRule: CustomShiftRule = {
          id: newRule.id || `rule-auto-${Date.now()}-${Math.random().toString(36).substring(2, 5)}`,
          symbol: sym,
          name: newRule.name || `${sym}勤務`,
          startTime: newRule.isDayOff ? undefined : newRule.startTime || '08:30',
          endTime: newRule.isDayOff ? undefined : newRule.endTime || '17:30',
          isDayOff: Boolean(newRule.isDayOff),
          color: newRule.color || (newRule.isDayOff ? '#F43F5E' : '#10B981'),
          note: newRule.note || '文章説明から自動追加',
        };
        if (existingIdx >= 0) {
          nextRules[existingIdx] = formattedRule;
        } else {
          nextRules.unshift(formattedRule);
        }
      }
      return nextRules;
    });

    setAutoAddedRulesNotice(extracted);
    setRuleSaveMessage(
      `文章の説明から ${extracted.length}件のルール（${extracted
        .map((r) => `「${r.symbol}」=${r.name}`)
        .join('、')}）を「${activeProfile.name}」に自動追加しました！`
    );
    setTimeout(() => setRuleSaveMessage(null), 5000);
  };

  // Standalone natural language rule extraction (from Rules tab or Scan tab button)
  const handleExtractRulesFromTextOnly = async () => {
    if (!ruleExplanationText.trim()) return;
    setIsExtractingRules(true);
    setErrorMsg(null);
    try {
      const res = await fetch('/api/roster/extract-rules', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ explanationText: ruleExplanationText }),
      });
      const data = await res.json();
      if (!res.ok || !data.success) {
        throw new Error(data.error || '文章からのルール抽出に失敗しました。');
      }
      const extracted: CustomShiftRule[] = data.rules || [];
      if (extracted.length > 0) {
        mergeExtractedRulesIntoActiveProfile(extracted);
      } else {
        setRuleSaveMessage(
          'ルールを特定できませんでした。「Aは早番(8:00〜17:00)、公は休み」のように記号と内容を入力してください。'
        );
        setTimeout(() => setRuleSaveMessage(null), 4000);
      }
    } catch (err: any) {
      setErrorMsg(err.message || '文章からのルール作成中にエラーが発生しました。');
    } finally {
      setIsExtractingRules(false);
    }
  };

  // Normalize any uploaded image (PNG, WebP, HEIC, JPEG) onto a white-background canvas at up to 2400px
  const compressImageIfNeeded = (dataUrl: string, maxDim = 2400): Promise<string> => {
    return new Promise((resolve) => {
      const img = new Image();
      img.onload = () => {
        let { width, height } = img;
        if (width > height) {
          if (width > maxDim) {
            height = Math.round((height * maxDim) / width);
            width = maxDim;
          }
        } else {
          if (height > maxDim) {
            width = Math.round((width * maxDim) / height);
            height = maxDim;
          }
        }
        const canvas = document.createElement('canvas');
        canvas.width = Math.max(width, 1);
        canvas.height = Math.max(height, 1);
        const ctx = canvas.getContext('2d');
        if (!ctx) {
          resolve(dataUrl);
          return;
        }
        ctx.fillStyle = '#ffffff';
        ctx.fillRect(0, 0, canvas.width, canvas.height);
        ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
        resolve(canvas.toDataURL('image/jpeg', 0.92));
      };
      img.onerror = () => resolve(dataUrl);
      img.src = dataUrl;
    });
  };

  // Handle local file upload (Supports both Image files AND PDF documents)
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const isPdf =
      file.type === 'application/pdf' || file.name.toLowerCase().endsWith('.pdf');

    setSelectedFileName(file.name);
    setParsedResult(null);
    setErrorMsg(null);
    setAutoAddedRulesNotice([]);

    const reader = new FileReader();
    reader.onload = async () => {
      const rawData = reader.result as string;
      if (isPdf) {
        setMimeType('application/pdf');
        setSelectedImage(rawData);
      } else {
        setMimeType('image/jpeg');
        const optimized = await compressImageIfNeeded(rawData);
        setSelectedImage(optimized);
      }
    };
    reader.readAsDataURL(file);
  };

  // Load sample PDF shift table for immediate testing
  const handleSelectSamplePdf = () => {
    const pdfDataUrl = createSampleShiftPdfDataUrl();
    setSelectedFileName('2026年8月度_勤務シフト表サンプル.pdf');
    setMimeType('application/pdf');
    setSelectedImage(pdfDataUrl);
    setTargetPerson('佐藤');
    setScanMonth(8);
    setParsedResult(null);
    setErrorMsg(null);
    setAutoAddedRulesNotice([]);
    if (!ruleExplanationText.trim()) {
      setRuleExplanationText(
        'Aは早番で08:00〜16:30、Bは遅番で12:00〜20:30、Cは夜勤で20:00〜05:00、休は公休として読み取って'
      );
    }
  };

  // Select sample preset image
  const handleSelectPreset = (preset: SampleRosterPreset) => {
    setSelectedFileName(`${preset.name}.png`);
    setTargetPerson(preset.targetPerson);
    if (preset.name.includes('8月')) {
      setScanMonth(8);
    } else if (preset.name.includes('10月')) {
      setScanMonth(10);
    } else {
      setScanMonth(0);
    }
    setParsedResult(null);
    setErrorMsg(null);
    setAutoAddedRulesNotice([]);

    if (preset.base64Data.startsWith('data:image/svg+xml')) {
      const img = new Image();
      img.onload = () => {
        const canvas = document.createElement('canvas');
        canvas.width = 1200;
        canvas.height = 700;
        const ctx = canvas.getContext('2d');
        if (ctx) {
          ctx.fillStyle = '#ffffff';
          ctx.fillRect(0, 0, canvas.width, canvas.height);
          ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
          setSelectedImage(canvas.toDataURL('image/png'));
          setMimeType('image/png');
        } else {
          setSelectedImage(preset.base64Data);
          setMimeType('image/png');
        }
      };
      img.onerror = () => {
        setSelectedImage(preset.base64Data);
        setMimeType('image/png');
      };
      img.src = preset.base64Data;
    } else {
      setSelectedImage(preset.base64Data);
      setMimeType('image/png');
    }
  };

  // Add a new custom rule manually
  const handleAddRule = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newSymbol.trim() || !newName.trim()) return;

    const rule: CustomShiftRule = {
      id: `rule-${Date.now()}`,
      symbol: newSymbol.trim(),
      name: newName.trim(),
      startTime: newIsDayOff ? undefined : newStartTime,
      endTime: newIsDayOff ? undefined : newEndTime,
      isDayOff: newIsDayOff,
      color: newColor,
      note: newNote.trim() || undefined,
    };

    setCustomRulesForActiveProfile((prev) => [
      rule,
      ...prev.filter((r) => r.symbol !== rule.symbol),
    ]);

    setNewSymbol('');
    setNewName('');
    setNewNote('');
    setRuleSaveMessage(
      `「${activeProfile.name}」に記号「${rule.symbol}」＝「${rule.name}」を登録しました！`
    );
    setTimeout(() => setRuleSaveMessage(null), 3000);
  };

  // Delete a rule from active profile
  const handleDeleteRule = (id: string) => {
    setCustomRulesForActiveProfile((prev) => prev.filter((r) => r.id !== id));
  };

  // Apply a Preset Template to active profile
  const handleApplyPresetTemplate = (preset: (typeof RULE_PRESETS)[0]) => {
    const newRules: CustomShiftRule[] = preset.rules.map((r, i) => ({
      ...r,
      id: `rule-preset-${Date.now()}-${i}`,
    }));
    setCustomRulesForActiveProfile(newRules);
    setRuleSaveMessage(
      `「${activeProfile.name}」に「${preset.name}」のルールテンプレートを適用しました！`
    );
    setTimeout(() => setRuleSaveMessage(null), 3000);
  };

  // Reset active profile rules to default
  const handleResetToDefaultRules = () => {
    const isPartner = activeProfile.memberId === 'user-aoi';
    setCustomRulesForActiveProfile(
      isPartner ? [...PARTNER_DEFAULT_SHIFT_RULES] : [...DEFAULT_SHIFT_RULES]
    );
    setRuleSaveMessage(`「${activeProfile.name}」のシフトルールを初期設定にリセットしました。`);
    setTimeout(() => setRuleSaveMessage(null), 3000);
  };

  // Call Server-Side Gemini API with Custom Rules + Natural Language Explanation
  const handleAnalyzeRoster = async (overridePerson?: string) => {
    if (!selectedImage) return;

    setIsAnalyzing(true);
    setErrorMsg(null);
    setAutoAddedRulesNotice([]);

    const personToUse = overridePerson !== undefined ? overridePerson : targetPerson;

    try {
      const res = await fetch('/api/roster/parse', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          imageBase64: selectedImage,
          mimeType,
          targetPersonName: personToUse.trim() || undefined,
          targetYear: scanYear,
          targetMonth: scanMonth > 0 ? scanMonth : undefined,
          customRules: customRules,
          ruleExplanationText: ruleExplanationText.trim() || undefined,
        }),
      });

      let data: any = {};
      try {
        data = await res.json();
      } catch {
        throw new Error(
          `サーバー応答の解析に失敗しました (Status: ${res.status})。時間をおいて再試行してください。`
        );
      }

      if (!res.ok || !data.success) {
        throw new Error(data.error || '勤務表の解析に失敗しました。');
      }

      const result: ShiftParseResult = data.data || { shifts: [] };

      // Automatically add newly extracted rules from the user's natural language explanation!
      if (Array.isArray(result.extractedRules) && result.extractedRules.length > 0) {
        mergeExtractedRulesIntoActiveProfile(result.extractedRules);
      }

      setParsedResult(result);
      if (result.personName && !targetPerson) {
        setTargetPerson(result.personName);
      }
      if (result.yearMonth) {
        const [ymY, ymM] = result.yearMonth.split('-').map(Number);
        if (ymY && ymM >= 1 && ymM <= 12) {
          setManualYear(ymY);
          setManualMonth(ymM - 1);
        }
      }

      const initialSelection: { [index: number]: boolean } = {};
      if (Array.isArray(result.shifts)) {
        result.shifts.forEach((_, idx) => {
          initialSelection[idx] = true;
        });
      }
      setSelectedShifts(initialSelection);
    } catch (err: any) {
      console.error('AI Shift Parsing error:', err);
      const isLoadFailed =
        err?.name === 'TypeError' &&
        (err?.message === 'Load failed' || err?.message === 'Failed to fetch');
      const message = isLoadFailed
        ? 'サーバーとの通信に失敗しました。通信環境をご確認いただくか、少し時間をおいて再度お試しください。'
        : err.message || 'シフト表のAI認識中にエラーが発生しました。';
      setErrorMsg(message);
    } finally {
      setIsAnalyzing(false);
    }
  };

  // Instant 0ms staff switching using cached allStaffShifts (or fallback to re-analyze)
  const handleSelectDetectedStaff = (staffName: string) => {
    setTargetPerson(staffName);
    if (parsedResult?.allStaffShifts && Array.isArray(parsedResult.allStaffShifts[staffName])) {
      const targetShifts = parsedResult.allStaffShifts[staffName];
      const counts: { [k: string]: number } = {};
      for (const s of targetShifts) {
        const k = s.isDayOff ? '公休・休み' : s.shiftType;
        counts[k] = (counts[k] || 0) + 1;
      }
      const countSummary = Object.entries(counts)
        .map(([k, v]) => `${k}:${v}日`)
        .join(' / ');
      const ymLabel = parsedResult.yearMonth || `${scanYear}年`;

      const nextSelection: { [index: number]: boolean } = {};
      targetShifts.forEach((_, idx) => {
        nextSelection[idx] = true;
      });
      setSelectedShifts(nextSelection);
      setParsedResult({
        ...parsedResult,
        personName: staffName,
        shifts: targetShifts,
        summary: `${ymLabel} (${staffName}): 計${targetShifts.length}日分 [${countSummary}]`,
      });
    } else {
      handleAnalyzeRoster(staffName);
    }
  };

  // Adjust month and year of parsed result on the fly
  const handleAdjustParsedYearMonth = (newYear: number, newMonth: number) => {
    if (!parsedResult || !Array.isArray(parsedResult.shifts)) return;
    const padM = String(newMonth).padStart(2, '0');
    const newYm = `${newYear}-${padM}`;
    const maxDays = new Date(newYear, newMonth, 0).getDate();

    const remapShifts = (list: ShiftEntry[]) =>
      list.slice(0, maxDays).map((s, idx) => {
        const origDate = s.date || '';
        const dayMatch = origDate.match(/(\d{1,2})$/);
        const dayNum = dayMatch ? parseInt(dayMatch[1], 10) : idx + 1;
        const safeDay = Math.min(Math.max(dayNum, 1), maxDays);
        return {
          ...s,
          date: `${newYear}-${padM}-${String(safeDay).padStart(2, '0')}`,
        };
      });

    const updatedAllStaff: { [k: string]: ShiftEntry[] } = {};
    if (parsedResult.allStaffShifts) {
      for (const [k, v] of Object.entries(parsedResult.allStaffShifts)) {
        if (Array.isArray(v)) {
          updatedAllStaff[k] = remapShifts(v);
        }
      }
    }

    setManualYear(newYear);
    setManualMonth(newMonth - 1);
    setParsedResult({
      ...parsedResult,
      yearMonth: newYm,
      shifts: remapShifts(parsedResult.shifts),
      allStaffShifts: updatedAllStaff,
    });
  };

  // Quick inline update of shift in review table
  const handleToggleShiftType = (idx: number, nextType: string, isDayOff: boolean) => {
    if (!parsedResult || !Array.isArray(parsedResult.shifts)) return;
    const matchedRule = customRules.find((r) => r.name === nextType || r.symbol === nextType);
    const updated = [...parsedResult.shifts];
    updated[idx] = {
      ...updated[idx],
      shiftType: nextType,
      isDayOff: isDayOff,
      startTime: isDayOff
        ? undefined
        : matchedRule?.startTime || updated[idx].startTime || '08:30',
      endTime: isDayOff
        ? undefined
        : matchedRule?.endTime || updated[idx].endTime || '17:30',
    };
    setParsedResult({
      ...parsedResult,
      shifts: updated,
    });
  };

  // Shift badge helper matching custom rules if possible
  const getShiftBadge = (type?: string, isDayOff?: boolean) => {
    const safeType = type || '';
    const matchedRule = customRules.find(
      (r) =>
        r.name === safeType ||
        r.symbol === safeType ||
        (Boolean(r.symbol) && safeType.includes(r.symbol))
    );
    if (matchedRule) {
      return { bg: 'bg-emerald-50 text-slate-800 border-slate-200', color: matchedRule.color };
    }
    if (isDayOff) {
      return { bg: 'bg-rose-100 text-rose-700 border-rose-200', color: '#F43F5E' };
    }
    if (safeType.includes('準夜') || safeType.includes('準')) {
      return { bg: 'bg-purple-100 text-purple-800 border-purple-200', color: '#8B5CF6' };
    }
    if (safeType.includes('深夜') || safeType.includes('深')) {
      return { bg: 'bg-indigo-100 text-indigo-900 border-indigo-200', color: '#4C1D95' };
    }
    if (safeType.includes('早')) {
      return { bg: 'bg-amber-100 text-amber-800 border-amber-200', color: '#F59E0B' };
    }
    if (safeType.includes('遅')) {
      return { bg: 'bg-orange-100 text-orange-800 border-orange-200', color: '#EA580C' };
    }
    if (safeType.includes('夜') || safeType.includes('当直')) {
      return { bg: 'bg-purple-100 text-purple-800 border-purple-200', color: '#7C3AED' };
    }
    return { bg: 'bg-emerald-100 text-emerald-800 border-emerald-200', color: '#10B981' };
  };

  // Final Import Action
  const handleExecuteImport = () => {
    if (!parsedResult || !Array.isArray(parsedResult.shifts) || parsedResult.shifts.length === 0)
      return;

    const eventsToCreate: CalendarEvent[] = [];

    parsedResult.shifts.forEach((shift, idx) => {
      if (!shift) return;
      if (!selectedShifts[idx]) return;
      if (!importDayOffs && shift.isDayOff) return;

      const shiftType = shift.shiftType || (shift.isDayOff ? '公休' : '日勤');
      const badge = getShiftBadge(shiftType, Boolean(shift.isDayOff));

      const event: CalendarEvent = {
        id: `shift-${Date.now()}-${idx}-${Math.random().toString(36).substring(2, 6)}`,
        calendarId: destCalendarId,
        title: shift.isDayOff ? `公休 (休み)` : `${shiftType}勤務`,
        date: shift.date || new Date().toISOString().substring(0, 10),
        startTime: shift.isDayOff ? undefined : shift.startTime || '09:00',
        endTime: shift.isDayOff ? undefined : shift.endTime || '18:00',
        isAllDay: Boolean(shift.isDayOff || (!shift.startTime && !shift.endTime)),
        memberIds: [destMemberId],
        color: badge.color,
        category: 'シフト',
        shiftType: shiftType,
        notes: [
          `AI勤務表解析 (${activeProfile.name}) より一括登録`,
          shift?.note
            ? `備考: ${typeof shift.note === 'string' ? shift.note : JSON.stringify(shift.note)}`
            : '',
          parsedResult?.personName ? `対象: ${parsedResult.personName}` : '',
        ]
          .filter(Boolean)
          .join('\n'),
      };

      eventsToCreate.push(event);
    });

    onImportShifts(eventsToCreate, destCalendarId);
    onClose();
  };

  // Available Stamps for manual shift entry (reflects active shift table profile's rules!)
  const availableStamps = [
    ...customRules,
    ...[
      { symbol: '日', name: '日勤', startTime: '08:30', endTime: '17:30', isDayOff: false, color: '#10B981' },
      { symbol: '早', name: '早番', startTime: '07:00', endTime: '16:00', isDayOff: false, color: '#F59E0B' },
      { symbol: '遅', name: '遅番', startTime: '11:00', endTime: '20:00', isDayOff: false, color: '#EA580C' },
      { symbol: '夜', name: '夜勤', startTime: '16:30', endTime: '09:30', isDayOff: false, color: '#7C3AED' },
      { symbol: '当', name: '当直', startTime: '17:00', endTime: '09:00', isDayOff: false, color: '#2563EB' },
      { symbol: '休', name: '公休', isDayOff: true, color: '#F43F5E' },
    ].filter((def) => !customRules.some((r) => r.name === def.name)),
  ];

  // Number of days in manual month and first day of week
  const daysInManualMonth = new Date(manualYear, manualMonth + 1, 0).getDate();
  const firstDayOfWeek = new Date(manualYear, manualMonth, 1).getDay();

  // Pattern batch application
  const handleApplyPattern = (pattern: 'weekday' | '2shift' | '3shift' | 'clear') => {
    if (pattern === 'clear') {
      setManualShifts({});
      return;
    }

    const nextShifts: typeof manualShifts = {};
    const daysCount = daysInManualMonth;

    if (pattern === 'weekday') {
      const dayShift =
        availableStamps.find((s) => s.name === '日勤' || !s.isDayOff) || availableStamps[0];
      const offShift = availableStamps.find((s) => s.isDayOff) || availableStamps[availableStamps.length - 1];

      for (let d = 1; d <= daysCount; d++) {
        const dow = new Date(manualYear, manualMonth, d).getDay();
        if (dow === 0 || dow === 6) {
          nextShifts[d] = { ...offShift };
        } else {
          nextShifts[d] = { ...dayShift };
        }
      }
    } else if (pattern === '2shift') {
      const dayShift = availableStamps.find((s) => s.name === '日勤') || availableStamps[0];
      const nightShift = availableStamps.find((s) => s.name.includes('夜')) || availableStamps[0];
      const offShift = availableStamps.find((s) => s.isDayOff) || availableStamps[availableStamps.length - 1];
      const cycle = [dayShift, nightShift, offShift, offShift];

      for (let d = 1; d <= daysCount; d++) {
        const item = cycle[(d - 1) % cycle.length];
        nextShifts[d] = { ...item };
      }
    } else if (pattern === '3shift') {
      const early = availableStamps.find((s) => s.name.includes('早')) || availableStamps[0];
      const late = availableStamps.find((s) => s.name.includes('遅')) || availableStamps[0];
      const night = availableStamps.find((s) => s.name.includes('夜')) || availableStamps[0];
      const off = availableStamps.find((s) => s.isDayOff) || availableStamps[availableStamps.length - 1];
      const cycle = [early, late, night, off];

      for (let d = 1; d <= daysCount; d++) {
        const item = cycle[(d - 1) % cycle.length];
        nextShifts[d] = { ...item };
      }
    }

    setManualShifts(nextShifts);
  };

  // Stamp a specific day
  const handleStampDay = (day: number) => {
    const current = manualShifts[day];
    const stamp = availableStamps.find((s) => s.name === selectedStampName) || availableStamps[0];

    if (current && current.name === stamp.name) {
      const next = { ...manualShifts };
      delete next[day];
      setManualShifts(next);
    } else {
      setManualShifts({
        ...manualShifts,
        [day]: { ...stamp },
      });
    }
  };

  // Execute manual import
  const handleExecuteManualImport = () => {
    const days = Object.keys(manualShifts)
      .map(Number)
      .filter((d) => d > 0);
    if (days.length === 0) return;

    const eventsToCreate: CalendarEvent[] = [];
    const monthStr = String(manualMonth + 1).padStart(2, '0');

    days
      .sort((a, b) => a - b)
      .forEach((day, idx) => {
        const shift = manualShifts[day];
        if (!shift) return;
        if (!importDayOffs && shift.isDayOff) return;

        const dateStr = `${manualYear}-${monthStr}-${String(day).padStart(2, '0')}`;
        const event: CalendarEvent = {
          id: `shift-manual-${Date.now()}-${idx}-${Math.random().toString(36).substring(2, 6)}`,
          calendarId: destCalendarId,
          title: shift.isDayOff ? `公休 (休み)` : `${shift.name}勤務`,
          date: dateStr,
          startTime: shift.isDayOff ? undefined : shift.startTime || '09:00',
          endTime: shift.isDayOff ? undefined : shift.endTime || '18:00',
          isAllDay: Boolean(shift.isDayOff || (!shift.startTime && !shift.endTime)),
          memberIds: [destMemberId],
          color: shift.color,
          category: 'シフト',
          shiftType: shift.name,
          notes: `手動・スタンプ入力 (${activeProfile.name}) より一括登録`,
        };

        eventsToCreate.push(event);
      });

    onImportShifts(eventsToCreate, destCalendarId);
    onClose();
  };

  const isPdfSelected = mimeType === 'application/pdf';

  return (
    <div className="fixed inset-0 z-[2000] bg-black/60 backdrop-blur-xs flex items-end sm:items-center justify-center p-0 sm:p-4 overflow-y-auto pb-safe">
      <div className="bg-white rounded-t-3xl sm:rounded-2xl max-w-3xl w-full max-h-[94vh] flex flex-col shadow-2xl animate-in fade-in zoom-in-95 duration-150 overflow-hidden">
        {/* Header */}
        <div className="px-6 py-3.5 border-b border-slate-100 flex items-center justify-between bg-gradient-to-r from-emerald-600 to-teal-700 text-white shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-white/20 backdrop-blur-xs flex items-center justify-center">
              <Camera className="w-5 h-5 text-white" />
            </div>
            <div>
              <h3 className="font-bold text-base flex items-center gap-1.5 flex-wrap">
                勤務表・シフト読取 (写真 / PDF対応)
                <span className="bg-amber-400 text-slate-900 text-[10px] font-extrabold px-1.5 py-0.5 rounded-full uppercase">
                  Gemini AI
                </span>
              </h3>
              <p className="text-xs text-emerald-100">
                2ユーザー・シフト表ごとのルール管理＆文章説明から新ルールを自動学習
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 text-white flex items-center justify-center text-sm transition cursor-pointer"
          >
            ✕
          </button>
        </div>

        {/* 2-User / Per-Roster Profile Switcher Bar */}
        <div className="px-6 py-2.5 bg-slate-100 border-b border-slate-200 shrink-0">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <div className="flex items-center gap-1.5 text-xs font-bold text-slate-700">
              <Users className="w-4 h-4 text-emerald-600 shrink-0" />
              <span>シフト表ごとのルール切替 (2ユーザー対応):</span>
            </div>

            <div className="flex items-center gap-1.5 flex-wrap">
              {rosterProfiles.map((prof) => {
                const isSelected = prof.id === activeProfile.id;
                const linkedMember = members.find((m) => m.id === prof.memberId);
                return (
                  <div key={prof.id} className="inline-flex items-center">
                    <button
                      type="button"
                      onClick={() => handleSelectProfile(prof)}
                      className={`px-3 py-1.5 rounded-xl text-xs font-bold transition flex items-center gap-1.5 cursor-pointer border ${
                        isSelected
                          ? 'bg-emerald-600 text-white border-emerald-600 shadow-xs'
                          : 'bg-white hover:bg-slate-50 text-slate-700 border-slate-200'
                      }`}
                    >
                      <span
                        className="w-2 h-2 rounded-full shrink-0"
                        style={{
                          backgroundColor: isSelected
                            ? '#ffffff'
                            : linkedMember?.color || '#10B981',
                        }}
                      />
                      <span>{prof.name}</span>
                      <span
                        className={`text-[10px] px-1.5 py-0.2 rounded-full ${
                          isSelected
                            ? 'bg-emerald-700 text-emerald-100'
                            : 'bg-slate-100 text-slate-500'
                        }`}
                      >
                        {prof.rules.length}ルール
                      </span>
                    </button>
                    {rosterProfiles.length > 2 && isSelected && (
                      <button
                        type="button"
                        onClick={() => handleDeleteProfile(prof.id)}
                        className="ml-1 p-1 text-slate-400 hover:text-red-500 rounded-md transition cursor-pointer"
                        title="このシフト表設定を削除"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </div>
                );
              })}

              <button
                type="button"
                onClick={() => setIsCreatingProfile(!isCreatingProfile)}
                className="px-2.5 py-1.5 rounded-xl text-xs font-bold bg-white hover:bg-emerald-50 text-emerald-700 border border-dashed border-emerald-300 flex items-center gap-1 transition cursor-pointer"
              >
                <FolderPlus className="w-3.5 h-3.5" />
                <span>＋シフト表を追加</span>
              </button>
            </div>
          </div>

          {/* Inline New Shift Table Profile Creator */}
          {isCreatingProfile && (
            <form
              onSubmit={handleCreateProfile}
              className="mt-2.5 p-3 bg-white rounded-xl border border-emerald-200 flex flex-wrap items-center gap-2 text-xs"
            >
              <span className="font-bold text-slate-700">新規シフト表:</span>
              <input
                type="text"
                required
                value={newProfileName}
                onChange={(e) => setNewProfileName(e.target.value)}
                placeholder="例: あおいのシフト表 (クリニック) / 副業バイト"
                className="flex-1 min-w-44 px-2.5 py-1.5 border border-slate-200 rounded-lg text-xs"
              />
              <select
                value={newProfileMemberId}
                onChange={(e) => setNewProfileMemberId(e.target.value)}
                className="px-2.5 py-1.5 border border-slate-200 rounded-lg text-xs bg-white"
              >
                {members.map((m) => (
                  <option key={m.id} value={m.id}>
                    担当: {m.name}
                  </option>
                ))}
              </select>
              <button
                type="submit"
                className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg font-bold cursor-pointer"
              >
                作成
              </button>
              <button
                type="button"
                onClick={() => setIsCreatingProfile(false)}
                className="px-2.5 py-1.5 text-slate-500 hover:text-slate-700 cursor-pointer"
              >
                キャンセル
              </button>
            </form>
          )}
        </div>

        {/* Tab Navigation: Scan vs Manual Stamp vs Rules Settings */}
        <div className="flex border-b border-slate-200 bg-white px-6 text-xs font-bold shrink-0 overflow-x-auto">
          <button
            type="button"
            onClick={() => setActiveTab('scan')}
            className={`py-3 px-3.5 border-b-2 flex items-center gap-2 transition whitespace-nowrap cursor-pointer ${
              activeTab === 'scan'
                ? 'border-emerald-600 text-emerald-700'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            <Camera className="w-4 h-4" />
            写真・PDF AI読取
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('manual')}
            className={`py-3 px-3.5 border-b-2 flex items-center gap-2 transition whitespace-nowrap cursor-pointer ${
              activeTab === 'manual'
                ? 'border-emerald-600 text-emerald-700'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            <CalendarIcon className="w-4 h-4 text-emerald-600" />
            <span>手動・スタンプ一括入力</span>
            {Object.keys(manualShifts).length > 0 && (
              <span className="bg-emerald-100 text-emerald-800 text-[10px] px-1.5 py-0.2 rounded-full">
                {Object.keys(manualShifts).length}日
              </span>
            )}
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('rules')}
            className={`py-3 px-3.5 border-b-2 flex items-center gap-2 transition whitespace-nowrap cursor-pointer ${
              activeTab === 'rules'
                ? 'border-emerald-600 text-emerald-700'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            <Settings className="w-4 h-4 text-emerald-600" />
            <span>「{activeProfile.name}」のルール設定</span>
            <span className="bg-emerald-100 text-emerald-800 text-[10px] px-1.5 py-0.2 rounded-full">
              {customRules.length}件
            </span>
          </button>
        </div>

        {/* Modal Body */}
        <div className="flex-1 overflow-y-auto p-6">
          {/* Global Rule Save / Auto-Learn Feedback Banner */}
          {ruleSaveMessage && (
            <div className="mb-4 p-3 bg-emerald-50 border border-emerald-200 rounded-xl text-xs text-emerald-900 font-bold flex items-center gap-2 animate-in fade-in">
              <Check className="w-4 h-4 text-emerald-600 shrink-0" />
              <span>{ruleSaveMessage}</span>
            </div>
          )}

          {/* TAB 1: SCAN & IMPORT (IMAGE + PDF + NATURAL LANGUAGE RULE EXPLANATION) */}
          {activeTab === 'scan' && (
            <div className="space-y-5">
              {/* Active Profile Rules Summary Bar */}
              <div className="p-3.5 bg-emerald-50/90 border border-emerald-200 rounded-xl flex flex-col sm:flex-row sm:items-center justify-between gap-2.5 text-xs">
                <div className="flex items-start sm:items-center gap-2">
                  <Sparkles className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5 sm:mt-0" />
                  <div className="text-emerald-950 leading-relaxed">
                    <span className="font-bold">選択中:「{activeProfile.name}」</span>
                    <span className="ml-1.5 text-emerald-800">
                      ({customRules.slice(0, 6).map((r) => `${r.symbol}=${r.name}`).join('・')}
                      {customRules.length > 6 ? ` 他` : ''} 計{customRules.length}件のルール適用中)
                    </span>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => setActiveTab('rules')}
                  className="px-3 py-1.5 bg-white hover:bg-emerald-100/50 border border-emerald-300 text-emerald-800 rounded-lg font-bold text-[11px] transition shrink-0 self-end sm:self-auto cursor-pointer"
                >
                  ルール一覧・編集
                </button>
              </div>

              {/* Step 1: Upload Photo / PDF or Choose Sample */}
              {!parsedResult && (
                <div className="space-y-4">
                  {/* Upload Dropzone (Image + PDF) */}
                  <div className="border-2 border-dashed border-slate-200 hover:border-emerald-500 rounded-2xl p-5 text-center bg-slate-50 hover:bg-emerald-50/30 transition cursor-pointer relative">
                    <input
                      type="file"
                      accept="image/*,application/pdf,.pdf"
                      onChange={handleFileUpload}
                      className="absolute inset-0 opacity-0 cursor-pointer w-full h-full"
                    />
                    <div className="flex items-center justify-center gap-2 mb-1.5">
                      <Upload className="w-8 h-8 text-emerald-600" />
                      <FileText className="w-8 h-8 text-indigo-500" />
                    </div>
                    <p className="text-sm font-bold text-slate-800">
                      シフト表の「写真 (JPG/PNG)」または「PDFファイル」を選択・ドロップ
                    </p>
                    <p className="text-xs text-slate-500 mt-1">
                      スマホで撮影した勤務表の写真・スクリーンショット・職場から配布されたPDFシフト表に対応
                    </p>
                  </div>

                  {/* Sample Presets (Images + Sample PDF) */}
                  <div>
                    <div className="flex flex-wrap items-center justify-between gap-2 mb-2">
                      <p className="text-xs font-semibold text-slate-600 flex items-center gap-1">
                        <Sparkles className="w-3.5 h-3.5 text-amber-500" />
                        サンプル勤務表（写真・PDF）で即座にテストできます：
                      </p>
                      <button
                        type="button"
                        onClick={handleSelectSamplePdf}
                        className={`px-3 py-1.5 rounded-xl border text-xs font-bold flex items-center gap-1.5 transition cursor-pointer ${
                          isPdfSelected
                            ? 'bg-indigo-600 text-white border-indigo-600 shadow-xs'
                            : 'bg-indigo-50 hover:bg-indigo-100 text-indigo-800 border-indigo-200'
                        }`}
                      >
                        <FileText className="w-3.5 h-3.5" />
                        サンプルPDFシフト表を読み込む (未登録記号 A/B/C テスト用)
                      </button>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
                      {SAMPLE_ROSTERS.map((preset) => (
                        <button
                          key={preset.id}
                          type="button"
                          onClick={() => handleSelectPreset(preset)}
                          className={`p-3 text-left rounded-xl border text-xs transition flex flex-col justify-between cursor-pointer ${
                            selectedImage === preset.base64Data
                              ? 'border-emerald-500 bg-emerald-50/50 ring-2 ring-emerald-500/30'
                              : 'border-slate-200 hover:border-slate-300 bg-white hover:bg-slate-50'
                          }`}
                        >
                          <div>
                            <div className="font-bold text-slate-900">{preset.name}</div>
                            <div className="text-[11px] text-emerald-700 mt-0.5">{preset.role}</div>
                            <div className="text-[10px] text-slate-400 mt-1 line-clamp-2">
                              {preset.description}
                            </div>
                          </div>
                          <div className="mt-2 rounded-lg overflow-hidden border border-slate-200 bg-white">
                            <img
                              src={preset.base64Data}
                              alt={preset.name}
                              className="w-full h-16 object-contain block"
                            />
                          </div>
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Natural Language Rule Explanation Box (Always accessible so user can explain untaught rules in text) */}
                  <div className="p-4 bg-gradient-to-r from-amber-50/90 to-emerald-50/70 rounded-2xl border border-amber-200/90 space-y-2.5">
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <label className="text-xs font-bold text-slate-900 flex items-center gap-1.5">
                        <MessageSquarePlus className="w-4 h-4 text-amber-600 shrink-0" />
                        <span>
                          教えていないルール・記号がある場合は文章で説明（読取と同時に「{activeProfile.name}」のルールへ自動追加）
                        </span>
                      </label>
                      {ruleExplanationText.trim() && (
                        <button
                          type="button"
                          onClick={handleExtractRulesFromTextOnly}
                          disabled={isExtractingRules}
                          className="px-2.5 py-1 bg-white hover:bg-emerald-50 text-emerald-700 border border-emerald-300 rounded-lg text-[11px] font-bold transition cursor-pointer"
                        >
                          {isExtractingRules ? '抽出中...' : '＋この文章から今すぐルールに追加'}
                        </button>
                      )}
                    </div>

                    <textarea
                      rows={2}
                      value={ruleExplanationText}
                      onChange={(e) => setRuleExplanationText(e.target.value)}
                      placeholder="例: 「Aは早番で8:00〜16:30、Bは遅番で12:00〜20:30、Cは夜勤で20:00〜05:00、斜線(／)と公は休みとして読み取って」"
                      className="w-full p-2.5 text-xs bg-white border border-amber-300 focus:border-emerald-500 rounded-xl text-slate-800 placeholder:text-slate-400"
                    />

                    <div className="flex flex-wrap items-center gap-1.5 text-[11px]">
                      <span className="text-slate-500 font-medium">例文をタップで入力:</span>
                      {EXPLANATION_EXAMPLES.map((ex, i) => (
                        <button
                          key={i}
                          type="button"
                          onClick={() => setRuleExplanationText(ex.text)}
                          className="px-2 py-0.5 bg-white hover:bg-amber-100/70 border border-amber-200 rounded-md text-slate-700 font-medium transition cursor-pointer"
                        >
                          {ex.label}
                        </button>
                      ))}
                      {ruleExplanationText && (
                        <button
                          type="button"
                          onClick={() => setRuleExplanationText('')}
                          className="px-2 py-0.5 text-slate-400 hover:text-slate-600 underline cursor-pointer"
                        >
                          クリア
                        </button>
                      )}
                    </div>
                  </div>

                  {/* Selected Image or PDF Preview & Target Person Input */}
                  {selectedImage && (
                    <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 space-y-3">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <span className="text-xs font-bold text-slate-700">
                            選択中のシフト表プレビュー:
                          </span>
                          {isPdfSelected ? (
                            <span className="px-2 py-0.5 bg-indigo-100 text-indigo-800 rounded-md text-[11px] font-bold flex items-center gap-1">
                              <FileText className="w-3 h-3" />
                              PDF: {selectedFileName || 'シフト表.pdf'}
                            </span>
                          ) : (
                            selectedFileName && (
                              <span className="text-xs text-slate-500">{selectedFileName}</span>
                            )
                          )}
                        </div>
                        <button
                          type="button"
                          onClick={() => {
                            setSelectedImage(null);
                            setSelectedFileName('');
                          }}
                          className="text-xs text-red-600 hover:underline font-medium cursor-pointer"
                        >
                          ファイルを変更する
                        </button>
                      </div>

                      {isPdfSelected ? (
                        <div className="w-full rounded-xl border border-indigo-200 bg-white p-3 space-y-2">
                          <div className="flex items-center justify-between bg-indigo-50/70 px-3 py-2 rounded-lg">
                            <div className="flex items-center gap-2">
                              <FileText className="w-5 h-5 text-indigo-600 shrink-0" />
                              <div>
                                <div className="text-xs font-bold text-indigo-950">
                                  {selectedFileName || 'シフト表ドキュメント.pdf'}
                                </div>
                                <div className="text-[11px] text-indigo-700">
                                  Gemini Multimodal PDF解析対応 — 表内の日付・氏名・記号を直接読み取ります
                                </div>
                              </div>
                            </div>
                            <span className="text-[10px] font-bold bg-indigo-600 text-white px-2 py-0.5 rounded-full">
                              PDF読込済
                            </span>
                          </div>
                          <iframe
                            src={selectedImage}
                            title="PDF Shift Preview"
                            className="w-full h-44 rounded-lg border border-slate-200 bg-slate-50"
                          />
                        </div>
                      ) : (
                        <div className="w-full overflow-hidden rounded-lg border border-slate-200 bg-white p-2 flex items-center justify-center">
                          <img
                            src={selectedImage}
                            alt="Roster Preview"
                            className="w-full max-h-60 object-contain block mx-auto"
                          />
                        </div>
                      )}

                      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-2">
                        {/* Target Year & Month Selector */}
                        <div>
                          <label className="block text-xs font-semibold text-slate-700 mb-1">
                            対象年月 (表内の月を指定):
                          </label>
                          <div className="flex gap-1.5">
                            <select
                              value={scanYear}
                              onChange={(e) => setScanYear(Number(e.target.value))}
                              className="w-22 px-2 py-1.5 border border-slate-200 rounded-lg text-xs bg-white font-medium"
                            >
                              <option value={2025}>2025年</option>
                              <option value={2026}>2026年</option>
                              <option value={2027}>2027年</option>
                            </select>
                            <select
                              value={scanMonth}
                              onChange={(e) => setScanMonth(Number(e.target.value))}
                              className="flex-1 px-2 py-1.5 border border-slate-200 rounded-lg text-xs bg-white font-medium"
                            >
                              <option value={0}>🤖 自動検出 (推奨)</option>
                              <option value={1}>1月</option>
                              <option value={2}>2月</option>
                              <option value={3}>3月</option>
                              <option value={4}>4月</option>
                              <option value={5}>5月</option>
                              <option value={6}>6月</option>
                              <option value={7}>7月</option>
                              <option value={8}>8月</option>
                              <option value={9}>9月</option>
                              <option value={10}>10月</option>
                              <option value={11}>11月</option>
                              <option value={12}>12月</option>
                            </select>
                          </div>
                        </div>

                        {/* Target Person Name with Quick Chips */}
                        <div>
                          <label className="block text-xs font-semibold text-slate-700 mb-1">
                            読み取る対象者氏名:
                          </label>
                          <input
                            type="text"
                            value={targetPerson}
                            onChange={(e) => setTargetPerson(e.target.value)}
                            placeholder="例: 佐藤、田中 (空欄=1人目)"
                            className="w-full px-3 py-1.5 border border-slate-200 rounded-lg text-xs bg-white"
                          />
                          <div className="flex items-center gap-1 mt-1.5 flex-wrap">
                            <button
                              type="button"
                              onClick={() => setTargetPerson('')}
                              className={`px-1.5 py-0.5 rounded text-[10px] transition cursor-pointer ${
                                targetPerson === ''
                                  ? 'bg-emerald-600 text-white font-bold'
                                  : 'bg-slate-100 hover:bg-slate-200 text-slate-600'
                              }`}
                            >
                              先頭スタッフ
                            </button>
                            {members.map((m) => (
                              <button
                                key={m.id}
                                type="button"
                                onClick={() => setTargetPerson(m.name)}
                                className={`px-1.5 py-0.5 rounded text-[10px] transition cursor-pointer ${
                                  targetPerson === m.name
                                    ? 'bg-emerald-600 text-white font-bold'
                                    : 'bg-slate-100 hover:bg-slate-200 text-slate-600'
                                }`}
                              >
                                {m.name}
                              </button>
                            ))}
                          </div>
                        </div>

                        {/* Destination Member */}
                        <div>
                          <label className="block text-xs font-semibold text-slate-700 mb-1">
                            カレンダー登録先メンバー:
                          </label>
                          <select
                            value={destMemberId}
                            onChange={(e) => setDestMemberId(e.target.value)}
                            className="w-full px-3 py-1.5 border border-slate-200 rounded-lg text-xs bg-white"
                          >
                            {members.map((m) => (
                              <option key={m.id} value={m.id}>
                                {m.name}
                              </option>
                            ))}
                          </select>
                        </div>
                      </div>

                      {errorMsg && (
                        <div className="p-3.5 rounded-xl bg-rose-50 border border-rose-200 text-rose-800 text-xs space-y-2">
                          <div className="flex items-center gap-2">
                            <AlertCircle className="w-4 h-4 shrink-0 text-rose-600" />
                            <span>{errorMsg}</span>
                          </div>
                          <button
                            type="button"
                            onClick={() => setActiveTab('manual')}
                            className="px-3 py-1.5 bg-rose-600 hover:bg-rose-700 text-white rounded-lg font-bold text-xs transition flex items-center gap-1.5 cursor-pointer"
                          >
                            <CalendarIcon className="w-3.5 h-3.5" />
                            手動・スタンプ入力に切り替えて勤務表を登録する
                          </button>
                        </div>
                      )}

                      <button
                        type="button"
                        onClick={() => handleAnalyzeRoster()}
                        disabled={isAnalyzing}
                        className="w-full py-2.5 bg-emerald-600 hover:bg-emerald-700 disabled:bg-emerald-400 text-white rounded-xl text-sm font-bold shadow-md transition flex items-center justify-center gap-2 cursor-pointer"
                      >
                        {isAnalyzing ? (
                          <>
                            <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                            {isPdfSelected
                              ? 'PDFシフト表をAIが高精度解析＆ルール学習中...'
                              : 'シフト表をAIが高精度解析＆ルール学習中...'}
                          </>
                        ) : (
                          <>
                            <Sparkles className="w-4 h-4 text-amber-300" />
                            {ruleExplanationText.trim()
                              ? `文章の説明で「${activeProfile.name}」のルールを自動追加してAI解析する`
                              : targetPerson
                              ? `「${targetPerson}」のシフトをAI解析する (${activeProfile.name})`
                              : `シフト表をAI解析する (${activeProfile.name})`}
                          </>
                        )}
                      </button>
                    </div>
                  )}
                </div>
              )}

              {/* Step 2: Review and Bulk Import Parsed Shifts */}
              {parsedResult && (
                <div className="space-y-4">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                    <div>
                      <h4 className="font-bold text-slate-900 text-sm flex items-center gap-2">
                        {parsedResult.shifts.length > 0 ? (
                          <>
                            <CheckCircle className="w-4 h-4 text-emerald-600" />
                            解析結果: {parsedResult.shifts.length}件のシフトを特定しました ({activeProfile.name})
                          </>
                        ) : (
                          <>
                            <AlertCircle className="w-4 h-4 text-amber-600" />
                            シフトを検出できませんでした
                          </>
                        )}
                      </h4>
                      {parsedResult.summary && (
                        <p className="text-xs text-slate-500 mt-0.5">{parsedResult.summary}</p>
                      )}
                    </div>
                    <div className="flex items-center gap-2">
                      <button
                        type="button"
                        onClick={() => handleAnalyzeRoster()}
                        disabled={isAnalyzing}
                        className="text-xs px-2.5 py-1 bg-emerald-50 hover:bg-emerald-100 text-emerald-700 border border-emerald-200 rounded-lg font-medium transition cursor-pointer flex items-center gap-1"
                      >
                        <RotateCcw className="w-3 h-3" />
                        再解析
                      </button>
                      <button
                        type="button"
                        onClick={() => setParsedResult(null)}
                        className="text-xs text-slate-500 hover:text-slate-800 underline cursor-pointer"
                      >
                        別の写真・PDFに変更
                      </button>
                    </div>
                  </div>

                  {/* Newly Auto-Added Rules Highlight Box */}
                  {autoAddedRulesNotice.length > 0 && (
                    <div className="p-3 bg-emerald-50 border border-emerald-300 rounded-xl text-xs space-y-1.5">
                      <div className="font-bold text-emerald-950 flex items-center gap-1.5">
                        <Sparkles className="w-4 h-4 text-emerald-600" />
                        <span>
                          文章の説明から以下のルールを自動学習し、「{activeProfile.name}」のルールブックに保存しました：
                        </span>
                      </div>
                      <div className="flex flex-wrap gap-1.5">
                        {autoAddedRulesNotice.map((r, i) => (
                          <span
                            key={i}
                            className="px-2 py-0.5 rounded-md bg-white border border-emerald-200 font-bold text-[11px] text-slate-800 flex items-center gap-1"
                          >
                            <span
                              className="w-2 h-2 rounded-full"
                              style={{ backgroundColor: r.color }}
                            />
                            記号「{r.symbol}」→ {r.name}{' '}
                            {r.isDayOff ? '(休日)' : `(${r.startTime}〜${r.endTime})`}
                          </span>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Inline Natural Language Rule Explanation for Re-Scanning if user spots an untaught symbol */}
                  <div className="p-3 bg-amber-50/70 border border-amber-200 rounded-xl space-y-2 text-xs">
                    <div className="font-bold text-amber-950 flex items-center gap-1.5">
                      <MessageSquarePlus className="w-3.5 h-3.5 text-amber-600" />
                      <span>
                        まだ教えていない記号がありましたか？文章で説明して再読取すると自動でルールに追加されます：
                      </span>
                    </div>
                    <div className="flex flex-col sm:flex-row gap-2">
                      <input
                        type="text"
                        value={ruleExplanationText}
                        onChange={(e) => setRuleExplanationText(e.target.value)}
                        placeholder="例: 「Aは早番(8:00〜16:30)、Bは遅番(12:00〜20:30)、公は休み」"
                        className="flex-1 px-3 py-1.5 bg-white border border-amber-300 rounded-lg text-xs"
                      />
                      <button
                        type="button"
                        disabled={isAnalyzing || !ruleExplanationText.trim()}
                        onClick={() => handleAnalyzeRoster()}
                        className="px-3.5 py-1.5 bg-amber-600 hover:bg-amber-700 disabled:bg-slate-300 text-white rounded-lg font-bold text-xs transition shrink-0 cursor-pointer"
                      >
                        {isAnalyzing ? '解析中...' : '説明を反映して再読取＆ルール自動追加'}
                      </button>
                    </div>
                  </div>

                  {/* Empty Result Notification */}
                  {parsedResult.shifts.length === 0 ? (
                    <div className="p-4 bg-amber-50/80 border border-amber-200 rounded-2xl text-xs space-y-3">
                      <p className="text-amber-900 leading-relaxed font-medium">
                        ファイルからシフト行を特定できませんでした。対象者の氏名「
                        <strong>{targetPerson || '指定なし'}</strong>
                        」が表内と一致しているかご確認ください。
                      </p>
                      <div className="flex flex-wrap items-center gap-2 pt-1">
                        <button
                          type="button"
                          onClick={() => setActiveTab('manual')}
                          className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl font-bold transition flex items-center gap-1.5 cursor-pointer shadow-xs"
                        >
                          <CalendarIcon className="w-4 h-4" />
                          手動・スタンプ入力でシフトを登録する
                        </button>
                        <button
                          type="button"
                          onClick={() => setParsedResult(null)}
                          className="px-3.5 py-2 bg-white hover:bg-slate-50 border border-slate-300 text-slate-700 rounded-xl font-medium transition cursor-pointer"
                        >
                          別の写真・PDFを試す
                        </button>
                      </div>
                    </div>
                  ) : (
                    <>
                      {/* Detected staff names chips if available */}
                      {Array.isArray(parsedResult.detectedStaffNames) &&
                        parsedResult.detectedStaffNames.length > 0 && (
                          <div className="p-3 bg-blue-50/80 border border-blue-200 rounded-xl flex flex-wrap items-center gap-1.5 text-xs">
                            <span className="text-blue-900 font-bold shrink-0 flex items-center gap-1">
                              <User className="w-3.5 h-3.5 text-blue-600" />
                              表内のスタッフ (タップで即座に切替):
                            </span>
                            {parsedResult.detectedStaffNames.map((name, i) => (
                              <button
                                key={i}
                                type="button"
                                disabled={isAnalyzing}
                                onClick={() => handleSelectDetectedStaff(name)}
                                className={`px-2.5 py-1 rounded-lg text-xs transition cursor-pointer font-medium ${
                                  parsedResult.personName === name
                                    ? 'bg-blue-600 text-white font-bold shadow-xs'
                                    : 'bg-white hover:bg-blue-100 text-blue-800 border border-blue-200'
                                }`}
                              >
                                {name} {parsedResult.personName === name ? '✓' : ''}
                              </button>
                            ))}
                          </div>
                        )}

                      {/* Target settings & Year-Month Correction */}
                      <div className="bg-slate-50 p-3.5 rounded-xl border border-slate-200 grid grid-cols-1 sm:grid-cols-4 gap-3 text-xs">
                        <div>
                          <label className="block font-semibold text-slate-700 mb-1">
                            解析年月:
                          </label>
                          <div className="flex items-center gap-1.5">
                            <span className="font-bold text-emerald-800 bg-emerald-100/70 px-2 py-1 rounded-lg border border-emerald-200 text-xs">
                              {parsedResult.yearMonth || `${scanYear}年`}
                            </span>
                            <select
                              value={
                                parsedResult.yearMonth
                                  ? parseInt(parsedResult.yearMonth.split('-')[1], 10)
                                  : scanMonth || 8
                              }
                              onChange={(e) => {
                                const newM = Number(e.target.value);
                                const parsedY = parsedResult.yearMonth
                                  ? parseInt(parsedResult.yearMonth.split('-')[0], 10)
                                  : scanYear;
                                handleAdjustParsedYearMonth(parsedY, newM);
                              }}
                              className="px-2 py-1 border border-slate-300 rounded-lg text-xs bg-white font-medium cursor-pointer"
                            >
                              {Array.from({ length: 12 }, (_, i) => i + 1).map((m) => (
                                <option key={m} value={m}>
                                  {m}月に変更
                                </option>
                              ))}
                            </select>
                          </div>
                        </div>

                        <div>
                          <label className="block font-semibold text-slate-700 mb-1">
                            追加先カレンダー:
                          </label>
                          <select
                            value={destCalendarId}
                            onChange={(e) => setDestCalendarId(e.target.value)}
                            className="w-full p-1.5 border border-slate-200 rounded-lg bg-white"
                          >
                            {calendars.map((c) => (
                              <option key={c.id} value={c.id}>
                                {c.emoji} {c.name}
                              </option>
                            ))}
                          </select>
                        </div>

                        <div>
                          <label className="block font-semibold text-slate-700 mb-1">
                            対象メンバー:
                          </label>
                          <select
                            value={destMemberId}
                            onChange={(e) => setDestMemberId(e.target.value)}
                            className="w-full p-1.5 border border-slate-200 rounded-lg bg-white"
                          >
                            {members.map((m) => (
                              <option key={m.id} value={m.id}>
                                {m.name}
                              </option>
                            ))}
                          </select>
                        </div>

                        <div className="flex items-center pt-4 sm:pt-5">
                          <label className="inline-flex items-center gap-1.5 cursor-pointer font-medium text-slate-700">
                            <input
                              type="checkbox"
                              checked={importDayOffs}
                              onChange={(e) => setImportDayOffs(e.target.checked)}
                              className="rounded-sm text-emerald-600 focus:ring-emerald-500 w-4 h-4 cursor-pointer"
                            />
                            公休(休み)も登録する
                          </label>
                        </div>
                      </div>

                      {/* Table of extracted shifts */}
                      <div className="border border-slate-200 rounded-xl overflow-hidden max-h-72 overflow-y-auto">
                        <table className="w-full text-left text-xs">
                          <thead className="bg-slate-100 text-slate-600 font-semibold sticky top-0 z-10 border-b border-slate-200">
                            <tr>
                              <th className="p-2.5 w-10 text-center">
                                <input
                                  type="checkbox"
                                  checked={
                                    Object.values(selectedShifts).filter(Boolean).length ===
                                    parsedResult.shifts.length
                                  }
                                  onChange={(e) => {
                                    const val = e.target.checked;
                                    const next: { [key: number]: boolean } = {};
                                    parsedResult.shifts.forEach((_, idx) => {
                                      next[idx] = val;
                                    });
                                    setSelectedShifts(next);
                                  }}
                                  className="rounded-sm text-emerald-600 cursor-pointer"
                                />
                              </th>
                              <th className="p-2.5">日付</th>
                              <th className="p-2.5">表の記号</th>
                              <th className="p-2.5">シフト種別 (変更可)</th>
                              <th className="p-2.5">勤務時間</th>
                            </tr>
                          </thead>
                          <tbody className="divide-y divide-slate-100 bg-white">
                            {parsedResult.shifts.map((shift, idx) => {
                              if (!shift) return null;
                              const isSelected = !!selectedShifts[idx];
                              const shiftType =
                                shift.shiftType || (shift.isDayOff ? '公休' : '日勤');
                              const badge = getShiftBadge(shiftType, Boolean(shift.isDayOff));

                              return (
                                <tr
                                  key={idx}
                                  className={`hover:bg-slate-50 transition ${
                                    isSelected ? 'bg-emerald-50/20' : 'opacity-60'
                                  }`}
                                >
                                  <td className="p-2.5 text-center">
                                    <input
                                      type="checkbox"
                                      checked={isSelected}
                                      onChange={(e) =>
                                        setSelectedShifts({
                                          ...selectedShifts,
                                          [idx]: e.target.checked,
                                        })
                                      }
                                      className="rounded-sm text-emerald-600 cursor-pointer"
                                    />
                                  </td>
                                  <td className="p-2.5 font-medium text-slate-900 whitespace-nowrap">
                                    {shift.date || '-'}
                                  </td>
                                  <td className="p-2.5">
                                    <span className="px-1.5 py-0.5 rounded bg-slate-100 text-slate-700 font-mono font-bold text-[11px] border border-slate-200">
                                      {shift.rawSymbol || shiftType}
                                    </span>
                                  </td>
                                  <td className="p-2.5">
                                    <select
                                      value={shift.isDayOff ? '公休' : shiftType}
                                      onChange={(e) => {
                                        const nextVal = e.target.value;
                                        const matchedRule = customRules.find(
                                          (r) => r.name === nextVal
                                        );
                                        const isOff =
                                          matchedRule !== undefined
                                            ? matchedRule.isDayOff
                                            : nextVal === '公休' ||
                                              nextVal === '有給休暇' ||
                                              nextVal === '夏季・特別休';
                                        handleToggleShiftType(idx, nextVal, isOff);
                                      }}
                                      className="px-2 py-0.5 rounded-md text-[11px] font-bold border cursor-pointer"
                                      style={{
                                        borderColor: `${badge.color}40`,
                                        backgroundColor: `${badge.color}15`,
                                        color: badge.color,
                                      }}
                                    >
                                      <option value="日勤">日勤</option>
                                      <option value="早番">早番</option>
                                      <option value="遅番">遅番</option>
                                      <option value="準夜勤">準夜勤</option>
                                      <option value="深夜勤">深夜勤</option>
                                      <option value="夜勤">夜勤</option>
                                      <option value="夜勤明け">夜勤明け</option>
                                      <option value="当直">当直</option>
                                      <option value="公休">公休 (休み)</option>
                                      <option value="有給休暇">有給休暇</option>
                                      <option value="夏季・特別休">夏季・特別休</option>
                                      {customRules
                                        .filter(
                                          (r) =>
                                            ![
                                              '日勤',
                                              '早番',
                                              '遅番',
                                              '準夜勤',
                                              '深夜勤',
                                              '夜勤',
                                              '夜勤明け',
                                              '当直',
                                              '公休',
                                              '有給休暇',
                                              '夏季・特別休',
                                            ].includes(r.name)
                                        )
                                        .map((r) => (
                                          <option key={r.id} value={r.name}>
                                            {r.name} ({r.symbol})
                                          </option>
                                        ))}
                                    </select>
                                  </td>
                                  <td className="p-2.5 text-slate-600">
                                    {shift.isDayOff
                                      ? '終日休み'
                                      : shift.startTime
                                      ? `${shift.startTime} 〜 ${shift.endTime || ''}`
                                      : '時間指定なし'}
                                  </td>
                                </tr>
                              );
                            })}
                          </tbody>
                        </table>
                      </div>

                      {/* Actions */}
                      <div className="flex items-center justify-between pt-2">
                        <span className="text-xs text-slate-500">
                          {Object.values(selectedShifts).filter(Boolean).length} 件のシフトを選択中
                        </span>
                        <div className="flex items-center gap-2">
                          <button
                            type="button"
                            onClick={onClose}
                            className="px-4 py-2 border border-slate-200 text-slate-600 rounded-xl text-xs font-medium hover:bg-slate-50 transition cursor-pointer"
                          >
                            キャンセル
                          </button>
                          <button
                            type="button"
                            onClick={handleExecuteImport}
                            className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold shadow-md transition flex items-center gap-1.5 cursor-pointer"
                          >
                            <CheckCircle className="w-4 h-4" />
                            カレンダーに一括登録する
                          </button>
                        </div>
                      </div>
                    </>
                  )}
                </div>
              )}
            </div>
          )}

          {/* TAB 2: MANUAL STAMP & PATTERN ENTRY */}
          {activeTab === 'manual' && (
            <div className="space-y-4">
              {/* Header bar: Month Selector + Destination Settings */}
              <div className="bg-slate-50 p-3.5 rounded-xl border border-slate-200 space-y-3">
                <div className="flex flex-wrap items-center justify-between gap-3">
                  {/* Month navigation */}
                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => {
                        if (manualMonth === 0) {
                          setManualYear(manualYear - 1);
                          setManualMonth(11);
                        } else {
                          setManualMonth(manualMonth - 1);
                        }
                      }}
                      className="px-2.5 py-1.5 bg-white border border-slate-200 hover:bg-slate-100 rounded-lg text-xs font-bold text-slate-700 transition cursor-pointer"
                    >
                      ‹ 前月
                    </button>
                    <span className="text-sm font-bold text-slate-900 px-1">
                      {manualYear}年 {manualMonth + 1}月
                    </span>
                    <button
                      type="button"
                      onClick={() => {
                        if (manualMonth === 11) {
                          setManualYear(manualYear + 1);
                          setManualMonth(0);
                        } else {
                          setManualMonth(manualMonth + 1);
                        }
                      }}
                      className="px-2.5 py-1.5 bg-white border border-slate-200 hover:bg-slate-100 rounded-lg text-xs font-bold text-slate-700 transition cursor-pointer"
                    >
                      翌月 ›
                    </button>
                  </div>

                  {/* Destination calendar & member selection */}
                  <div className="flex flex-wrap items-center gap-2 text-xs">
                    <div className="flex items-center gap-1">
                      <span className="text-slate-500 font-medium">追加先:</span>
                      <select
                        value={destCalendarId}
                        onChange={(e) => setDestCalendarId(e.target.value)}
                        className="px-2.5 py-1.5 bg-white border border-slate-200 rounded-lg text-xs font-medium"
                      >
                        {calendars.map((c) => (
                          <option key={c.id} value={c.id}>
                            {c.emoji} {c.name}
                          </option>
                        ))}
                      </select>
                    </div>

                    <div className="flex items-center gap-1">
                      <span className="text-slate-500 font-medium">対象:</span>
                      <select
                        value={destMemberId}
                        onChange={(e) => setDestMemberId(e.target.value)}
                        className="px-2.5 py-1.5 bg-white border border-slate-200 rounded-lg text-xs font-medium"
                      >
                        {members.map((m) => (
                          <option key={m.id} value={m.id}>
                            {m.name}
                          </option>
                        ))}
                      </select>
                    </div>

                    <label className="inline-flex items-center gap-1.5 cursor-pointer ml-1">
                      <input
                        type="checkbox"
                        checked={importDayOffs}
                        onChange={(e) => setImportDayOffs(e.target.checked)}
                        className="rounded-sm text-emerald-600 focus:ring-emerald-500 w-3.5 h-3.5"
                      />
                      <span className="text-slate-700">公休も登録</span>
                    </label>
                  </div>
                </div>

                {/* Quick Pattern Application */}
                <div className="pt-2 border-t border-slate-200 flex flex-wrap items-center justify-between gap-2 text-xs">
                  <div className="flex items-center gap-1.5 text-slate-600 font-semibold">
                    <Sparkles className="w-3.5 h-3.5 text-amber-500" />
                    <span>パターン一括適用:</span>
                  </div>
                  <div className="flex flex-wrap items-center gap-1.5">
                    <button
                      type="button"
                      onClick={() => handleApplyPattern('weekday')}
                      className="px-2.5 py-1 bg-white hover:bg-emerald-50 border border-slate-200 hover:border-emerald-300 rounded-lg text-slate-700 text-[11px] font-medium transition cursor-pointer"
                    >
                      平日日勤＋土日休み
                    </button>
                    <button
                      type="button"
                      onClick={() => handleApplyPattern('2shift')}
                      className="px-2.5 py-1 bg-white hover:bg-emerald-50 border border-slate-200 hover:border-emerald-300 rounded-lg text-slate-700 text-[11px] font-medium transition cursor-pointer"
                    >
                      2交代 (日→夜→明→休)
                    </button>
                    <button
                      type="button"
                      onClick={() => handleApplyPattern('3shift')}
                      className="px-2.5 py-1 bg-white hover:bg-emerald-50 border border-slate-200 hover:border-emerald-300 rounded-lg text-slate-700 text-[11px] font-medium transition cursor-pointer"
                    >
                      3交代 (早→遅→夜→休)
                    </button>
                    <button
                      type="button"
                      onClick={() => handleApplyPattern('clear')}
                      className="px-2.5 py-1 bg-white hover:bg-red-50 border border-slate-200 hover:border-red-300 text-slate-500 hover:text-red-600 rounded-lg text-[11px] font-medium transition cursor-pointer"
                    >
                      クリア
                    </button>
                  </div>
                </div>
              </div>

              {/* Shift Stamp Palette */}
              <div>
                <p className="text-xs font-semibold text-slate-700 mb-1.5 flex items-center justify-between">
                  <span>
                    「{activeProfile.name}」のスタンプを選択（選択後、下の日付をタップして配置）：
                  </span>
                  <span className="text-[11px] text-slate-400 font-normal">
                    同じ日付をもう一度押すと解除
                  </span>
                </p>
                <div className="flex flex-wrap gap-2">
                  {availableStamps.map((stamp) => {
                    const isSelected = selectedStampName === stamp.name;
                    return (
                      <button
                        key={`${stamp.symbol}-${stamp.name}`}
                        type="button"
                        onClick={() => setSelectedStampName(stamp.name)}
                        className={`px-3 py-1.5 rounded-xl border text-xs font-bold transition flex items-center gap-1.5 cursor-pointer ${
                          isSelected
                            ? 'ring-2 ring-emerald-500 shadow-xs'
                            : 'bg-white hover:bg-slate-50'
                        }`}
                        style={{
                          borderColor: isSelected ? stamp.color : '#e2e8f0',
                          backgroundColor: isSelected ? `${stamp.color}15` : undefined,
                          color: isSelected ? stamp.color : '#334155',
                        }}
                      >
                        <span
                          className="w-2.5 h-2.5 rounded-full shrink-0"
                          style={{ backgroundColor: stamp.color }}
                        />
                        <span>{stamp.name}</span>
                        {stamp.startTime && (
                          <span className="text-[10px] opacity-70 font-normal">
                            {stamp.startTime}~{stamp.endTime || ''}
                          </span>
                        )}
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Mini Calendar Grid for stamping */}
              <div className="border border-slate-200 rounded-2xl overflow-hidden bg-white shadow-2xs">
                <div className="grid grid-cols-7 bg-slate-50 border-b border-slate-200 text-center py-2 text-xs font-bold text-slate-500">
                  <span className="text-rose-500">日</span>
                  <span>月</span>
                  <span>火</span>
                  <span>水</span>
                  <span>木</span>
                  <span>金</span>
                  <span className="text-blue-500">土</span>
                </div>

                <div className="grid grid-cols-7 divide-x divide-y divide-slate-100 bg-slate-50/20">
                  {Array.from({ length: firstDayOfWeek }).map((_, i) => (
                    <div key={`empty-${i}`} className="h-16 bg-slate-50/50" />
                  ))}

                  {Array.from({ length: daysInManualMonth }).map((_, i) => {
                    const day = i + 1;
                    const shift = manualShifts[day];
                    const dow = new Date(manualYear, manualMonth, day).getDay();
                    const isSunday = dow === 0;
                    const isSaturday = dow === 6;

                    return (
                      <button
                        key={day}
                        type="button"
                        onClick={() => handleStampDay(day)}
                        className={`h-16 p-1.5 text-left transition flex flex-col justify-between hover:bg-emerald-50/40 relative cursor-pointer ${
                          shift ? 'bg-emerald-50/25' : 'bg-white'
                        }`}
                      >
                        <span
                          className={`text-xs font-bold ${
                            isSunday
                              ? 'text-rose-600'
                              : isSaturday
                              ? 'text-blue-600'
                              : 'text-slate-700'
                          }`}
                        >
                          {day}
                        </span>

                        {shift ? (
                          <span
                            className="px-1.5 py-0.5 rounded-md text-[10px] font-bold border truncate block text-center"
                            style={{
                              backgroundColor: `${shift.color}15`,
                              color: shift.color,
                              borderColor: `${shift.color}35`,
                            }}
                          >
                            {shift.name}
                          </span>
                        ) : (
                          <span className="text-[10px] text-slate-300 self-center opacity-0 hover:opacity-100">
                            +
                          </span>
                        )}
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Summary and Registration action */}
              <div className="p-3.5 bg-slate-50 rounded-xl border border-slate-200 flex flex-col sm:flex-row items-center justify-between gap-3">
                <div className="text-xs text-slate-600">
                  <span className="font-bold text-slate-900">
                    登録予定: {Object.keys(manualShifts).length} 日分
                  </span>
                  <span className="ml-2 text-slate-500">
                    (出勤 {Object.values(manualShifts).filter((s) => !s.isDayOff).length}日 / 休み{' '}
                    {Object.values(manualShifts).filter((s) => s.isDayOff).length}日)
                  </span>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={onClose}
                    className="px-4 py-2 border border-slate-200 text-slate-600 rounded-xl text-xs font-medium hover:bg-slate-100 transition cursor-pointer"
                  >
                    キャンセル
                  </button>
                  <button
                    type="button"
                    onClick={handleExecuteManualImport}
                    disabled={Object.keys(manualShifts).length === 0}
                    className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-700 disabled:bg-slate-300 disabled:cursor-not-allowed text-white rounded-xl text-xs font-bold shadow-md transition flex items-center gap-1.5 cursor-pointer"
                  >
                    <CheckCircle className="w-4 h-4" />
                    この勤務表をカレンダーに登録する
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* TAB 3: TEACH AI SHIFT RULES (PER SHIFT TABLE PROFILE) */}
          {activeTab === 'rules' && (
            <div className="space-y-6">
              {/* Teaching Guide Header */}
              <div className="p-4 bg-gradient-to-r from-blue-50 to-indigo-50 border border-blue-200 rounded-2xl flex items-start gap-3">
                <BookOpen className="w-5 h-5 text-blue-600 mt-0.5 shrink-0" />
                <div className="text-xs text-blue-900 leading-relaxed">
                  <h4 className="font-bold text-sm text-blue-950 mb-1">
                    「{activeProfile.name}」専用のシフトルール設定
                  </h4>
                  <p>
                    2ユーザーそれぞれのシフト表や職場ごとに異なる記号ルールを独立して保存できます。上のバーから「たくまのシフト表」「あおいのシフト表」を切り替えて設定でき、文章で説明して自動登録することも可能です。
                  </p>
                </div>
              </div>

              {/* Natural Language Rule Teaching Card in Rules Tab */}
              <div className="p-4 bg-gradient-to-r from-amber-50 to-emerald-50 border border-amber-200 rounded-2xl space-y-3">
                <div className="text-xs font-bold text-slate-900 flex items-center gap-1.5">
                  <MessageSquarePlus className="w-4 h-4 text-amber-600" />
                  <span>
                    文章で説明してルールを自動作成・追加（「{activeProfile.name}」に保存されます）
                  </span>
                </div>
                <textarea
                  rows={2}
                  value={ruleExplanationText}
                  onChange={(e) => setRuleExplanationText(e.target.value)}
                  placeholder="例: 「Aは早番で8:00〜16:30、Bは遅番で12:00〜20:30、Cは夜勤で20:00〜05:00、斜線(／)と公は休み」"
                  className="w-full p-2.5 text-xs bg-white border border-amber-300 rounded-xl"
                />
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div className="flex flex-wrap items-center gap-1.5 text-[11px]">
                    <span className="text-slate-500">例文:</span>
                    {EXPLANATION_EXAMPLES.map((ex, i) => (
                      <button
                        key={i}
                        type="button"
                        onClick={() => setRuleExplanationText(ex.text)}
                        className="px-2 py-0.5 bg-white hover:bg-amber-100 border border-amber-200 rounded-md text-slate-700 cursor-pointer"
                      >
                        {ex.label}
                      </button>
                    ))}
                  </div>
                  <button
                    type="button"
                    disabled={isExtractingRules || !ruleExplanationText.trim()}
                    onClick={handleExtractRulesFromTextOnly}
                    className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 disabled:bg-slate-300 text-white rounded-xl text-xs font-bold transition shadow-xs flex items-center gap-1.5 cursor-pointer"
                  >
                    <Sparkles className="w-3.5 h-3.5" />
                    {isExtractingRules
                      ? 'AIが文章からルールを解析中...'
                      : '文章からルールを自動作成して追加'}
                  </button>
                </div>
              </div>

              {/* Quick Template Buttons */}
              <div>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs font-bold text-slate-700 flex items-center gap-1.5">
                    <Sparkles className="w-3.5 h-3.5 text-amber-500" />
                    職種別テンプレートから「{activeProfile.name}」へ一括設定:
                  </span>
                  <button
                    type="button"
                    onClick={handleResetToDefaultRules}
                    className="text-[11px] text-slate-500 hover:text-slate-700 flex items-center gap-1 cursor-pointer"
                  >
                    <RotateCcw className="w-3 h-3" /> 初期ルールに戻す
                  </button>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2">
                  {RULE_PRESETS.map((preset, pIdx) => (
                    <button
                      key={pIdx}
                      type="button"
                      onClick={() => handleApplyPresetTemplate(preset)}
                      className="p-2.5 text-left bg-slate-50 hover:bg-emerald-50/70 border border-slate-200 hover:border-emerald-400 rounded-xl text-xs transition group cursor-pointer"
                    >
                      <div className="font-bold text-slate-800 group-hover:text-emerald-800">
                        {preset.name}
                      </div>
                      <div className="text-[10px] text-slate-500 mt-0.5 line-clamp-1">
                        {preset.desc}
                      </div>
                    </button>
                  ))}
                </div>
              </div>

              {/* Add New Rule Form (1 by 1) */}
              <form
                onSubmit={handleAddRule}
                className="p-4 bg-slate-50 rounded-2xl border border-slate-200 space-y-3"
              >
                <div className="text-xs font-bold text-slate-800 flex items-center gap-1.5">
                  <Plus className="w-4 h-4 text-emerald-600" />
                  個別に記号・シフトルールを追加 ({activeProfile.name})
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-6 gap-2.5">
                  <div className="col-span-1">
                    <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                      表の記号 <span className="text-red-500">*</span>
                    </label>
                    <input
                      type="text"
                      required
                      value={newSymbol}
                      onChange={(e) => setNewSymbol(e.target.value)}
                      placeholder="例: 準, 深, A"
                      className="w-full px-2.5 py-1.5 text-center font-bold text-sm bg-white border border-slate-200 rounded-lg"
                    />
                  </div>

                  <div className="col-span-2">
                    <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                      シフト名称 <span className="text-red-500">*</span>
                    </label>
                    <input
                      type="text"
                      required
                      value={newName}
                      onChange={(e) => setNewName(e.target.value)}
                      placeholder="例: 準夜勤, 深夜勤, 当直"
                      className="w-full px-2.5 py-1.5 text-xs bg-white border border-slate-200 rounded-lg"
                    />
                  </div>

                  <div className="col-span-1">
                    <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                      開始時刻
                    </label>
                    <input
                      type="time"
                      disabled={newIsDayOff}
                      value={newStartTime}
                      onChange={(e) => setNewStartTime(e.target.value)}
                      className="w-full px-2 py-1.5 text-xs bg-white border border-slate-200 rounded-lg disabled:bg-slate-100"
                    />
                  </div>

                  <div className="col-span-1">
                    <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                      終了時刻
                    </label>
                    <input
                      type="time"
                      disabled={newIsDayOff}
                      value={newEndTime}
                      onChange={(e) => setNewEndTime(e.target.value)}
                      className="w-full px-2 py-1.5 text-xs bg-white border border-slate-200 rounded-lg disabled:bg-slate-100"
                    />
                  </div>

                  <div className="col-span-1">
                    <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                      表示色
                    </label>
                    <input
                      type="color"
                      value={newColor}
                      onChange={(e) => setNewColor(e.target.value)}
                      className="w-full h-8 cursor-pointer p-0.5 border border-slate-200 rounded-lg bg-white"
                    />
                  </div>
                </div>

                <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 pt-1">
                  <div className="flex items-center gap-4">
                    <label className="inline-flex items-center gap-1.5 text-xs font-semibold text-slate-700 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={newIsDayOff}
                        onChange={(e) => setNewIsDayOff(e.target.checked)}
                        className="rounded-sm text-emerald-600 focus:ring-emerald-500 w-4 h-4"
                      />
                      休日（公休・有給）として扱う
                    </label>
                    <input
                      type="text"
                      value={newNote}
                      onChange={(e) => setNewNote(e.target.value)}
                      placeholder="備考（例: 引き継ぎ30分あり）"
                      className="px-2.5 py-1 text-xs bg-white border border-slate-200 rounded-lg w-48"
                    />
                  </div>

                  <button
                    type="submit"
                    className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold transition shadow-xs flex items-center gap-1 cursor-pointer"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    このルールを追加する
                  </button>
                </div>
              </form>

              {/* Current Configured Rules Grid */}
              <div>
                <h4 className="text-xs font-bold text-slate-700 mb-2">
                  「{activeProfile.name}」の登録済みシフトルール一覧 ({customRules.length}件)
                </h4>

                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2.5">
                  {customRules.map((rule) => (
                    <div
                      key={rule.id}
                      className="p-3 bg-white rounded-xl border border-slate-200 shadow-2xs hover:border-slate-300 transition flex items-start justify-between gap-2"
                    >
                      <div className="flex items-start gap-2.5">
                        <span
                          className="w-8 h-8 rounded-lg flex items-center justify-center font-bold text-sm shrink-0 shadow-2xs border"
                          style={{
                            backgroundColor: `${rule.color}15`,
                            color: rule.color,
                            borderColor: `${rule.color}30`,
                          }}
                        >
                          {rule.symbol}
                        </span>
                        <div>
                          <div className="text-xs font-bold text-slate-900 flex items-center gap-1.5">
                            <span>{rule.name}</span>
                            {rule.isDayOff && (
                              <span className="px-1.5 py-0.2 bg-rose-100 text-rose-700 text-[9px] font-bold rounded-sm">
                                休日
                              </span>
                            )}
                          </div>
                          <div className="text-[11px] text-slate-500 mt-0.5 flex items-center gap-1">
                            <Clock className="w-3 h-3 text-slate-400" />
                            {rule.isDayOff
                              ? '終日休み'
                              : rule.startTime
                              ? `${rule.startTime} 〜 ${rule.endTime || ''}`
                              : '時間指定なし'}
                          </div>
                          {rule.note && (
                            <div className="text-[10px] text-slate-400 mt-0.5 line-clamp-1">
                              {rule.note}
                            </div>
                          )}
                        </div>
                      </div>

                      <button
                        type="button"
                        onClick={() => handleDeleteRule(rule.id)}
                        className="text-slate-400 hover:text-red-500 p-1 rounded-md transition cursor-pointer"
                        title="ルールを削除"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  ))}
                </div>
              </div>

              {/* Ready to scan button */}
              <div className="pt-2 flex justify-end">
                <button
                  type="button"
                  onClick={() => setActiveTab('scan')}
                  className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold shadow-md transition flex items-center gap-1.5 cursor-pointer"
                >
                  <Camera className="w-4 h-4" />
                  「{activeProfile.name}」のルールでスキャン画面に戻る
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
