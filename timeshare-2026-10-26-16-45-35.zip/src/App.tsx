import React, { useState, useEffect, useCallback, useRef } from 'react';
import { User } from 'firebase/auth';
import { CheckCircle2 } from 'lucide-react';
import { Header } from './components/Header';
import { CalendarView } from './components/CalendarView';
import { MapAndPlacesView } from './components/MapAndPlacesView';
import { EventModal } from './components/EventModal';
import { RosterScannerModal } from './components/RosterScannerModal';
import { ShareModal } from './components/ShareModal';
import { GoogleCalendarSyncModal } from './components/GoogleCalendarSyncModal';
import { UserManagementModal, PasswordUnlockModal } from './components/UserManagementModal';

import {
  CalendarEvent,
  SharedCalendar,
  PinnedPlace,
  Member,
  ShiftRosterProfile,
} from './types';
import {
  loadCalendars,
  saveCalendars,
  loadEvents,
  saveEvents,
  loadPinnedPlaces,
  savePinnedPlaces,
  loadActiveCalendarId,
  saveActiveCalendarId,
  loadActiveMemberId,
  saveActiveMemberId,
  loadRosterProfiles,
  saveRosterProfiles,
  DEFAULT_SHIFT_RULES,
  CURRENT_USER,
} from './lib/storage';
import { initAuth, getAccessToken } from './lib/firebaseAuth';
import {
  fetchGoogleCalendarEvents,
  convertGoogleEventToLocal,
  pushEventToGoogleCalendar,
} from './lib/googleCalendar';

export default function App() {
  // Main Data States
  const [calendars, setCalendars] = useState<SharedCalendar[]>(loadCalendars);
  const [activeCalendarId, setActiveCalendarId] = useState<string>(loadActiveCalendarId);
  const [events, setEvents] = useState<CalendarEvent[]>(loadEvents);
  const [places, setPinnedPlaces] = useState<PinnedPlace[]>(loadPinnedPlaces);
  const [rosterProfiles, setRosterProfiles] = useState<ShiftRosterProfile[]>(loadRosterProfiles);
  const [activeMemberId, setActiveMemberId] = useState<string>(loadActiveMemberId);

  // Active View: Calendar or Pinned Places & Map
  const [activeView, setActiveView] = useState<'calendar' | 'map'>('calendar');

  // Google Calendar Auth States
  const [googleUser, setGoogleUser] = useState<User | null>(null);
  const [accessToken, setAccessToken] = useState<string | null>(null);
  const [isSyncingGoogle, setIsSyncingGoogle] = useState(false);

  // Modals
  const [isEventModalOpen, setIsEventModalOpen] = useState(false);
  const [selectedEvent, setSelectedEvent] = useState<Partial<CalendarEvent> | null>(null);
  const [isRosterScannerOpen, setIsRosterScannerOpen] = useState(false);
  const [isShareModalOpen, setIsShareModalOpen] = useState(false);
  const [shareModalTab, setShareModalTab] = useState<'share' | 'join' | 'create'>('share');
  const [isGoogleSyncModalOpen, setIsGoogleSyncModalOpen] = useState(false);
  const [isUserModalOpen, setIsUserModalOpen] = useState(false);
  const [pendingUnlockMember, setPendingUnlockMember] = useState<Member | null>(null);

  // Real-time Sync States
  const clientIdRef = useRef<string>(
    `client-${Date.now()}-${Math.random().toString(36).substring(2, 8)}`
  );
  const lastVersionRef = useRef<number>(0);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [isLiveConnected, setIsLiveConnected] = useState(true);
  const [onlineCount, setOnlineCount] = useState(1);
  const [lastSyncedLabel, setLastSyncedLabel] = useState<string>(() =>
    new Date().toLocaleTimeString('ja-JP', { hour: '2-digit', minute: '2-digit' })
  );

  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [calendarFocusDate, setCalendarFocusDate] = useState<string | null>(null);

  const showToast = useCallback((msg: string, duration = 4000) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage((prev) => (prev === msg ? null : prev));
    }, duration);
  }, []);

  // Active calendar object
  const activeCalendar =
    calendars.find((c) => c.id === activeCalendarId) || calendars[0] || {
      id: 'default',
      name: '共有カレンダー',
      description: '',
      color: '#10B981',
      emoji: '📅',
      inviteCode: 'TREE-1234',
      members: [CURRENT_USER],
    };

  // Current acting member
  const currentMember =
    activeCalendar.members.find((m) => m.id === activeMemberId) ||
    activeCalendar.members[0] ||
    CURRENT_USER;

  // Apply authoritative state received from server / another device
  const applyRemoteState = useCallback(
    (remoteState: any, notifyMsg?: string) => {
      if (!remoteState || typeof remoteState.version !== 'number') return;
      if (remoteState.version <= 0) return;

      lastVersionRef.current = remoteState.version;

      if (Array.isArray(remoteState.calendars) && remoteState.calendars.length > 0) {
        setCalendars(remoteState.calendars);
        saveCalendars(remoteState.calendars);
      }
      if (Array.isArray(remoteState.events)) {
        setEvents(remoteState.events);
        saveEvents(remoteState.events);
      }
      if (Array.isArray(remoteState.places)) {
        setPinnedPlaces(remoteState.places);
        savePinnedPlaces(remoteState.places);
      }
      if (Array.isArray(remoteState.rosterProfiles) && remoteState.rosterProfiles.length > 0) {
        setRosterProfiles(remoteState.rosterProfiles);
        saveRosterProfiles(remoteState.rosterProfiles);
      }

      const nowStr = new Date().toLocaleTimeString('ja-JP', {
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit',
      });
      setLastSyncedLabel(nowStr);

      if (notifyMsg) {
        showToast(notifyMsg, 3500);
      }
    },
    [showToast]
  );

  // Push local state change to server so all other connected devices update in real time
  const pushStateToServer = useCallback(
    async (
      nextCalendars: SharedCalendar[],
      nextEvents: CalendarEvent[],
      nextPlaces: PinnedPlace[],
      nextProfiles: ShiftRosterProfile[],
      actionLabel?: string
    ) => {
      try {
        const res = await fetch('/api/sync/update', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            clientId: clientIdRef.current,
            updatedBy: currentMember.name,
            actionLabel,
            calendars: nextCalendars,
            events: nextEvents,
            places: nextPlaces,
            rosterProfiles: nextProfiles,
          }),
        });
        if (res.ok) {
          const data = await res.json();
          if (data?.state?.version) {
            lastVersionRef.current = data.state.version;
          }
          setLastSyncedLabel(
            new Date().toLocaleTimeString('ja-JP', {
              hour: '2-digit',
              minute: '2-digit',
              second: '2-digit',
            })
          );
        }
      } catch (err) {
        console.warn('Failed to push state to server:', err);
      }

      // Also broadcast over BroadcastChannel for instant 0ms cross-tab sync
      try {
        const bc = new BroadcastChannel('timeshare_realtime_sync');
        bc.postMessage({
          clientId: clientIdRef.current,
          updatedBy: currentMember.name,
          actionLabel,
          calendars: nextCalendars,
          events: nextEvents,
          places: nextPlaces,
          rosterProfiles: nextProfiles,
        });
        bc.close();
      } catch {
        // Ignore if BroadcastChannel is not supported
      }
    },
    [currentMember.name]
  );

  // Fetch latest shared state from server (used on initial mount, window focus, and manual Refresh button)
  const fetchLatestServerState = useCallback(
    async (isManualClick = false) => {
      if (isManualClick) setIsRefreshing(true);
      try {
        const res = await fetch(`/api/sync/state?t=${Date.now()}`, {
          cache: 'no-store',
        });
        if (!res.ok) throw new Error(`HTTP ${res.status}`);
        const data = await res.json();
        if (typeof data.onlineCount === 'number' && data.onlineCount > 0) {
          setOnlineCount(data.onlineCount);
        }
        const st = data.state;
        if (st && st.version > 0) {
          applyRemoteState(
            st,
            isManualClick
              ? `最新の予定・シフト・ユーザー情報を同期しました！（${new Date().toLocaleTimeString(
                  'ja-JP',
                  { hour: '2-digit', minute: '2-digit' }
                )}）`
              : undefined
          );
        } else if (st && st.version === 0) {
          // Server has no state yet: seed it with our current local state
          await fetch('/api/sync/update', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              clientId: clientIdRef.current,
              updatedBy: currentMember.name,
              isInitialSeed: true,
              calendars,
              events,
              places,
              rosterProfiles,
            }),
          });
          if (isManualClick) {
            showToast('現在の予定データをサーバーと同期しました！');
          }
        }
        setIsLiveConnected(true);
      } catch (err) {
        console.warn('Sync fetch error:', err);
        if (isManualClick) {
          showToast('同期確認を完了しました（ローカル最新データ表示中）');
        }
      } finally {
        if (isManualClick) setIsRefreshing(false);
      }
    },
    [applyRemoteState, calendars, currentMember.name, events, places, rosterProfiles, showToast]
  );

  // Set up initial sync, Server-Sent Events (SSE) stream, BroadcastChannel, and focus listener
  useEffect(() => {
    fetchLatestServerState(false);

    // 1. Live Server-Sent Events (SSE) connection
    let es: EventSource | null = null;
    let reconnectTimer: ReturnType<typeof setTimeout> | null = null;

    const connectSse = () => {
      try {
        es = new EventSource('/api/sync/stream');
        es.onopen = () => {
          setIsLiveConnected(true);
        };
        es.onmessage = (evt) => {
          try {
            const msg = JSON.parse(evt.data);
            if (typeof msg.onlineCount === 'number' && msg.onlineCount > 0) {
              setOnlineCount(msg.onlineCount);
            }
            if (msg.type === 'connected' && msg.state?.version > lastVersionRef.current) {
              applyRemoteState(msg.state);
            } else if (
              msg.type === 'state:updated' &&
              msg.clientId !== clientIdRef.current &&
              msg.state
            ) {
              const actor = msg.updatedBy ? `${msg.updatedBy}さんが` : '別端末から';
              const action = msg.actionLabel || '予定・シフト';
              applyRemoteState(msg.state, `🔄 ${actor}${action}を更新しました（リアルタイム反映済）`);
            }
          } catch {
            // Ignore malformed SSE message
          }
        };
        es.onerror = () => {
          setIsLiveConnected(false);
          es?.close();
          if (reconnectTimer) clearTimeout(reconnectTimer);
          reconnectTimer = setTimeout(connectSse, 4000);
        };
      } catch {
        setIsLiveConnected(false);
      }
    };

    connectSse();

    // 2. BroadcastChannel for instant cross-tab updates
    let bc: BroadcastChannel | null = null;
    try {
      bc = new BroadcastChannel('timeshare_realtime_sync');
      bc.onmessage = (ev) => {
        const msg = ev.data;
        if (msg && msg.clientId !== clientIdRef.current) {
          if (Array.isArray(msg.calendars)) setCalendars(msg.calendars);
          if (Array.isArray(msg.events)) setEvents(msg.events);
          if (Array.isArray(msg.places)) setPinnedPlaces(msg.places);
          if (Array.isArray(msg.rosterProfiles)) setRosterProfiles(msg.rosterProfiles);
          showToast(
            `🔄 ${msg.updatedBy || '別タブ'}の変更をリアルタイム反映しました`,
            3000
          );
        }
      };
    } catch {
      // BroadcastChannel not supported
    }

    // 3. Auto-sync when user returns to tab or unlocks phone
    const handleVisibilityOrFocus = () => {
      if (document.visibilityState === 'visible') {
        fetchLatestServerState(false);
      }
    };
    window.addEventListener('focus', handleVisibilityOrFocus);
    document.addEventListener('visibilitychange', handleVisibilityOrFocus);

    return () => {
      es?.close();
      if (reconnectTimer) clearTimeout(reconnectTimer);
      bc?.close();
      window.removeEventListener('focus', handleVisibilityOrFocus);
      document.removeEventListener('visibilitychange', handleVisibilityOrFocus);
    };
  }, []); // Run once on mount

  // Persist local state changes
  useEffect(() => {
    saveCalendars(calendars);
  }, [calendars]);

  useEffect(() => {
    saveEvents(events);
  }, [events]);

  useEffect(() => {
    savePinnedPlaces(places);
  }, [places]);

  useEffect(() => {
    saveRosterProfiles(rosterProfiles);
  }, [rosterProfiles]);

  useEffect(() => {
    saveActiveCalendarId(activeCalendarId);
  }, [activeCalendarId]);

  useEffect(() => {
    saveActiveMemberId(activeMemberId);
  }, [activeMemberId]);

  // Firebase Auth Listener
  useEffect(() => {
    const unsubscribe = initAuth(
      (user, token) => {
        setGoogleUser(user);
        setAccessToken(token);
      },
      () => {
        setGoogleUser(null);
        setAccessToken(null);
      }
    );
    return () => unsubscribe();
  }, []);

  // Fetch Google Calendar events and merge into state
  const handleSyncGoogleEvents = useCallback(async () => {
    const token = accessToken || (await getAccessToken());
    if (!token) return;

    setIsSyncingGoogle(true);
    try {
      const gEvents = await fetchGoogleCalendarEvents(token);
      const convertedEvents = gEvents.map((gEv) =>
        convertGoogleEventToLocal(gEv, activeCalendarId, currentMember.id)
      );

      setEvents((prev) => {
        const nonGoogleEvents = prev.filter((e) => !e.id.startsWith('google-'));
        const next = [...nonGoogleEvents, ...convertedEvents];
        pushStateToServer(calendars, next, places, rosterProfiles, 'Googleカレンダー同期');
        return next;
      });
    } catch (err: any) {
      console.error('Failed to sync Google Calendar events:', err);
      throw err;
    } finally {
      setIsSyncingGoogle(false);
    }
  }, [
    accessToken,
    activeCalendarId,
    calendars,
    currentMember.id,
    places,
    pushStateToServer,
    rosterProfiles,
  ]);

  // Calendar selection
  const handleSelectCalendar = (calId: string) => {
    setActiveCalendarId(calId);
  };

  // Member switcher (checks if target member is password-protected!)
  const handleSwitchMember = (memberId: string) => {
    if (memberId === activeMemberId) return;
    const target = activeCalendar.members.find((m) => m.id === memberId);
    if (target && target.isPasswordProtected && target.password) {
      setPendingUnlockMember(target);
      return;
    }
    setActiveMemberId(memberId);
    if (target) {
      showToast(`操作ユーザーを「${target.name}」に切り替えました`);
    }
  };

  // Select user from UserManagementModal
  const handleSelectUserFromModal = (member: Member) => {
    if (member.id === activeMemberId) {
      setIsUserModalOpen(false);
      return;
    }
    if (member.isPasswordProtected && member.password) {
      setPendingUnlockMember(member);
      return;
    }
    setActiveMemberId(member.id);
    setIsUserModalOpen(false);
    showToast(`操作ユーザーを「${member.name}」に切り替えました`);
  };

  // Add New User (with optional password & dedicated shift profile)
  const handleAddUser = (
    newMember: Member,
    addToAllCalendars: boolean,
    createShiftProfile: boolean
  ) => {
    const nextCalendars = calendars.map((cal) => {
      if (addToAllCalendars || cal.id === activeCalendarId) {
        if (cal.members.some((m) => m.id === newMember.id)) return cal;
        return { ...cal, members: [...cal.members, newMember] };
      }
      return cal;
    });

    let nextProfiles = rosterProfiles;
    if (createShiftProfile) {
      const cleanName = newMember.name.replace(/\s*\(.*?\)\s*/g, '').trim() || newMember.name;
      const newProfile: ShiftRosterProfile = {
        id: `roster-${newMember.id}`,
        name: `${cleanName}のシフト表`,
        memberId: newMember.id,
        description: `${newMember.name}用のシフト表ルール設定`,
        rules: [...DEFAULT_SHIFT_RULES],
      };
      nextProfiles = [...rosterProfiles, newProfile];
      setRosterProfiles(nextProfiles);
    }

    setCalendars(nextCalendars);
    setActiveMemberId(newMember.id);
    pushStateToServer(
      nextCalendars,
      events,
      places,
      nextProfiles,
      `新規ユーザー「${newMember.name}」の追加`
    );
  };

  // Update User (name, color, password settings)
  const handleUpdateUser = (updatedMember: Member) => {
    const nextCalendars = calendars.map((cal) => ({
      ...cal,
      members: cal.members.map((m) => (m.id === updatedMember.id ? updatedMember : m)),
    }));
    setCalendars(nextCalendars);
    pushStateToServer(
      nextCalendars,
      events,
      places,
      rosterProfiles,
      `ユーザー「${updatedMember.name}」の設定更新`
    );
  };

  // Delete User
  const handleDeleteUser = (memberId: string) => {
    const target = activeCalendar.members.find((m) => m.id === memberId);
    if (target && target.isPasswordProtected && target.password) {
      // If currently not operating as this protected user, require unlocking first
      if (activeMemberId !== memberId) {
        setPendingUnlockMember(target);
        return;
      }
    }

    const nextCalendars = calendars.map((cal) => {
      if (cal.members.length <= 1) return cal;
      return {
        ...cal,
        members: cal.members.filter((m) => m.id !== memberId),
      };
    });
    setCalendars(nextCalendars);

    if (activeMemberId === memberId) {
      const remaining =
        nextCalendars.find((c) => c.id === activeCalendarId)?.members ||
        nextCalendars[0]?.members || [CURRENT_USER];
      setActiveMemberId(remaining[0].id);
    }

    pushStateToServer(
      nextCalendars,
      events,
      places,
      rosterProfiles,
      'ユーザーの削除'
    );
  };

  // Open Event Modal to create at date
  const handleCreateEventAtDate = (dateStr: string) => {
    setSelectedEvent({
      calendarId: activeCalendarId,
      date: dateStr,
      isAllDay: false,
      memberIds: [currentMember.id],
    });
    setIsEventModalOpen(true);
  };

  // Open Event Modal to edit
  const handleSelectEvent = (event: CalendarEvent) => {
    setSelectedEvent(event);
    setIsEventModalOpen(true);
  };

  // Save Event (supports single or array for recurring/bulk multi-date events)
  const handleSaveEvent = async (
    eventToSave: CalendarEvent | CalendarEvent[],
    pushToGoogle = false
  ) => {
    const eventsToProcess = Array.isArray(eventToSave) ? eventToSave : [eventToSave];

    if (pushToGoogle) {
      const token = accessToken || (await getAccessToken());
      if (token) {
        for (const ev of eventsToProcess) {
          try {
            const res = await pushEventToGoogleCalendar(token, ev);
            ev.googleEventId = res.id;
            ev.isGoogleSynced = true;
          } catch (err) {
            console.error('Failed to push event to Google Calendar:', err);
          }
        }
      }
    }

    setEvents((prev) => {
      let updated = [...prev];
      for (const ev of eventsToProcess) {
        const existsIdx = updated.findIndex((e) => e.id === ev.id);
        if (existsIdx >= 0) {
          updated[existsIdx] = ev;
        } else {
          updated = [ev, ...updated];
        }
      }
      pushStateToServer(
        calendars,
        updated,
        places,
        rosterProfiles,
        `予定「${eventsToProcess[0]?.title || 'スケジュール'}」`
      );
      return updated;
    });
  };

  // Delete Event (single or entire recurring/bulk group)
  const handleDeleteEvent = (id: string, recurringGroupId?: string) => {
    setEvents((prev) => {
      const next = recurringGroupId
        ? prev.filter((e) => e.recurringGroupId !== recurringGroupId)
        : prev.filter((e) => e.id !== id);
      pushStateToServer(calendars, next, places, rosterProfiles, '予定の削除');
      return next;
    });
  };

  // Shift Scanner Bulk Import
  const handleImportShifts = (newShifts: CalendarEvent[], targetCalendarId?: string) => {
    if (!newShifts || newShifts.length === 0) return;

    const destCalId = targetCalendarId || newShifts[0]?.calendarId || activeCalendarId;
    const importedDates = new Set(newShifts.map((s) => s.date));
    const importedMemberId = newShifts[0]?.memberIds?.[0];

    setEvents((prev) => {
      const filtered = prev.filter((e) => {
        if (e.id === 'evt-2' || e.id === 'evt-3') return false;
        if (
          e.calendarId === destCalId &&
          e.category === 'シフト' &&
          importedDates.has(e.date) &&
          (!importedMemberId || e.memberIds.includes(importedMemberId))
        ) {
          return false;
        }
        return true;
      });
      const next = [...newShifts, ...filtered];
      pushStateToServer(
        calendars,
        next,
        places,
        rosterProfiles,
        `シフト表（${newShifts.length}件）の一括登録`
      );
      return next;
    });

    if (destCalId && destCalId !== activeCalendarId) {
      setActiveCalendarId(destCalId);
    }
    setActiveView('calendar');

    const firstDate = newShifts[0]?.date;
    if (firstDate) {
      setCalendarFocusDate(`${firstDate}#${Date.now()}`);
    }

    const targetCal = calendars.find((c) => c.id === destCalId);
    const calName = targetCal?.name || 'カレンダー';
    const ymMatch = firstDate?.match(/^(\d{4})-(\d{2})/);
    const ymLabel = ymMatch ? `${ymMatch[1]}年${Number(ymMatch[2])}月` : '';

    showToast(
      `${ymLabel ? `${ymLabel}の` : ''}勤務表から ${newShifts.length} 件のシフトを「${calName}」に登録し、全端末へ同期しました！`,
      5000
    );
  };

  // Sync Roster Profiles when rules or profiles are updated in RosterScannerModal
  const handleRosterProfilesChange = (nextProfiles: ShiftRosterProfile[]) => {
    setRosterProfiles(nextProfiles);
    pushStateToServer(calendars, events, places, nextProfiles, 'シフト表ルールの設定');
  };

  // Places Handlers
  const handleAddPlace = (newPlace: Omit<PinnedPlace, 'id'>) => {
    const place: PinnedPlace = {
      ...newPlace,
      id: `pin-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
    };
    setPinnedPlaces((prev) => {
      const next = [place, ...prev];
      pushStateToServer(calendars, events, next, rosterProfiles, `スポット「${place.name}」の追加`);
      return next;
    });
  };

  const handleUpdatePlace = (updatedPlace: PinnedPlace) => {
    setPinnedPlaces((prev) => {
      const next = prev.map((p) => (p.id === updatedPlace.id ? updatedPlace : p));
      pushStateToServer(calendars, events, next, rosterProfiles, `スポット「${updatedPlace.name}」の更新`);
      return next;
    });
  };

  const handleDeletePlace = (id: string) => {
    setPinnedPlaces((prev) => {
      const next = prev.filter((p) => p.id !== id);
      pushStateToServer(calendars, events, next, rosterProfiles, 'スポットの削除');
      return next;
    });
  };

  // Create Calendar Event from a Pinned Place
  const handleCreateEventFromPlace = (place: PinnedPlace) => {
    setSelectedEvent({
      calendarId: place.calendarId || activeCalendarId,
      title: `${place.name} へおでかけ`,
      date: place.targetDate || new Date().toISOString().substring(0, 10),
      location: place.address || place.name,
      locationCoords: { lat: place.lat, lng: place.lng },
      notes: place.notes || '',
      category: place.category === 'cafe' || place.category === 'gourmet' ? 'デート' : '旅行',
      memberIds: [currentMember.id],
    });
    setIsEventModalOpen(true);
  };

  // Share & Join Calendar Handlers
  const handleJoinCalendarByCode = (code: string): boolean => {
    const found = calendars.find((c) => c.inviteCode.toUpperCase() === code.toUpperCase());
    if (found) {
      setActiveCalendarId(found.id);
      return true;
    }
    const newSharedCal: SharedCalendar = {
      id: `cal-joined-${Date.now()}`,
      name: `共有カレンダー (${code})`,
      description: '招待コードにより参加した共有カレンダー',
      color: '#6366F1',
      emoji: '🤝',
      inviteCode: code,
      members: [
        CURRENT_USER,
        {
          id: `owner-${code}`,
          name: '共有ホスト',
          avatarUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=150&q=80',
          color: '#6366F1',
          role: 'owner',
        },
      ],
    };

    const next = [...calendars, newSharedCal];
    setCalendars(next);
    setActiveCalendarId(newSharedCal.id);
    pushStateToServer(next, events, places, rosterProfiles, '共有カレンダーへの参加');
    return true;
  };

  const handleCreateNewCalendar = (newCal: Omit<SharedCalendar, 'id'>) => {
    const calendar: SharedCalendar = {
      ...newCal,
      id: `cal-${Date.now()}`,
    };
    const next = [...calendars, calendar];
    setCalendars(next);
    setActiveCalendarId(calendar.id);
    pushStateToServer(next, events, places, rosterProfiles, `カレンダー「${calendar.name}」の作成`);
  };

  const handleAddMemberToCalendar = (calendarId: string, member: Member) => {
    const next = calendars.map((c) =>
      c.id === calendarId ? { ...c, members: [...c.members, member] } : c
    );
    setCalendars(next);
    pushStateToServer(next, events, places, rosterProfiles, `メンバー「${member.name}」の追加`);
  };

  // Count Google synced events
  const googleSyncedCount = events.filter(
    (e) => e.isGoogleSynced || e.id.startsWith('google-')
  ).length;

  return (
    <div className="flex flex-col h-screen w-screen overflow-hidden bg-slate-100 font-sans text-slate-800">
      {/* Top Header */}
      <Header
        calendars={calendars}
        activeCalendar={activeCalendar}
        onSelectCalendar={handleSelectCalendar}
        activeView={activeView}
        onChangeView={setActiveView}
        onOpenRosterScanner={() => setIsRosterScannerOpen(true)}
        onOpenShareModal={() => {
          setShareModalTab('share');
          setIsShareModalOpen(true);
        }}
        onOpenCreateCalendar={() => {
          setShareModalTab('create');
          setIsShareModalOpen(true);
        }}
        onOpenGoogleSyncModal={() => setIsGoogleSyncModalOpen(true)}
        onOpenUserModal={() => setIsUserModalOpen(true)}
        onManualRefresh={() => fetchLatestServerState(true)}
        isRefreshing={isRefreshing}
        isLiveConnected={isLiveConnected}
        lastSyncedLabel={lastSyncedLabel}
        onlineCount={onlineCount}
        googleUser={googleUser}
        members={activeCalendar.members}
        currentMember={currentMember}
        onSwitchMember={handleSwitchMember}
      />

      {/* Main View Area */}
      <main className="flex-1 overflow-hidden pb-16 md:pb-0">
        {activeView === 'calendar' ? (
          <CalendarView
            events={events}
            calendars={calendars}
            activeCalendarId={activeCalendarId}
            members={activeCalendar.members}
            onSelectEvent={handleSelectEvent}
            onCreateEventAtDate={handleCreateEventAtDate}
            onDeleteEvent={handleDeleteEvent}
            onOpenRosterScanner={() => setIsRosterScannerOpen(true)}
            focusDateTrigger={calendarFocusDate}
          />
        ) : (
          <MapAndPlacesView
            places={places}
            calendars={calendars}
            activeCalendarId={activeCalendarId}
            onAddPlace={handleAddPlace}
            onUpdatePlace={handleUpdatePlace}
            onDeletePlace={handleDeletePlace}
            onCreateEventFromPlace={handleCreateEventFromPlace}
          />
        )}
      </main>

      {/* Event Details / Creation Modal */}
      <EventModal
        isOpen={isEventModalOpen}
        onClose={() => setIsEventModalOpen(false)}
        event={selectedEvent}
        calendars={calendars}
        activeCalendarId={activeCalendarId}
        members={activeCalendar.members}
        currentMember={currentMember}
        onSaveEvent={handleSaveEvent}
        onDeleteEvent={handleDeleteEvent}
        isGoogleConnected={Boolean(googleUser && accessToken)}
      />

      {/* Shift Roster Photo & PDF AI Scanner Modal */}
      <RosterScannerModal
        isOpen={isRosterScannerOpen}
        onClose={() => setIsRosterScannerOpen(false)}
        calendars={calendars}
        activeCalendarId={activeCalendarId}
        members={activeCalendar.members}
        currentMemberId={currentMember.id}
        onImportShifts={handleImportShifts}
        externalProfiles={rosterProfiles}
        onProfilesChange={handleRosterProfilesChange}
      />

      {/* User Addition & Password Management Modal */}
      <UserManagementModal
        isOpen={isUserModalOpen}
        onClose={() => setIsUserModalOpen(false)}
        members={activeCalendar.members}
        currentMember={currentMember}
        calendars={calendars}
        activeCalendarId={activeCalendarId}
        onAddUser={handleAddUser}
        onUpdateUser={handleUpdateUser}
        onDeleteUser={handleDeleteUser}
        onSelectUser={handleSelectUserFromModal}
      />

      {/* Password Unlock Modal when switching to a password-protected user */}
      <PasswordUnlockModal
        targetMember={pendingUnlockMember}
        onCancel={() => setPendingUnlockMember(null)}
        onSuccess={(unlockedMember) => {
          setActiveMemberId(unlockedMember.id);
          setPendingUnlockMember(null);
          setIsUserModalOpen(false);
          showToast(`🔒 パスワード認証に成功し、「${unlockedMember.name}」に切り替えました`);
        }}
      />

      {/* Calendar Share & Invite Modal */}
      <ShareModal
        isOpen={isShareModalOpen}
        onClose={() => setIsShareModalOpen(false)}
        activeCalendar={activeCalendar}
        calendars={calendars}
        onJoinCalendarByCode={handleJoinCalendarByCode}
        onCreateNewCalendar={handleCreateNewCalendar}
        onAddMemberToCalendar={handleAddMemberToCalendar}
        initialTab={shareModalTab}
      />

      {/* Google Calendar Sync Settings Modal */}
      <GoogleCalendarSyncModal
        isOpen={isGoogleSyncModalOpen}
        onClose={() => setIsGoogleSyncModalOpen(false)}
        currentUser={googleUser}
        accessToken={accessToken}
        onSyncGoogleEvents={handleSyncGoogleEvents}
        isSyncing={isSyncingGoogle}
        syncedCount={googleSyncedCount}
      />

      {/* Floating Success / Sync Toast */}
      {toastMessage && (
        <div className="fixed bottom-6 left-1/2 -translate-x-1/2 z-[3000] bg-slate-900/95 text-white px-5 py-3 rounded-2xl shadow-2xl border border-slate-700/60 flex items-center gap-3 text-xs sm:text-sm font-semibold pointer-events-none animate-in fade-in slide-in-from-bottom-3 duration-200">
          <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
          <span>{toastMessage}</span>
        </div>
      )}
    </div>
  );
}
