import express from 'express';
import path from 'path';
import fs from 'node:fs';
import { fileURLToPath } from 'url';
import dns from 'node:dns';
import dotenv from 'dotenv';
import { GoogleGenAI, Type } from '@google/genai';

// Prioritize IPv4 to avoid hanging on environments without IPv6 connectivity
dns.setDefaultResultOrder('ipv4first');

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = Number(process.env.PORT) || 3000;

app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ extended: true, limit: '50mb' }));

// Initialize Gemini SDK with telemetry header as required by guidelines
const ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY,
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    },
  },
});

// Helper to deterministically + AI-assistedly parse natural language Japanese shift rule explanations
function parseRulesDeterministically(explanationText: string): any[] {
  if (!explanationText || !explanationText.trim()) return [];
  const extracted: any[] = [];
  const palette = ['#10B981', '#F59E0B', '#EA580C', '#8B5CF6', '#0284C7', '#6D28D9', '#2563EB', '#EC4899'];

  // Split by common Japanese clause delimiters: 、 。 \n ／ ;
  const segments = explanationText
    .split(/[。\n；;]+|(?<=休み|公休|有給|有休|日勤|早番|遅番|夜勤|当直|明け|\d{1,2}:\d{2}|\d{1,2}時(?:半|\d{1,2}分)?)[、,]\s*/)
    .map((s) => s.trim())
    .filter(Boolean);

  // Also split further on commas if each part looks like "XはY"
  const clauses: string[] = [];
  for (const seg of segments) {
    const subParts = seg.split(/[、,]/);
    let current = '';
    for (const sub of subParts) {
      if (current && /(?:は|=|＝|→|:|：)/.test(sub)) {
        clauses.push(current.trim());
        current = sub;
      } else {
        current = current ? `${current}、${sub}` : sub;
      }
    }
    if (current.trim()) clauses.push(current.trim());
  }

  const normalizeTime = (hStr: string, mStr?: string, isHalf?: boolean): string => {
    const h = Math.min(Math.max(parseInt(hStr, 10) || 0, 0), 23);
    const m = isHalf ? 30 : Math.min(Math.max(parseInt(mStr || '0', 10) || 0, 0), 59);
    return `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}`;
  };

  clauses.forEach((clause, idx) => {
    // Match symbol before は / が / ＝ / = / → / : / なら
    // e.g. 「A」は早番(8:00〜16:30), Aは8時〜17時の日勤, 斜線(/)と公は休み
    const m = clause.match(
      /^(?:記号)?\s*[「『"'(（]?([^\s「』"')\）はが=＝→:：、,]{1,6})[」』"')\）]?(?:\s*(?:と|や|・|\/)\s*[「『"'(（]?([^\s「』"')\）はが=＝→:：、,]{1,6})[」』"')\）]?)?\s*(?:は|が|なら|=|＝|→|:|：|を)\s*(.+)$/
    );
    if (!m) return;

    const symbols = [m[1], m[2]].filter(Boolean).map((s) => s.trim());
    const restDesc = m[3].trim();

    const isOff =
      /休み|公休|休日|休|オフ|OFF|有給|有休|年休|夏休|特休/.test(restDesc) &&
      !/半休|午前|午後|\d{1,2}\s*[:時]/.test(restDesc);

    // Extract time range if present: e.g. 8:30〜17:15, 8時30分〜17時, 9時半-18時, 20:00〜翌5:00
    let startTime: string | undefined;
    let endTime: string | undefined;
    const timeMatch = restDesc.match(
      /(\d{1,2})(?:\s*[:：]\s*(\d{2})|\s*時(?:\s*(半)|(\d{1,2})分?)?)?\s*(?:[-〜~～からー]|より)\s*(?:翌|翌日)?\s*(\d{1,2})(?:\s*[:：]\s*(\d{2})|\s*時(?:\s*(半)|(\d{1,2})分?)?)?/
    );
    if (timeMatch && !isOff) {
      startTime = normalizeTime(timeMatch[1], timeMatch[2] || timeMatch[4], Boolean(timeMatch[3]));
      endTime = normalizeTime(timeMatch[5], timeMatch[6] || timeMatch[8], Boolean(timeMatch[7]));
    }

    // Determine shift name
    let shiftName = '';
    const knownShiftNames = [
      '日勤',
      '早番',
      '遅番',
      '中番',
      '準夜勤',
      '準夜',
      '深夜勤',
      '深夜',
      '夜勤明け',
      '夜勤',
      '当直',
      '通し勤務',
      '通し',
      '午前勤務',
      '午後勤務',
      '半休',
      '有給休暇',
      '有休',
      '特別休暇',
      '夏季休暇',
      '公休',
    ];
    for (const kn of knownShiftNames) {
      if (restDesc.includes(kn)) {
        shiftName = kn === '準夜' ? '準夜勤' : kn === '深夜' ? '深夜勤' : kn === '有休' ? '有給休暇' : kn;
        break;
      }
    }

    if (!shiftName) {
      if (isOff) {
        shiftName = '公休';
      } else {
        // Strip time range and parentheses from restDesc to get clean name
        const cleaned = restDesc
          .replace(/[(（][^）)]*[)）]/g, '')
          .replace(/(\d{1,2})(?:[:：]\d{2}|時(?:半|\d{1,2}分?)?)?\s*[-〜~～からー]\s*(?:翌|翌日)?\s*(\d{1,2})(?:[:：]\d{2}|時(?:半|\d{1,2}分?)?)?/g, '')
          .replace(/(?:で|です|として扱う|として|とする|にする|のこと|勤務|シフト|扱い)$/g, '')
          .replace(/^[で、,\s]+|[で、,\s]+$/g, '')
          .trim();
        shiftName = cleaned && cleaned.length <= 12 ? cleaned : `${symbols[0]}勤務`;
      }
    }

    if (!isOff && !startTime) {
      if (shiftName.includes('早')) {
        startTime = '07:00';
        endTime = '16:00';
      } else if (shiftName.includes('遅')) {
        startTime = '12:00';
        endTime = '21:00';
      } else if (shiftName.includes('準夜')) {
        startTime = '16:00';
        endTime = '00:30';
      } else if (shiftName.includes('深夜')) {
        startTime = '00:00';
        endTime = '08:30';
      } else if (shiftName.includes('夜')) {
        startTime = '16:30';
        endTime = '09:30';
      } else {
        startTime = '08:30';
        endTime = '17:30';
      }
    }

    for (const sym of symbols) {
      const cleanSym = sym === '斜線' ? '／' : sym === '丸' || sym === 'マル' ? '○' : sym;
      const color = isOff
        ? shiftName.includes('有')
          ? '#EC4899'
          : '#F43F5E'
        : shiftName.includes('早')
        ? '#F59E0B'
        : shiftName.includes('遅')
        ? '#EA580C'
        : shiftName.includes('夜') || shiftName.includes('準') || shiftName.includes('深')
        ? '#7C3AED'
        : palette[idx % palette.length];

      extracted.push({
        symbol: cleanSym,
        name: shiftName,
        startTime: isOff ? undefined : startTime,
        endTime: isOff ? undefined : endTime,
        isDayOff: isOff,
        color,
        note: `文章説明より自動学習 (${clause})`,
      });
    }
  });

  return extracted;
}

// Endpoint to extract structured shift rules from natural language description
app.post('/api/roster/extract-rules', async (req, res) => {
  try {
    const { explanationText = '' } = req.body;
    if (!explanationText || typeof explanationText !== 'string' || !explanationText.trim()) {
      return res.status(400).json({ error: 'ルールの説明文が入力されていません。' });
    }

    const deterministicRules = parseRulesDeterministically(explanationText);

    try {
      const response = await ai.models.generateContent({
        model: 'gemini-3.8-flash',
        contents: `以下のユーザーが入力したシフト表のルール説明文から、シフト記号とシフト内容の対応ルールをすべて抽出してJSON配列で返してください。

【ユーザーの説明文】
${explanationText}

【抽出ルール】
- symbol: シフト表に書かれる記号や文字（例: "A", "B", "早", "準", "／", "○", "空欄" など）
- name: シフトの名称（例: "早番", "遅番", "日勤", "準夜勤", "公休", "有給休暇" など）
- startTime: 開始時刻 "HH:mm" 形式（休日の場合は空文字または省略）
- endTime: 終了時刻 "HH:mm" 形式（休日の場合は空文字または省略）
- isDayOff: 休日・公休・有給などの場合は true、出勤の場合は false
- color: シフト種別に合った16進数カラーコード（例: 日勤="#10B981", 早番="#F59E0B", 遅番="#EA580C", 夜勤="#7C3AED", 公休="#F43F5E", 有給="#EC4899", その他="#0284C7"）
- note: 補足メモ（例: "文章説明から自動登録"）`,
        config: {
          responseMimeType: 'application/json',
          temperature: 0.1,
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              rules: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    symbol: { type: Type.STRING },
                    name: { type: Type.STRING },
                    startTime: { type: Type.STRING },
                    endTime: { type: Type.STRING },
                    isDayOff: { type: Type.BOOLEAN },
                    color: { type: Type.STRING },
                    note: { type: Type.STRING },
                  },
                  required: ['symbol', 'name', 'isDayOff', 'color'],
                },
              },
            },
            required: ['rules'],
          },
        },
      });

      const parsed = JSON.parse((response.text || '{}').trim());
      if (Array.isArray(parsed.rules) && parsed.rules.length > 0) {
        const sanitized = parsed.rules.map((r: any, i: number) => ({
          id: `rule-ai-${Date.now()}-${i}`,
          symbol: String(r.symbol || '').trim(),
          name: String(r.name || '').trim(),
          startTime: r.isDayOff ? undefined : r.startTime || '08:30',
          endTime: r.isDayOff ? undefined : r.endTime || '17:30',
          isDayOff: Boolean(r.isDayOff),
          color: r.color || (r.isDayOff ? '#F43F5E' : '#10B981'),
          note: r.note || '文章説明から自動追加',
        })).filter((r: any) => r.symbol && r.name);

        if (sanitized.length > 0) {
          return res.json({ success: true, rules: sanitized });
        }
      }
    } catch (aiErr) {
      console.warn('Gemini rule extraction fallback to deterministic parser:', aiErr);
    }

    const fallbackRules = deterministicRules.map((r, i) => ({
      ...r,
      id: `rule-det-${Date.now()}-${i}`,
    }));

    return res.json({ success: true, rules: fallbackRules });
  } catch (err: any) {
    console.error('Error extracting rules from text:', err);
    return res.status(500).json({ error: '文章からのルール抽出に失敗しました。', details: err.message });
  }
});

// Shift schedule recognition endpoint via Gemini Multimodal Vision (Supports Images & PDFs + Natural Language Rule Learning)
app.post('/api/roster/parse', async (req, res) => {
  try {
    const {
      imageBase64,
      mimeType = 'image/jpeg',
      targetPersonName = '',
      targetYear,
      targetMonth,
      customRules = [],
      ruleExplanationText = '',
    } = req.body;

    if (!imageBase64) {
      return res.status(400).json({ error: '画像またはPDFデータが提供されていません。' });
    }

    // Extract actual mimeType from data URL header if present (supports image/* and application/pdf)
    const dataUrlMatch = imageBase64.match(/^data:([a-zA-Z0-9/+.-]+);base64,/);
    const detectedMime = dataUrlMatch ? dataUrlMatch[1] : mimeType;
    const effectiveMimeType =
      detectedMime === 'application/pdf' || mimeType === 'application/pdf'
        ? 'application/pdf'
        : detectedMime === 'image/svg+xml' || !detectedMime
        ? 'image/jpeg'
        : detectedMime;

    // Strip data URL prefix if present
    const base64Data = imageBase64.replace(/^data:[a-zA-Z0-9/+.-]+;base64,/, '');

    // Pre-parse any natural language explanation deterministically so we also have immediate rules
    const deterministicNewRules = parseRulesDeterministically(ruleExplanationText);

    const currentYear = 2026;
    const requestedYear = Number(targetYear) || currentYear;
    const requestedMonth = Number(targetMonth); // 1..12 if user explicitly chose a month, else 0/NaN

    let targetMonthInstruction = '';
    if (requestedMonth >= 1 && requestedMonth <= 12) {
      targetMonthInstruction = `・ユーザーが対象年月として「${requestedYear}年${requestedMonth}月」を指定しています。detectedYear=${requestedYear}, detectedMonth=${requestedMonth}, yearMonth="${requestedYear}-${String(requestedMonth).padStart(2, '0')}" としてください。`;
    }

    // Format custom rules prompt section if user provided them
    let customRulesSection = '';
    if (Array.isArray(customRules) && customRules.length > 0) {
      customRulesSection = `
【★登録済みのシフト記号ルール】
${customRules
  .map(
    (r: any) =>
      `・記号「${r.symbol}」 → シフト名:「${r.name}」(開始:${r.startTime || '未設定'}, 終了:${r.endTime || '未設定'}, 休み:${r.isDayOff ? 'true' : 'false'})`
  )
  .join('\n')}
`;
    }

    let explanationPromptSection = '';
    if (ruleExplanationText && String(ruleExplanationText).trim()) {
      explanationPromptSection = `
【★★最重要：ユーザーからの追加ルール文章説明（未登録ルールの教え）】
ユーザーから今回のシフト表の読み取りルールについて以下の文章説明が与えられています。この説明に従ってシフト表を読み取り、さらにこの文章に含まれる新しい記号・シフトルールを "extractedRules" 配列に構造化して出力してください：
「${String(ruleExplanationText).trim()}」
`;
    }

    const prompt = `あなたは日本の勤務表・シフト表（病院・介護・飲食店・小売・オフィス・工場・バイト等の画像およびPDFドキュメント）の超高精度OCRエキスパートです。
添付されたシフト表（${effectiveMimeType === 'application/pdf' ? 'PDFファイル' : '画像'}）から「対象年月」「各スタッフの1日〜末日の日付別シフト記号」を正確に読み取ってください。

【1. 年月（何月度か）の特定ルール（最重要・絶対厳守）】
・表内のタイトル・見出し・隅の文字（例:「8月」「8月度」「2026年8月」「令和8年8月」「08月」「8/1〜8/31」「August」「AUG」等）を最優先で探してください。
・「8月」と書かれている場合は必ず detectedMonth: 8, yearMonth: "${requestedYear}-08" にしてください。絶対に10月など無関係な月にしないでください。
・もし上部が切れていて「○月」の文字が見えない場合は、日付ヘッダーの「1日」の曜日から2026年の月を特定してください：
  - 1日が「土」(土曜) かつ31日まで → 8月 (2026-08)
  - 1日が「水」(水曜) かつ31日まで → 7月 (2026-07)
  - 1日が「火」(火曜) かつ30日まで → 9月 (2026-09)
  - 1日が「月」(月曜) かつ30日まで → 6月 (2026-06)
  - 1日が「金」(金曜) かつ31日まで → 5月 (2026-05)
  - 1日が「水」(水曜) かつ30日まで → 4月 (2026-04)
  - 1日が「日」(日曜) かつ31日まで → 3月 (2026-03)
  - 1日が「日」(日曜) かつ28日まで → 2月 (2026-02)
  - 1日が「木」(木曜) かつ31日まで → 10月 または 1月
  - 1日が「日」(日曜) かつ30日まで → 11月 (2026-11)
  - 1日が「火」(火曜) かつ31日まで → 12月 (2026-12)
${targetMonthInstruction}

【2. スタッフ別の1日〜末日の読み取りルール（列ズレ・捏造厳禁）】
・表内の各スタッフ（最大10名、個人カレンダーなら1名）について、日付の列番号（1〜31）とマス目の文字を必ずペアにしてカンマ区切り文字列 "shiftsByDay" として出力してください。
  - 書式: "1:日,2:早,3:遅,4:休,5:日,6:夜,7:明,8:公,9:／,10:日..." （1日からその月の末日まで）
  - マス目が空欄なら "1:空"、斜線なら "1:／"、丸なら "1:○"、時間表記なら "1:9-17" のように記載してください。
  - 必ず上部（または左部）にある「日付の数字(1〜31)」と「そのスタッフの行の交差するマス目」を1日ずつ照合し、列ズレが起きないようにしてください。
・指定対象者: ${targetPersonName ? `「${targetPersonName}」（部分一致・苗字のみでも可）` : '指定なし（表の1人目のスタッフ）'}
${customRulesSection}
${explanationPromptSection}
・指定のJSONのみを出力してください。`;

    const genConfig = {
      systemInstruction:
        'あなたは日本のシフト表・勤務表（画像およびPDF）を1日〜末日まで日付番号と照合して正確に読み取るOCRエキスパートです。ユーザーの文章説明ルールがある場合はそれを抽出し、簡潔なJSONのみを返してください。',
      responseMimeType: 'application/json',
      temperature: 0.1,
      maxOutputTokens: 2500,
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          detectedYear: {
            type: Type.INTEGER,
            description: '読み取った西暦年 (例: 2026)',
          },
          detectedMonth: {
            type: Type.INTEGER,
            description: '読み取った月 (1〜12の整数。8月なら必ず8)',
          },
          yearMonth: {
            type: Type.STRING,
            description: '特定した年月 (YYYY-MM形式、例: 2026-08)',
          },
          personName: {
            type: Type.STRING,
            description: '対象者の氏名',
          },
          staffRows: {
            type: Type.ARRAY,
            description: '各スタッフの氏名と1日〜末日の「日:記号」カンマ区切り文字列（最大10名）',
            items: {
              type: Type.OBJECT,
              properties: {
                name: {
                  type: Type.STRING,
                  description: 'スタッフ氏名',
                },
                shiftsByDay: {
                  type: Type.STRING,
                  description: '1日から末日までの「日:記号」カンマ区切り文字列（例: "1:日,2:早,3:休,4:夜,5:明,..."）',
                },
              },
              required: ['name', 'shiftsByDay'],
            },
          },
          extractedRules: {
            type: Type.ARRAY,
            description: 'ユーザーの文章説明や表の凡例から新たに特定・学習したシフト記号ルール',
            items: {
              type: Type.OBJECT,
              properties: {
                symbol: { type: Type.STRING, description: '表の記号 (例: A, B, 通, ／, ○)' },
                name: { type: Type.STRING, description: 'シフト名称 (例: 早番, 遅番, 通し勤務, 公休)' },
                startTime: { type: Type.STRING, description: '開始時刻 HH:mm (休日は空文字)' },
                endTime: { type: Type.STRING, description: '終了時刻 HH:mm (休日は空文字)' },
                isDayOff: { type: Type.BOOLEAN, description: '休日・公休ならtrue' },
                color: { type: Type.STRING, description: 'カラーコード (#10B981, #F59E0B, #EA580C, #7C3AED, #F43F5E等)' },
                note: { type: Type.STRING, description: '補足説明' },
              },
              required: ['symbol', 'name', 'isDayOff'],
            },
          },
        },
        required: ['detectedMonth', 'yearMonth', 'personName', 'staffRows'],
      },
    };

    const callModelWithTimeout = async (modelName: string, timeoutMs: number) => {
      return Promise.race([
        ai.models.generateContent({
          model: modelName,
          contents: [
            {
              role: 'user',
              parts: [
                {
                  inlineData: {
                    data: base64Data,
                    mimeType: effectiveMimeType,
                  },
                },
                {
                  text: prompt,
                },
              ],
            },
          ],
          config: genConfig,
        }),
        new Promise((_, reject) =>
          setTimeout(() => reject(new Error(`Timeout after ${timeoutMs}ms on ${modelName}`)), timeoutMs)
        ),
      ]);
    };

    let response: any;
    const modelsToTry = [
      { name: 'gemini-3.8-flash', timeout: 15000 },
      { name: 'gemini-flash-latest', timeout: 15000 },
      { name: 'gemini-3.1-flash-lite', timeout: 12000 },
    ];
    let lastError: any = null;

    for (const m of modelsToTry) {
      try {
        response = await callModelWithTimeout(m.name, m.timeout);
        if (response && response.text) {
          break;
        }
      } catch (err: any) {
        lastError = err;
        console.warn(`Model ${m.name} failed or timed out (${err?.message}), attempting next model...`);
      }
    }

    if (!response && lastError) {
      throw lastError;
    }

    let parsedJson: any = {};
    const rawText = (response?.text || '').trim();
    const cleanedText = rawText.replace(/^```(?:json)?\s*/i, '').replace(/\s*```$/i, '').trim();

    try {
      parsedJson = JSON.parse(cleanedText || '{}');
    } catch (parseErr: any) {
      console.warn('Direct JSON.parse failed, recovering partial response:', parseErr?.message);
      parsedJson = { staffRows: [] };
      const rowRegex = /"name"\s*:\s*"([^"]+)"\s*,\s*"shiftsByDay"\s*:\s*"([^"]+)/g;
      let match: RegExpExecArray | null;
      while ((match = rowRegex.exec(cleanedText)) !== null) {
        parsedJson.staffRows.push({ name: match[1], shiftsByDay: match[2] });
      }
      const mMatch = cleanedText.match(/"detectedMonth"\s*:\s*(\d{1,2})/);
      if (mMatch) parsedJson.detectedMonth = parseInt(mMatch[1], 10);
    }

    // Combine AI extracted rules + deterministic rules from user's natural language explanation
    const combinedExtractedRules: any[] = [];
    const seenSymbols = new Set<string>();

    if (ruleExplanationText && String(ruleExplanationText).trim()) {
      const aiRules = Array.isArray(parsedJson?.extractedRules) ? parsedJson.extractedRules : [];
      for (const r of [...aiRules, ...deterministicNewRules]) {
        const sym = String(r?.symbol || '').trim();
        const name = String(r?.name || '').trim();
        if (!sym || !name || seenSymbols.has(sym)) continue;
        seenSymbols.add(sym);
        const isOff = Boolean(r.isDayOff);
        combinedExtractedRules.push({
          id: `rule-learned-${Date.now()}-${combinedExtractedRules.length}`,
          symbol: sym,
          name,
          startTime: isOff ? undefined : r.startTime || '08:30',
          endTime: isOff ? undefined : r.endTime || '17:30',
          isDayOff: isOff,
          color: r.color || (isOff ? '#F43F5E' : '#10B981'),
          note: r.note || '文章説明から自動学習',
        });
      }
    }

    // Active rule list = newly learned rules from explanation (highest priority) + existing customRules
    const effectiveRules = [
      ...combinedExtractedRules,
      ...(Array.isArray(customRules) ? customRules : []),
    ];

    // 1. Resolve effective Year & Month accurately (NEVER hardcode October!)
    let effectiveYear = requestedYear;
    let effectiveMonth = requestedMonth >= 1 && requestedMonth <= 12 ? requestedMonth : 0;

    // Priority 2: detectedMonth from Gemini
    if (!effectiveMonth) {
      const dm = Number(parsedJson?.detectedMonth);
      if (!isNaN(dm) && dm >= 1 && dm <= 12) {
        effectiveMonth = dm;
      }
      const dy = Number(parsedJson?.detectedYear);
      if (!isNaN(dy) && dy >= 2020 && dy <= 2035) {
        effectiveYear = dy;
      }
    }

    // Priority 3: yearMonth string from Gemini
    if (!effectiveMonth) {
      const ymStr = String(parsedJson?.yearMonth || '').trim();
      const ymMatch = ymStr.match(/(\d{4})[-/年.](\d{1,2})/);
      if (ymMatch) {
        effectiveYear = parseInt(ymMatch[1], 10);
        effectiveMonth = parseInt(ymMatch[2], 10);
      } else {
        const mOnly = ymStr.match(/(\d{1,2})/);
        if (mOnly) {
          const m = parseInt(mOnly[1], 10);
          if (m >= 1 && m <= 12) effectiveMonth = m;
        }
      }
    }

    // Final fallback if completely undetectable
    if (!effectiveYear || isNaN(effectiveYear)) effectiveYear = currentYear;
    if (!effectiveMonth || isNaN(effectiveMonth) || effectiveMonth < 1 || effectiveMonth > 12) {
      effectiveMonth = 8;
    }

    const daysInEffectiveMonth = new Date(effectiveYear, effectiveMonth, 0).getDate();
    const formattedYearMonth = `${effectiveYear}-${String(effectiveMonth).padStart(2, '0')}`;
    parsedJson.yearMonth = formattedYearMonth;

    // Check if user's rule explanation or custom rules define a custom behavior for blank cells
    const blankRule = effectiveRules.find(
      (r: any) => r.symbol === '空' || r.symbol === '空欄' || r.symbol === '空白'
    );

    // Deterministic converter from a single cell's raw symbol to a ShiftEntry
    const convertCellSymbolToShift = (
      rawSym: string,
      dayNum: number,
      blankMeansDayOff: boolean
    ) => {
      const sym = String(rawSym || '').trim();
      const isBlankToken = !sym || sym === '空' || sym === '空欄' || sym === '空白';
      const dateStr = `${effectiveYear}-${String(effectiveMonth).padStart(2, '0')}-${String(dayNum).padStart(2, '0')}`;

      // 1. Check effective rules (including newly explained rules) first
      if (!isBlankToken && effectiveRules.length > 0) {
        const exactRule = effectiveRules.find(
          (r: any) => r.symbol === sym || r.name === sym
        );
        if (exactRule) {
          return {
            date: dateStr,
            rawSymbol: sym,
            shiftType: exactRule.name,
            isDayOff: Boolean(exactRule.isDayOff),
            startTime: exactRule.isDayOff ? undefined : exactRule.startTime || '08:30',
            endTime: exactRule.isDayOff ? undefined : exactRule.endTime || '17:30',
            note: `表記載:「${sym}」`,
          };
        }
      }

      // 2. Empty cell handling
      if (isBlankToken) {
        if (blankRule) {
          return {
            date: dateStr,
            rawSymbol: '空欄',
            shiftType: blankRule.name,
            isDayOff: Boolean(blankRule.isDayOff),
            startTime: blankRule.isDayOff ? undefined : blankRule.startTime || '08:30',
            endTime: blankRule.isDayOff ? undefined : blankRule.endTime || '17:30',
            note: `空欄(${blankRule.name})`,
          };
        }
        if (blankMeansDayOff) {
          return {
            date: dateStr,
            rawSymbol: '空欄',
            shiftType: '公休',
            isDayOff: true,
            note: '空欄(休み)',
          };
        }
        return {
          date: dateStr,
          rawSymbol: '空欄',
          shiftType: '日勤',
          isDayOff: false,
          startTime: '08:30',
          endTime: '17:30',
          note: '標準日勤',
        };
      }

      // 3. Time range written directly in cell (e.g. "9-17", "9:00-17:30", "10〜19")
      const timeRangeMatch = sym.match(/(\d{1,2})(?::(\d{2}))?\s*[-〜~～/]\s*(\d{1,2})(?::(\d{2}))?/);
      if (timeRangeMatch) {
        const sh = timeRangeMatch[1].padStart(2, '0');
        const sm = timeRangeMatch[2] || '00';
        const eh = timeRangeMatch[3].padStart(2, '0');
        const em = timeRangeMatch[4] || '00';
        return {
          date: dateStr,
          rawSymbol: sym,
          shiftType: `出勤(${sh}:${sm}-${eh}:${em})`,
          isDayOff: false,
          startTime: `${sh}:${sm}`,
          endTime: `${eh}:${em}`,
          note: `表記載:「${sym}」`,
        };
      }

      // 4. Night shift finish ("明", "明け")
      if (sym === '明' || sym.includes('明け') || sym === '夜明') {
        return {
          date: dateStr,
          rawSymbol: sym,
          shiftType: '夜勤明け',
          isDayOff: false,
          startTime: '00:00',
          endTime: '09:30',
          note: `表記載:「${sym}」`,
        };
      }

      // 5. Paid leave / Special leave
      if (sym.includes('有') || sym.includes('年')) {
        return {
          date: dateStr,
          rawSymbol: sym,
          shiftType: '有給休暇',
          isDayOff: true,
          note: `表記載:「${sym}」`,
        };
      }
      if (sym.includes('夏') || sym.includes('特')) {
        return {
          date: dateStr,
          rawSymbol: sym,
          shiftType: '夏季・特別休',
          isDayOff: true,
          note: `表記載:「${sym}」`,
        };
      }

      // 6. Day off / Holiday symbols
      if (
        ['休', '公', '公休', '○', '◎', '／', '/', '×', '✕', '-', 'ー', '―', '希', '希望休', 'OFF', 'off', '休み'].includes(sym) ||
        sym.includes('休') ||
        sym.includes('公')
      ) {
        return {
          date: dateStr,
          rawSymbol: sym,
          shiftType: '公休',
          isDayOff: true,
          note: `表記載:「${sym}」`,
        };
      }

      // 7. Standard shift types
      if (sym.includes('早') || sym === 'E' || sym === '前' || sym === 'A' || sym === '1' || sym === '1直') {
        return {
          date: dateStr,
          rawSymbol: sym,
          shiftType: sym.includes('1') ? '1直 (朝勤)' : '早番',
          isDayOff: false,
          startTime: '07:00',
          endTime: '16:00',
          note: `表記載:「${sym}」`,
        };
      }
      if (sym.includes('遅') || sym === 'L' || sym === '後' || sym === 'B' || sym === '2' || sym === '2直') {
        return {
          date: dateStr,
          rawSymbol: sym,
          shiftType: sym.includes('2') ? '2直 (夕勤)' : '遅番',
          isDayOff: false,
          startTime: '11:00',
          endTime: '20:00',
          note: `表記載:「${sym}」`,
        };
      }
      if (sym.includes('準') || sym === 'S') {
        return {
          date: dateStr,
          rawSymbol: sym,
          shiftType: '準夜勤',
          isDayOff: false,
          startTime: '16:00',
          endTime: '00:30',
          note: `表記載:「${sym}」`,
        };
      }
      if (sym.includes('深')) {
        return {
          date: dateStr,
          rawSymbol: sym,
          shiftType: '深夜勤',
          isDayOff: false,
          startTime: '00:00',
          endTime: '08:30',
          note: `表記載:「${sym}」`,
        };
      }
      if (
        sym.includes('夜') ||
        sym.includes('当') ||
        sym.includes('宿') ||
        sym === 'N' ||
        sym === 'C' ||
        sym === '☆' ||
        sym === '★' ||
        sym === '●' ||
        sym === '3' ||
        sym === '3直'
      ) {
        return {
          date: dateStr,
          rawSymbol: sym,
          shiftType: sym.includes('当') ? '当直' : sym.includes('3') ? '3直 (夜勤)' : '夜勤',
          isDayOff: false,
          startTime: '16:30',
          endTime: '09:30',
          note: `表記載:「${sym}」`,
        };
      }
      if (sym.includes('半') || sym === 'AM' || sym.includes('午前')) {
        return {
          date: dateStr,
          rawSymbol: sym,
          shiftType: '午前勤務',
          isDayOff: false,
          startTime: '08:30',
          endTime: '12:30',
          note: `表記載:「${sym}」`,
        };
      }
      if (sym === 'PM' || sym.includes('午後')) {
        return {
          date: dateStr,
          rawSymbol: sym,
          shiftType: '午後勤務',
          isDayOff: false,
          startTime: '13:00',
          endTime: '17:30',
          note: `表記載:「${sym}」`,
        };
      }

      return {
        date: dateStr,
        rawSymbol: sym,
        shiftType: sym === '日' || sym === '常' || sym === 'D' || sym === '出' ? '日勤' : sym,
        isDayOff: false,
        startTime: '08:30',
        endTime: '17:30',
        note: `表記載:「${sym}」`,
      };
    };

    // Parse "1:日,2:早,3:休..." or array into day->symbol map and build allStaffShifts
    const parseShiftsByDayString = (rawStr: string): { [day: number]: string } => {
      const map: { [day: number]: string } = {};
      if (!rawStr) return map;
      const parts = String(rawStr).split(/[,、\n]+/);
      parts.forEach((part, idx) => {
        const trimmed = part.trim();
        if (!trimmed) return;
        const m = trimmed.match(/^(\d{1,2})\s*[:：=]\s*(.*)$/);
        if (m) {
          const d = parseInt(m[1], 10);
          if (d >= 1 && d <= 31) {
            map[d] = m[2].trim();
          }
        } else if (idx + 1 <= 31) {
          map[idx + 1] = trimmed;
        }
      });
      return map;
    };

    const allStaffShifts: { [name: string]: any[] } = {};
    const staffNamesList: string[] = [];

    if (Array.isArray(parsedJson?.staffRows) && parsedJson.staffRows.length > 0) {
      for (const row of parsedJson.staffRows) {
        if (!row || !row.name) continue;
        const cleanName = String(row.name).trim();
        if (!cleanName) continue;

        const dayMap = parseShiftsByDayString(row.shiftsByDay || '');
        const dayNumbers = Object.keys(dayMap).map(Number).filter((d) => d >= 1 && d <= daysInEffectiveMonth);
        if (dayNumbers.length === 0) continue;

        staffNamesList.push(cleanName);

        const maxDayInRow = Math.min(Math.max(...dayNumbers), daysInEffectiveMonth);
        const symbolsArray = Array.from({ length: maxDayInRow }, (_, i) => dayMap[i + 1] || '');

        const explicitRestCount = symbolsArray.filter((s) => {
          const v = s.trim();
          return ['休', '公', '○', '◎', '／', '/', '×', '✕', '-', 'ー', '有', '夏', '希', 'OFF'].some(
            (tok) => v === tok || v.includes('休') || v.includes('公')
          );
        }).length;
        const blankMeansDayOff = explicitRestCount === 0;

        const rowShifts = [];
        for (let d = 1; d <= maxDayInRow; d++) {
          rowShifts.push(convertCellSymbolToShift(dayMap[d] || '', d, blankMeansDayOff));
        }
        allStaffShifts[cleanName] = rowShifts;
      }
    }

    const normalizeName = (n: string) => n.replace(/\s+/g, '').toLowerCase();
    const targetNorm = normalizeName(targetPersonName || '');

    let matchedStaffName = '';
    if (staffNamesList.length > 0) {
      if (targetNorm) {
        matchedStaffName =
          staffNamesList.find((n) => normalizeName(n) === targetNorm) ||
          staffNamesList.find(
            (n) => normalizeName(n).includes(targetNorm) || targetNorm.includes(normalizeName(n))
          ) ||
          '';
      }
      if (!matchedStaffName && parsedJson.personName) {
        const pNorm = normalizeName(parsedJson.personName);
        matchedStaffName =
          staffNamesList.find((n) => normalizeName(n) === pNorm) ||
          staffNamesList.find((n) => normalizeName(n).includes(pNorm) || pNorm.includes(normalizeName(n))) ||
          '';
      }
      if (!matchedStaffName) {
        matchedStaffName = staffNamesList[0];
      }
    }

    if (matchedStaffName && allStaffShifts[matchedStaffName]?.length > 0) {
      parsedJson.personName = matchedStaffName;
      parsedJson.shifts = allStaffShifts[matchedStaffName];
    } else {
      parsedJson.shifts = [];
    }

    parsedJson.detectedStaffNames =
      staffNamesList.length > 0
        ? staffNamesList
        : Array.isArray(parsedJson.detectedStaffNames)
        ? parsedJson.detectedStaffNames.filter(Boolean)
        : [];
    parsedJson.allStaffShifts = allStaffShifts;
    parsedJson.extractedRules = combinedExtractedRules;

    // Recompute accurate summary for the selected person
    if (Array.isArray(parsedJson.shifts) && parsedJson.shifts.length > 0) {
      const counts: { [k: string]: number } = {};
      for (const s of parsedJson.shifts) {
        const k = s.isDayOff ? '公休・休み' : s.shiftType;
        counts[k] = (counts[k] || 0) + 1;
      }
      const countSummary = Object.entries(counts)
        .map(([k, v]) => `${k}:${v}日`)
        .join(' / ');
      parsedJson.summary = `${effectiveYear}年${effectiveMonth}月度 (${parsedJson.personName}): 計${parsedJson.shifts.length}日分 [${countSummary}]`;
    }

    return res.json({ success: true, data: parsedJson });
  } catch (error: any) {
    console.error('Error parsing roster image/PDF:', error);
    return res.status(500).json({
      error: '勤務表の解析中にエラーが発生しました。ファイル形式や画像の鮮明さをご確認ください。',
      details: error.message,
    });
  }
});

// Google-Maps-like shop, restaurant and place search endpoint
app.post('/api/places/search', async (req, res) => {
  try {
    const { query } = req.body;
    if (!query || typeof query !== 'string' || !query.trim()) {
      return res.status(400).json({ error: '検索キーワードが入力されていません。' });
    }

    const trimmedQuery = query.trim();

    // 1. Fetch via Photon Komoot Geocoder (Fast, no API key needed, no 403 block)
    try {
      const photonUrl = `https://photon.komoot.io/api/?q=${encodeURIComponent(
        trimmedQuery
      )}&limit=5&lat=35.6812&lon=139.7671`;
      const photonRes = await fetch(photonUrl, {
        headers: { 'User-Agent': 'TimeShare-App/1.0' },
      });

      if (photonRes.ok) {
        const data = await photonRes.json();
        if (data.features && data.features.length > 0) {
          const mapped = data.features.map((feat: any) => {
            const props = feat.properties || {};
            const [lon, lat] = feat.geometry?.coordinates || [0, 0];
            const rawName = props.name || props.street || trimmedQuery;
            const city = props.city || props.county || props.state || '';
            const street = props.street || '';
            const address = [city, street, props.housenumber, props.country]
              .filter(Boolean)
              .join(' ');

            let cat = 'sightseeing';
            const osmVal = (props.osm_value || '').toLowerCase();
            if (osmVal.includes('cafe') || osmVal.includes('coffee') || rawName.includes('カフェ') || rawName.includes('珈琲')) {
              cat = 'cafe';
            } else if (osmVal.includes('restaurant') || osmVal.includes('food') || osmVal.includes('bar') || rawName.includes('ラーメン') || rawName.includes('焼肉')) {
              cat = 'gourmet';
            } else if (osmVal.includes('shop') || osmVal.includes('supermarket') || osmVal.includes('mall')) {
              cat = 'shopping';
            } else if (osmVal.includes('hotel') || osmVal.includes('guest_house')) {
              cat = 'stay';
            }

            return {
              name: rawName,
              address: address || `${city} 周辺`,
              lat,
              lng: lon,
              category: cat,
              source: 'photon',
            };
          });

          return res.json({ success: true, places: mapped });
        }
      }
    } catch (photonErr) {
      console.warn('Photon lookup error in server:', photonErr);
    }

    return res.json({ success: true, places: [] });
  } catch (error: any) {
    console.error('Error in /api/places/search:', error);
    return res.status(500).json({ error: '店舗の検索中にエラーが発生しました。', details: error.message });
  }
});

// Reverse Geocoding proxy to avoid client CORS / rate-limit failures
app.get('/api/places/reverse', async (req, res) => {
  try {
    const { lat, lng } = req.query;
    if (!lat || !lng) {
      return res.status(400).json({ error: '緯度・経度が指定されていません。' });
    }

    const nominatimUrl = `https://nominatim.openstreetmap.org/reverse?format=json&lat=${encodeURIComponent(
      String(lat)
    )}&lon=${encodeURIComponent(String(lng))}&zoom=18&addressdetails=1`;

    const nominatimRes = await fetch(nominatimUrl, {
      headers: {
        'User-Agent': 'TimeShare-Calendar-App/1.0 (Japan; OpenStreetMap Applet)',
        'Accept': 'application/json',
      },
    });

    if (nominatimRes.ok) {
      const data = await nominatimRes.json();
      return res.json({ success: true, displayName: data.display_name || '' });
    }

    return res.json({ success: false, displayName: '' });
  } catch (err: any) {
    console.warn('Reverse geocode proxy error:', err);
    return res.json({ success: false, displayName: '' });
  }
});

// Weather and Disaster Risk endpoint
app.post('/api/places/weather-disaster', async (req, res) => {
  try {
    const { lat, lng, placeName } = req.body;
    if (lat === undefined || lng === undefined) {
      return res.status(400).json({ error: '緯度・経度が指定されていません。' });
    }

    const latitude = Number(lat);
    const longitude = Number(lng);

    // Fetch live weather & forecast from Open-Meteo
    const weatherUrl = `https://api.open-meteo.com/v1/forecast?latitude=${latitude}&longitude=${longitude}&current=temperature_2m,relative_humidity_2m,apparent_temperature,is_day,precipitation,weather_code,wind_speed_10m&daily=weather_code,temperature_2m_max,temperature_2m_min,precipitation_sum,precipitation_probability_max,wind_speed_10m_max&timezone=Asia%2FTokyo`;

    const weatherRes = await fetch(weatherUrl);
    if (!weatherRes.ok) {
      throw new Error(`Open-Meteo error: ${weatherRes.status}`);
    }

    const weatherData = await weatherRes.json();
    const current = weatherData.current || {};
    const daily = weatherData.daily || {};

    // WMO Weather code translation helper
    const getWeatherInfo = (code: number) => {
      switch (code) {
        case 0:
          return { label: '快晴', emoji: '☀️', condition: 'sunny' };
        case 1:
        case 2:
          return { label: '晴れ時々曇り', emoji: '⛅', condition: 'partly-cloudy' };
        case 3:
          return { label: '曇り', emoji: '☁️', condition: 'cloudy' };
        case 45:
        case 48:
          return { label: '霧', emoji: '🌫️', condition: 'fog' };
        case 51:
        case 53:
        case 55:
        case 56:
        case 57:
          return { label: '小雨・霧雨', emoji: '🌦️', condition: 'drizzle' };
        case 61:
        case 63:
          return { label: '雨', emoji: '🌧️', condition: 'rain' };
        case 65:
        case 66:
        case 67:
          return { label: '激しい雨', emoji: '⛈️', condition: 'heavy-rain' };
        case 71:
        case 73:
        case 75:
        case 77:
          return { label: '雪', emoji: '❄️', condition: 'snow' };
        case 80:
        case 81:
        case 82:
          return { label: 'にわか雨', emoji: '🌧️', condition: 'shower' };
        case 85:
        case 86:
          return { label: 'にわか雪', emoji: '🌨️', condition: 'snow-shower' };
        case 95:
        case 96:
        case 99:
          return { label: '雷雨・荒天', emoji: '⛈️', condition: 'thunderstorm' };
        default:
          return { label: '晴れ', emoji: '☀️', condition: 'sunny' };
      }
    };

    const curWeather = getWeatherInfo(current.weather_code ?? 0);

    // 5-day daily forecast
    const forecastDays = (daily.time || []).slice(0, 5).map((dStr: string, idx: number) => {
      const code = daily.weather_code?.[idx] ?? 0;
      const info = getWeatherInfo(code);
      return {
        date: dStr,
        maxTemp: Math.round(daily.temperature_2m_max?.[idx] ?? 0),
        minTemp: Math.round(daily.temperature_2m_min?.[idx] ?? 0),
        rainProb: daily.precipitation_probability_max?.[idx] ?? 0,
        rainSum: daily.precipitation_sum?.[idx] ?? 0,
        maxWind: daily.wind_speed_10m_max?.[idx] ?? 0,
        weatherLabel: info.label,
        emoji: info.emoji,
      };
    });

    // Evaluate Disaster and Severe Weather Alerts
    const maxRainToday = daily.precipitation_sum?.[0] ?? 0;
    const maxRainProbToday = daily.precipitation_probability_max?.[0] ?? 0;
    const maxWindToday = daily.wind_speed_10m_max?.[0] ?? 0;
    const currentTemp = Math.round(current.temperature_2m ?? 20);

    const alerts: { level: 'safe' | 'caution' | 'warning' | 'emergency'; title: string; desc: string }[] = [];

    // Rain alert
    if (maxRainToday >= 30 || current.weather_code >= 95) {
      alerts.push({
        level: 'warning',
        title: '大雨・荒天警報レベルの降水',
        desc: '激しい降雨や落雷のおそれがあります。屋外での活動や河川付近は十分ご注意ください。',
      });
    } else if (maxRainProbToday >= 60 || maxRainToday >= 10) {
      alerts.push({
        level: 'caution',
        title: '降雨・傘必須アラート',
        desc: '雨が降る可能性が高いです。雨具の持参や屋内観光ルートの検討がおすすめです。',
      });
    }

    // Wind alert
    if (maxWindToday >= 15) {
      alerts.push({
        level: 'warning',
        title: '強風・突風警報警戒',
        desc: `最大風速 ${Math.round(maxWindToday)}m/s の突風が予想されます。展望台や屋外レジャーは営業状況をご確認ください。`,
      });
    } else if (maxWindToday >= 10) {
      alerts.push({
        level: 'caution',
        title: '風がやや強め',
        desc: '風が強まりやすいコンディションです。帽子や持ち物の飛ばされにご注意ください。',
      });
    }

    // Heatstroke alert
    if (currentTemp >= 35) {
      alerts.push({
        level: 'warning',
        title: '熱中症警戒アラート発令レベル',
        desc: '気温が35℃以上の猛暑日です。こまめな水分・塩分補給と涼しい屋内での休憩を行ってください。',
      });
    } else if (currentTemp >= 31) {
      alerts.push({
        level: 'caution',
        title: '真夏日・熱中症注意',
        desc: '日中の日差しが強く熱中症のリスクがあります。日傘や水分補給をご準備ください。',
      });
    }

    // If no negative alerts, mark safe
    const isSafe = alerts.length === 0;
    const overallStatus = alerts.some((a) => a.level === 'warning')
      ? 'warning'
      : alerts.length > 0
      ? 'caution'
      : 'safe';

    const overallMessage =
      overallStatus === 'safe'
        ? '現在、大きな気象警報や災害リスクは確認されておらず、観光やおでかけに最適なコンディションです！'
        : overallStatus === 'warning'
        ? '気象警報・悪天候リスクがあります。最新の自治体防災情報や交通情報をご確認ください。'
        : '天候の変化に少し注意が必要です。雨具や上着をご準備ください。';

    return res.json({
      success: true,
      data: {
        placeName: placeName || '指定場所',
        current: {
          temp: currentTemp,
          apparentTemp: Math.round(current.apparent_temperature ?? currentTemp),
          humidity: current.relative_humidity_2m ?? 50,
          windSpeed: Math.round((current.wind_speed_10m ?? 0) * 10) / 10,
          precipitation: current.precipitation ?? 0,
          weatherLabel: curWeather.label,
          emoji: curWeather.emoji,
          condition: curWeather.condition,
        },
        forecast: forecastDays,
        disaster: {
          overallStatus,
          isSafe,
          alerts,
          summaryMessage: overallMessage,
        },
      },
    });
  } catch (error: any) {
    console.error('Error fetching weather & disaster data:', error);
    return res.status(500).json({ error: '天気・災害情報の取得に失敗しました。', details: error.message });
  }
});


// ============================================================================
// Multi-Device Real-Time Synchronization (SSE + Persistent Server State)
// ============================================================================
interface ServerSharedState {
  version: number;
  updatedAt: string;
  updatedBy?: string;
  clientId?: string;
  calendars: any[] | null;
  events: any[] | null;
  places: any[] | null;
  rosterProfiles: any[] | null;
}

const DATA_DIR = path.join(__dirname, 'data');
const STATE_FILE = path.join(DATA_DIR, 'shared-state.json');

function loadServerStateFromDisk(): ServerSharedState {
  try {
    if (fs.existsSync(STATE_FILE)) {
      const raw = fs.readFileSync(STATE_FILE, 'utf-8');
      const parsed = JSON.parse(raw);
      if (parsed && typeof parsed.version === 'number') {
        return parsed;
      }
    }
  } catch (err) {
    console.warn('Could not read shared-state.json, initializing fresh state:', err);
  }
  return {
    version: 0,
    updatedAt: new Date().toISOString(),
    calendars: null,
    events: null,
    places: null,
    rosterProfiles: null,
  };
}

function saveServerStateToDisk(state: ServerSharedState) {
  try {
    if (!fs.existsSync(DATA_DIR)) {
      fs.mkdirSync(DATA_DIR, { recursive: true });
    }
    fs.writeFileSync(STATE_FILE, JSON.stringify(state, null, 2), 'utf-8');
  } catch (err) {
    console.warn('Could not persist shared-state.json:', err);
  }
}

let serverSharedState: ServerSharedState = loadServerStateFromDisk();
const sseClients = new Set<express.Response>();

function broadcastStateToClients(payload: any) {
  const dataStr = `data: ${JSON.stringify(payload)}\n\n`;
  for (const clientRes of sseClients) {
    try {
      clientRes.write(dataStr);
    } catch {
      sseClients.delete(clientRes);
    }
  }
}

// Keep SSE connections alive through proxies
setInterval(() => {
  for (const clientRes of sseClients) {
    try {
      clientRes.write(`: heartbeat ${Date.now()}\n\n`);
    } catch {
      sseClients.delete(clientRes);
    }
  }
}, 20000);

// 1. Live SSE stream for real-time multi-device updates
app.get('/api/sync/stream', (req, res) => {
  res.setHeader('Content-Type', 'text/event-stream');
  res.setHeader('Cache-Control', 'no-cache, no-transform');
  res.setHeader('Connection', 'keep-alive');
  res.setHeader('X-Accel-Buffering', 'no');
  res.flushHeaders?.();

  // Immediately send current authoritative state on connect
  res.write(
    `data: ${JSON.stringify({
      type: 'connected',
      state: serverSharedState,
      onlineCount: sseClients.size + 1,
    })}\n\n`
  );

  sseClients.add(res);

  // Notify all clients of updated online count
  broadcastStateToClients({
    type: 'presence',
    onlineCount: sseClients.size,
  });

  req.on('close', () => {
    sseClients.delete(res);
    broadcastStateToClients({
      type: 'presence',
      onlineCount: sseClients.size,
    });
  });
});

// 2. Fetch latest shared state (on mount, window focus, or manual Refresh button)
app.get('/api/sync/state', (_req, res) => {
  return res.json({
    success: true,
    state: serverSharedState,
    onlineCount: sseClients.size,
  });
});

// 3. Push state update from any device and broadcast to all other devices in real time
app.post('/api/sync/update', (req, res) => {
  try {
    const {
      clientId,
      updatedBy,
      actionLabel,
      calendars,
      events,
      places,
      rosterProfiles,
      isInitialSeed,
    } = req.body || {};

    // If this is just an initial seed from a newly opened client and the server already has data, return server's data without overwriting
    if (isInitialSeed && serverSharedState.version > 0) {
      return res.json({
        success: true,
        alreadySeeded: true,
        state: serverSharedState,
      });
    }

    serverSharedState = {
      version: serverSharedState.version + 1,
      updatedAt: new Date().toISOString(),
      updatedBy: updatedBy || serverSharedState.updatedBy,
      clientId: clientId || undefined,
      calendars: Array.isArray(calendars) ? calendars : serverSharedState.calendars,
      events: Array.isArray(events) ? events : serverSharedState.events,
      places: Array.isArray(places) ? places : serverSharedState.places,
      rosterProfiles: Array.isArray(rosterProfiles)
        ? rosterProfiles
        : serverSharedState.rosterProfiles,
    };

    saveServerStateToDisk(serverSharedState);

    broadcastStateToClients({
      type: 'state:updated',
      clientId,
      updatedBy,
      actionLabel,
      state: serverSharedState,
      onlineCount: sseClients.size,
    });

    return res.json({
      success: true,
      state: serverSharedState,
    });
  } catch (err: any) {
    console.error('Error in /api/sync/update:', err);
    return res.status(500).json({ error: '同期データの更新に失敗しました。', details: err.message });
  }
});

// Vite middleware in development or static serving in production
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.join(__dirname, 'dist')));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(__dirname, 'dist', 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running at http://0.0.0.0:${PORT}`);
  });
}

startServer();
